<?php
ob_start();
include("../db.php");
include("../header2.php");

if(!isset($_SESSION['sno'])){
    header("Location: ../admin_login");
    exit(); 
}

if(isset($_SESSION['sno']) && !empty($_SESSION['sno'])){
$sessionid = $_SESSION['sno'];
$result1 = "SELECT sno,type,sa_access FROM users WHERE sno = '$sessionid'";
$getusers = mysqli_query($con, $result1);
$rowusers = mysqli_fetch_assoc($getusers);
	$loggedid = mysqli_real_escape_string($con, $rowusers['sno']);
	$adminrole = mysqli_real_escape_string($con, $rowusers['type']);
	$sa_access = mysqli_real_escape_string($con, $rowusers['sa_access']);
}else{
	$loggedid = '';
	$adminrole = '';
	$sa_access = '';
}

if($adminrole == 'Super_admin'){
?>
<div id="wrapper">
    <?php include("../sidebar2.php"); ?>
	
    <div id="content-wrapper">
      <div class="container-fluid">
		
		<div class="col-sm-12 mb-3">
		<div class="row">
		<div class="col-sm-6">
			<input type="text" class="form-control getvalClass" placeholder="Search by Id or A/C number">
		</div>
		<div class="col-sm-2">
			<button name="submit" type="submit" class="btn btn-sm btn-success searchAcbtn">Search</button>
		</div>
		</div>
		</div>
		
		<?php if(!empty($_GET['success']) == 'not_found' && isset($_GET['success'])){ ?>
			<p><center><b style="color:red;">Id Not Found</b></center></p>
		<?php } ?>
	  
		<div class="card mb-3">
          <div class="card-header">
            <i class="fas fa-table"></i>
            Delete Id
		  </div>
			
          <div class="card-body">
			           
			<div class="table-responsive">
              <table class="table table-bordered" id="" width="100%" cellspacing="0">
                <thead>
                  <tr>
					<th>Username</th>
                    <th>Associate Name</th>
                    <th>Created</th>
                    <th>Action</th>
				  </tr>
				</thead>
				
				<tbody class="searchResult">				
				</tbody>
				</table>
			</div>
			
          </div>
        </div>
		
<script>
$(document).on('click', '.searchAcbtn', function(){
	var getvalClass = $('.getvalClass').val();
	$('.showLoading').show();
	$.post("../response.php?tag=deleteIdList",{"getval":getvalClass},function(d){		
	if(d == ""){	
		alert("Not found");
		$('.searchResult').html(" ");
		$('.showLoading').hide();
	}else{
		$('.searchResult').html(" ");
		for (i in d) {
			$('<tr class="delsno'+d[i].snoid+'">' +
			'<td>'+d[i].username+'</td>' + 
			'<td>'+d[i].associate_name+'</td>' +
			'<td>'+d[i].created+'</td>' +
			'<td>'+d[i].delbtn+'</td>' +
			'</tr>').appendTo(".searchResult");
		}
	}	
	});
	$('.showLoading').hide();
	
	$(document).on('click', '.deldiv', function(){
		var getid = $(this).attr('data-id');
			
		var checkstr =  confirm('Are you sure you want to delete this?');
		if(checkstr == true){		
			$.post("../response.php?tag=deleteId",{"getid":getid},function(d){
				if(d == '1'){
					$('.delsno'+getid).hide();
				}			
			});
		}else{
			return false;
		}
	});		
});


</script>

<?php include("../footer2.php"); 
}else{
	header("Location: ../logout.php");
}
?>
