<?phpob_start();
include("../db.php");

$sponserid = $_POST["usid"];
$bnkname = $_POST["ubnkname"];
$nameIdClass = $_POST['assnameId'];

$flag = 0;
	
	if(!empty($sponserid)){
		$flag = 1;
		if($sponserid > 0 ){
			$sponserid1 = "username = '$sponserid'";
		}else{
			$sponserid1 = "username = '$sponserid'";
		}
	}else{
		$sponserid1 = '';
	}
	
	if(!empty($nameIdClass)){
		if($nameIdClass > 0 ){
			if ($flag == 1){
				$nameId1 = "AND (username LIKE '%$nameIdClass%') OR (associate_name LIKE '%$nameIdClass%')";
			}else{
				$nameId1 = "(username LIKE '%$nameIdClass%') OR (associate_name LIKE '%$nameIdClass%')";
				 $flag = 1;
			}
		}else{
			if ($flag == 1){
				$nameId1 = "AND (username LIKE '%$nameIdClass%') OR (associate_name LIKE '%$nameIdClass%')";
			}else{
				$nameId1 = "(username LIKE '%$nameIdClass%') OR (associate_name LIKE '%$nameIdClass%')";
				 $flag = 1;
			}			
		}
	}else{
		$nameId1 = '';
	}	
	
	if(!empty($bnkname)){
		if($bnkname > 0 ){
			if ($flag == 1){
				$bnkname1 = "AND bank_name = '$bnkname'";
			}else{
				$bnkname1 = "bank_name = '$bnkname'";
				 $flag = 1;
			}
		}else{
			if ($flag == 1){
				$bnkname1 = "AND bank_name = '$bnkname'";
			}else{
				$bnkname1 = "bank_name = '$bnkname'";
				 $flag = 1;
			}
			
		}
	}else{
		$bnkname1 = '';
	}


	
header("Content-Type: application/vnd.ms-excel");

echo 'Associate Name'. "\t" . 'Sponser Id'. "\t" . 'Account No' . "\t" . 'Account Holder Name' . "\t" . 'Bank Name' . "\t" . 'Branch Name' . "\t" . 'IFSC' . "\t" . 'Mobile Number' . "\t" . 'Email Address' . "\t" . 'GST Number' . "\t" . 'Associate Address' . "\t" . 'Country' . "\t" . 'State' . "\t" . 'City' . "\t" . 'Pin Code' . "\t" . 'DOB' . "\t" . 'size' . "\t" . 'Lenght' . "\t" . 'Nominee Name' . "\t" . 'Nominee Age' . "\t" . 'Nominee Relation' . "\t" . 'Pan Card No' . "\t" . 'Adhar No' . "\t" . 'occupation' . "\t" . 'Policy No' . "\t" . 'Pan Card' . "\t" . 'aadhar_front' . "\t" . 'aadhar_back' . "\t" . 'associate_image' . "\t" . 'associate_sign' . "\t" . 'created' .  "\n";

$result123 = "SELECT * FROM users WHERE $sponserid1 $bnkname1 $nameId1";
$resultsts=mysqli_query($con, $result123);

   while ($rowvalexprt=mysqli_fetch_array($resultsts)){

	$associate_name = mysqli_real_escape_string($con, $rowvalexprt['associate_name']);
	$username = mysqli_real_escape_string($con, $rowvalexprt['username']);
	$account_no = mysqli_real_escape_string($con, $rowvalexprt['account_no']);
	$account_holder_name = mysqli_real_escape_string($con, $rowvalexprt['account_holder_name']);
	$bank_name = mysqli_real_escape_string($con, $rowvalexprt['bank_name']);
	$branch_name = mysqli_real_escape_string($con, $rowvalexprt['branch_name']);
	$ifsc = mysqli_real_escape_string($con, $rowvalexprt['ifsc']);	
	$mobile = mysqli_real_escape_string($con, $rowvalexprt['mobile']);
	$email_address = mysqli_real_escape_string($con, $rowvalexprt['email_address']);
	$gstin_no = mysqli_real_escape_string($con, $rowvalexprt['gstin_no']);	
	$associate_address = mysqli_real_escape_string($con, $rowvalexprt['associate_address']);
	$country = mysqli_real_escape_string($con, $rowvalexprt['country']);
	$state = mysqli_real_escape_string($con, $rowvalexprt['state']);
	$city = mysqli_real_escape_string($con, $rowvalexprt['city']);
	$pin_code = mysqli_real_escape_string($con, $rowvalexprt['pin_code']);
	$dob = mysqli_real_escape_string($con, $rowvalexprt['dob']);
	$size = mysqli_real_escape_string($con, $rowvalexprt['size']);
	$lenght = mysqli_real_escape_string($con, $rowvalexprt['lenght']);
	$nominee_name = mysqli_real_escape_string($con, $rowvalexprt['nominee_name']);
	$nominee_age = mysqli_real_escape_string($con, $rowvalexprt['nominee_age']);
	$nominee_relation = mysqli_real_escape_string($con, $rowvalexprt['nominee_relation']);	
	$pan_card_no = mysqli_real_escape_string($con, $rowvalexprt['pan_card_no']);
	$adhar_no = mysqli_real_escape_string($con, $rowvalexprt['adhar_no']);
	$occupation = mysqli_real_escape_string($con, $rowvalexprt['occupation']);
	$policy_no = mysqli_real_escape_string($con, $rowvalexprt['policy_no']);
	$upload_pan = mysqli_real_escape_string($con, $rowvalexprt['upload_pan']);
	$upload_aadhar_front = mysqli_real_escape_string($con, $rowvalexprt['upload_aadhar_front']);
	$upload_aadhar_back = mysqli_real_escape_string($con, $rowvalexprt['upload_aadhar_back']);
	$associate_image = mysqli_real_escape_string($con, $rowvalexprt['associate_image']);
	$associate_sign = mysqli_real_escape_string($con, $rowvalexprt['associate_sign']);
	$created = mysqli_real_escape_string($con, $rowvalexprt['created']);
							
	
echo $associate_name. "\t" . $username. "\t" . $account_no . "\t" . $account_holder_name . "\t" . $bank_name . "\t" . $branch_name . "\t" . $ifsc . "\t" . $mobile . "\t" . $email_address . "\t" . $gstin_no . "\t" . $associate_address . "\t" . $country . "\t" . $state . "\t" . $city . "\t" . $pin_code . "\t" . $dob . "\t" . $size . "\t" . $lenght . "\t" . $nominee_name . "\t" . $nominee_age . "\t" . $nominee_relation . "\t" . $pan_card_no . "\t" . $adhar_no . "\t" . $occupation . "\t" . $policy_no . "\t" . "\t" . $upload_pan . "\t" . $upload_aadhar_front . "\t" . $associate_image . "\t" . $associate_sign . "\t" . $created.  "\n";

}


header("Content-disposition: attachment; filename=Account_Details.xls");
?>