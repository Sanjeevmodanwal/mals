<?phpob_start();
session_start();
include("../db.php");
	
header("Content-Type: application/vnd.ms-excel");

if(isset($_SESSION['sno']) && !empty($_SESSION['sno'])){
$sessionid = $_SESSION['sno'];
$result1 = "SELECT sno FROM users WHERE sno = '$sessionid'";
$getusers = mysqli_query($con, $result1);
$rowusers = mysqli_fetch_assoc($getusers);
	$loggedid = mysqli_real_escape_string($con, $rowusers['sno']);
}else{
	$loggedid = '';
}

echo 'Sno.' . "\t" . 'Associate Name'. "\t" . 'Associate Id'.  "\t" . 'Parent Name'.  "\t" . 'Introduser Id'.  "\t" . 'Position'. "\t" . 'Mobile Number' . "\t" . 'Email Address' . "\t" . 'GST Number' . "\t" . 'Associate Address' . "\t" . 'Country' . "\t" . 'State' . "\t" . 'City' . "\t" . 'Pin Code' . "\t" . 'DOB' . "\t" . 'Shirt Number' . "\t" . 'Lenght' .  "\t" . 'Account No' . "\t" . 'Account Holder Name' . "\t" . 'Bank Name' . "\t" . 'Branch Name' . "\t" . 'IFSC' . "\t" . 'Nominee Name' . "\t" . 'Nominee Age' . "\t" . 'Nominee Relation' . "\t" . 'Pan Card No' . "\t" . 'Adhar No' . "\t" . 'Pan Card' . "\t" . 'aadhar_front' . "\t" . 'aadhar_back' . "\t" . 'associate_image' . "\t" . 'created' .  "\n";

$result_all = "SELECT * FROM users where type!='Super_admin'";
$resultsts=mysqli_query($con, $result_all);

   while ($rowvalexprt=mysqli_fetch_array($resultsts)){
	$snoall = mysqli_real_escape_string($con, $rowvalexprt['sno']);
	$associate_name = mysqli_real_escape_string($con, $rowvalexprt['associate_name']);
	$username = mysqli_real_escape_string($con, $rowvalexprt['username']);		
	$mobile = mysqli_real_escape_string($con, $rowvalexprt['mobile']);
	$email_address = mysqli_real_escape_string($con, $rowvalexprt['email_address']);
	$gstin_no = mysqli_real_escape_string($con, $rowvalexprt['gstin_no']);	
	$associate_address = mysqli_real_escape_string($con, $rowvalexprt['associate_address']);
	$country = mysqli_real_escape_string($con, $rowvalexprt['country']);
	$state = mysqli_real_escape_string($con, $rowvalexprt['state']);
	$city = mysqli_real_escape_string($con, $rowvalexprt['city']);
	$pin_code = mysqli_real_escape_string($con, $rowvalexprt['pin_code']);
	$dob = mysqli_real_escape_string($con, $rowvalexprt['dob']);
	$size = mysqli_real_escape_string($con, $rowvalexprt['size']);
	$lenght = mysqli_real_escape_string($con, $rowvalexprt['lenght']);	
	$account_no = mysqli_real_escape_string($con, $rowvalexprt['account_no']);
	$account_holder_name = mysqli_real_escape_string($con, $rowvalexprt['account_holder_name']);
	$bank_name = mysqli_real_escape_string($con, $rowvalexprt['bank_name']);
	$branch_name = mysqli_real_escape_string($con, $rowvalexprt['branch_name']);
	$ifsc = mysqli_real_escape_string($con, $rowvalexprt['ifsc']);	
	$nominee_name = mysqli_real_escape_string($con, $rowvalexprt['nominee_name']);
	$nominee_age = mysqli_real_escape_string($con, $rowvalexprt['nominee_age']);
	$nominee_relation = mysqli_real_escape_string($con, $rowvalexprt['nominee_relation']);	
	$pan_card_no = mysqli_real_escape_string($con, $rowvalexprt['pan_card_no']);
	$adhar_no = mysqli_real_escape_string($con, $rowvalexprt['adhar_no']);
	$upload_pan = mysqli_real_escape_string($con, $rowvalexprt['upload_pan']);
	$upload_aadhar_front = mysqli_real_escape_string($con, $rowvalexprt['upload_aadhar_front']);
	$upload_aadhar_back = mysqli_real_escape_string($con, $rowvalexprt['upload_aadhar_back']);
	$associate_image = mysqli_real_escape_string($con, $rowvalexprt['associate_image']);
	$created = mysqli_real_escape_string($con, $rowvalexprt['created']);
	$sponser_id = mysqli_real_escape_string($con, $rowvalexprt['sponser_id']);
	$parent_id = mysqli_real_escape_string($con, $rowvalexprt['parent_id']);
	$position = mysqli_real_escape_string($con, $rowvalexprt['position']);	
	$prnt_qry = mysqli_query($con,"SELECT username FROM users where sno='$sponser_id'");	if(mysqli_num_rows($prnt_qry)){
		while ($row_prnt_qry = mysqli_fetch_assoc($prnt_qry)) {
		$sponser_id_name = mysqli_real_escape_string($con, $row_prnt_qry['username']);
	}	}else{		$sponser_id_name = '';	}
	$prnt_qry1 = mysqli_query($con,"SELECT username FROM users where sno='$parent_id'");	if(mysqli_num_rows($prnt_qry1)){
		while ($row_prnt_qry1 = mysqli_fetch_assoc($prnt_qry1)) {
		$parent_id_name = mysqli_real_escape_string($con, $row_prnt_qry1['username']);
	}	}else{		$parent_id_name = '';	}
							
	
echo $snoall . "\t" . $associate_name . "\t" . $username. "\t"  . $parent_id_name . "\t"  . $sponser_id_name . "\t"  . $position . "\t" . $mobile . "\t" . $email_address . "\t" . $gstin_no . "\t" . $associate_address . "\t" . $country . "\t" . $state . "\t" . $city . "\t" . $pin_code . "\t" . $dob . "\t" . $size . "\t" . $lenght . "\t" . $account_no . "\t" . $account_holder_name . "\t" . $bank_name . "\t" . $branch_name . "\t" . $ifsc .  "\t" . $nominee_name . "\t" . $nominee_age . "\t" . $nominee_relation . "\t" . $pan_card_no . "\t" . $adhar_no . "\t" . $upload_pan . "\t" . $upload_aadhar_front . "\t" . $associate_image . "\t" . $created.  "\n";
// die;

}
header("Content-disposition: attachment; filename=All_Download.xls");
?>