<?php
ob_start();
include("../db.php");
include("../header2.php");

if(!isset($_SESSION['sno'])){
    header("Location: ../admin_login");
    exit(); 
}

if(isset($_SESSION['sno']) && !empty($_SESSION['sno'])){
$sessionid = $_SESSION['sno'];
$result1 = "SELECT sno,type,sa_access FROM users WHERE sno = '$sessionid'";
$getusers = mysqli_query($con, $result1);
$rowusers = mysqli_fetch_assoc($getusers);
	$loggedid = mysqli_real_escape_string($con, $rowusers['sno']);
	$adminrole = mysqli_real_escape_string($con, $rowusers['type']);
	$sa_access = mysqli_real_escape_string($con, $rowusers['sa_access']);
}else{
	$loggedid = '';
	$adminrole = '';
	$sa_access = '';
}

if($adminrole == 'Super_admin'){
$snoid = base64_decode($_GET['snoid']);
$result1 = "SELECT sno,username,account_no,account_holder_name FROM users WHERE sno = '$snoid'";
$getusers = mysqli_query($con, $result1);
if(mysqli_num_rows($getusers)){
	$rowusers = mysqli_fetch_assoc($getusers);
	$user_sno = mysqli_real_escape_string($con, $rowusers['sno']);
	$username = mysqli_real_escape_string($con, $rowusers['username']);
	$account_no = mysqli_real_escape_string($con, $rowusers['account_no']);
	$account_holder_name = mysqli_real_escape_string($con, $rowusers['account_holder_name']);
}else{
	$user_sno = '';
	$username = '';
	$account_no = '';
	$account_holder_name = '';
}
?>
<div id="wrapper">
    <?php include("../sidebar2.php"); ?>
	
    <div id="content-wrapper">
      <div class="container-fluid">
		
		<div class="col-sm-12 mb-3">
		<div class="row">
		<div class="col-sm-6">
			<input type="text" class="form-control getvalClass" placeholder="Search by Id or A/C number">
		</div>
		<div class="col-sm-2">
			<button name="submit" type="submit" class="btn btn-sm btn-success searchAcbtn">Search</button>
		</div>
		</div>
		</div>
		
		<?php if(!empty($_GET['success']) == 'not_found' && isset($_GET['success'])){ ?>
			<p><center><b style="color:red;">Id Not Found</b></center></p>
		<?php } ?>
	  
		<div class="card mb-3">
          <div class="card-header">
            <i class="fas fa-table"></i>
            Payout(Passbook)
		  </div>
			
          <div class="card-body">
			<div class="searchResult">
				<div class="col-sm-12">
					<div class="col-sm-6">
						<p><b>User Id : </b><?php echo $username; ?></p>
						<p><b>A/C No. : </b><?php echo $account_no; ?></p>
						<p><b>Name : </b><?php echo $account_holder_name; ?></p>
					</div>
	<?php 
		$result_payout_Direct = "SELECT amount FROM payout_passbook_list WHERE income_name='Direct Income' AND user_id='$user_sno'";
		$get_payout_Direct = mysqli_query($con, $result_payout_Direct);
		$Direct_amount = 0;
		while ($row_payout_Direct = mysqli_fetch_assoc($get_payout_Direct)) {
			$Direct_amount += mysqli_real_escape_string($con, $row_payout_Direct['amount']);
		}

		$result_payout_Level = "SELECT amount FROM payout_passbook_list WHERE income_name='Level Income' AND user_id='$user_sno'";
		$get_payout_Level = mysqli_query($con, $result_payout_Level);
		$Level_amount = 0;
		while ($row_payout_Level = mysqli_fetch_assoc($get_payout_Level)) {
			$Level_amount += mysqli_real_escape_string($con, $row_payout_Level['amount']);
		}

		$result_payout_Other = "SELECT amount FROM payout_passbook_list WHERE income_name='Other Income' AND user_id='$user_sno'";
		$get_payout_Other = mysqli_query($con, $result_payout_Other);
		$Other_amount = 0;
		while ($row_payout_Other = mysqli_fetch_assoc($get_payout_Other)) {
			$Other_amount += mysqli_real_escape_string($con, $row_payout_Other['amount']);
		}
	?>
				<div class="col-sm-6">
					<p><b>Total Direct Income : </b><i class="fas fa-rupee-sign"></i><?php echo $Direct_amount; ?></p>
					<p><b>Total Level Income : </b><i class="fas fa-rupee-sign"></i><?php echo $Level_amount; ?></p>
					<p><b>Total Other Income : </b><i class="fas fa-rupee-sign"></i><?php echo $Other_amount; ?></p>
				</div>

				</div>
			</div>

			<form action="../mysqlaction.php" method="post" autocomplete="off">
				<p>
				<select name="level" required>
					<option value="">Select Level</option>
				<?php 
				$result_payout = "SELECT level FROM plan_payout_passbook WHERE status = '1' AND level!='' ";
				$get_payout = mysqli_query($con, $result_payout);
				while ($row_payout = mysqli_fetch_assoc($get_payout)) {
					$level = mysqli_real_escape_string($con, $row_payout['level']);
				?>
					<option><?php echo $level; ?></option>
				<?php } ?>
				</select>
				
				<select name="income" required>
					<option value="">Select Income</option>				
					<option value="Direct Income">Direct Income</option>
					<option value="Level Income">Level Income</option>
					<option value="Other Income">Other Income</option>
				</select>
				<input type='text' name='amount' placeholder="Enter Your Value" required>
				<input type='hidden' name='user_sno' class="puser_sno" value="<?php echo $user_sno; ?>">
				<input type='submit' class='btn btn-success btn-sm' name="btnpayinsert" value="Submit">
				</p>
			</form>
            
			<div class="table-responsive">
              <table class="table table-bordered" id="" width="100%" cellspacing="0">
                <thead>
                  <tr>
					<th>Level</th>
                    <th>Income</th>
                    <th>Amount</th>
                    <th>Created</th>
				  </tr>
				</thead>
				
				<tbody class="paytable">
				<?php 
				$result_payout = "SELECT * FROM payout_passbook_list WHERE user_id='$user_sno'";
				$get_payout = mysqli_query($con, $result_payout);
				$amount_qty = 0;
				while ($row_payout = mysqli_fetch_assoc($get_payout)) {
					$level = mysqli_real_escape_string($con, $row_payout['level']);
					$income_name = mysqli_real_escape_string($con, $row_payout['income_name']);
					$amount = mysqli_real_escape_string($con, $row_payout['amount']);
					$amount_qty += mysqli_real_escape_string($con, $row_payout['amount']);
					$datetime_1 = mysqli_real_escape_string($con, $row_payout['datetime']);
					$datetime = date('d F Y, h:i A', strtotime($datetime_1));
				?>
				<tr>
					<td><?php echo $level; ?></td>
					<td><?php echo $income_name; ?></td>
					<td><?php echo $amount; ?></td>
					<td><?php echo $datetime; ?></td>
				</tr>
				<?php } ?>
				<tr>
					<td colspan='2' class="text-right pr-5"><b>Total</b></td>
					<td><i class="fas fa-rupee-sign"></i><?php echo $amount_qty; ?></td>
					<td></td>
				</tr>
				</tbody>
				</table>
			</div>
			
          </div>
        </div>
		
<script>
$(document).on('click', '.searchAcbtn', function(){
	var getvalClass = $('.getvalClass').val();
	$('.showLoading').show();
	$.post("../response.php?tag=payoutList",{"getval":getvalClass},function(d){		
		$('.searchResult').html("");
		var snoid_1 = d[0].snoid;
		$('.puser_sno').attr('value', snoid_1);
		$('' + d[0].getallList + '').appendTo(".searchResult");	
	});
	
	$.post("../response.php?tag=payoutListUser",{"getval":getvalClass},function(d){		
		$('.paytable').html("");
		for (i in d) {
			$('' + d[i].allpaylist + '').appendTo(".paytable");
		}		
	});	
	$('.showLoading').hide();
	
});


</script>

<?php include("../footer2.php"); 
}else{
	header("Location: ../logout.php");
}
?>
