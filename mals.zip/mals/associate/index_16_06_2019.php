<?php
ob_start();
include("../db.php");
include("../header2.php");

if(!isset($_SESSION['sno'])){
    header("Location: ../admin_login");
    exit(); 
}

if(isset($_SESSION['sno']) && !empty($_SESSION['sno'])){
$sessionid = $_SESSION['sno'];
$result1 = "SELECT sno,type,sa_access FROM users WHERE sno = '$sessionid'";
$getusers = mysqli_query($con, $result1);
$rowusers = mysqli_fetch_assoc($getusers);
	$loggedid = mysqli_real_escape_string($con, $rowusers['sno']);
	$adminrole = mysqli_real_escape_string($con, $rowusers['type']);
	$sa_access = mysqli_real_escape_string($con, $rowusers['sa_access']);
}else{
	$loggedid = '';
	$adminrole = '';
	$sa_access = '';
}

if($adminrole == 'Super_admin'){
?>
<div id="wrapper">
    <?php include("../sidebar2.php"); ?>
	
    <div id="content-wrapper">
      <div class="container-fluid">
	  <div class="col-sm-12">
		<form method="post" action="all_export.php">
			<button name="alldownload" type="submit" class="btn btn-sm btn-success text-right mb-4">ALL Details Download</button>
		</form>
		</div>
		<div class="card mb-3">
          <div class="card-header">
            <i class="fas fa-table"></i>
            Users Table</div>
			
          <div class="card-body">
            <div class="table-responsive">
              <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                  <tr>
					<th>Username</th>
                    <th>Associate Name</th>
                    <th>Parent Name</th>
                    <th>Introduser Id</th>
                    <th>Position</th>
                    <th>Shirt No.</th>
                    <th>Size</th>
                    <th>Created</th>
                    <th>Action</th>
                  </tr>
                </thead>
                <tbody>
				<?php 
				$resultAssociate = mysqli_query($con,"SELECT sno,associate_name,username,parent_id,sponser_id,mobile,position,size,lenght,created FROM users WHERE type!='Super_admin'");
				while ($row_asso = mysqli_fetch_assoc($resultAssociate)) {
					$snoid = mysqli_real_escape_string($con, $row_asso['sno']);
					$associate_name = mysqli_real_escape_string($con, $row_asso['associate_name']);
					$sponser_id = mysqli_real_escape_string($con, $row_asso['sponser_id']);
					$parent_id = mysqli_real_escape_string($con, $row_asso['parent_id']);
					$username = mysqli_real_escape_string($con, $row_asso['username']);
					$position = mysqli_real_escape_string($con, $row_asso['position']);
					$size = mysqli_real_escape_string($con, $row_asso['size']);
					$lenght = mysqli_real_escape_string($con, $row_asso['lenght']);
					$created = mysqli_real_escape_string($con, $row_asso['created']);
					
					$prnt_qry = mysqli_query($con,"SELECT username FROM users where sno='$sponser_id'");
						 while ($row_prnt_qry = mysqli_fetch_assoc($prnt_qry)) {
						 $sponser_id_name = mysqli_real_escape_string($con, $row_prnt_qry['username']);
					}
					$prnt_qry1 = mysqli_query($con,"SELECT username FROM users where sno='$parent_id'");
						 while ($row_prnt_qry1 = mysqli_fetch_assoc($prnt_qry1)) {
						 $parent_id_name = mysqli_real_escape_string($con, $row_prnt_qry1['username']);
					}
				?>
                  <tr>
                    <td><?php echo $username; ?></td>
                    <td><?php echo $associate_name; ?></td>
                    <td><?php echo $parent_id_name; ?></td>
                    <td><?php echo $sponser_id_name; ?></td>
                    <td><?php echo $position; ?></td>
                    <td><?php echo $lenght; ?></td>
                    <td><?php echo $size; ?></td>
                    <td><?php echo $created; ?></td>
                    <td>
					<?php if($sa_access == 'Yes'){ ?>
					<a href="../associate/edituser.php?snoid=<?php echo base64_encode($snoid); ?>" class="btn btn-sm btn-warning" title="Edit"><i class="far fa-edit"></i></a>
					<?php }else{ ?>
					<a href="../associate/profile.php?snoid=<?php echo base64_encode($snoid); ?>" class="btn btn-sm btn-warning" title="Profile"><i class="far fa-eye"></i></a>
					<?php } ?>
                    <a href="../associate/tree_level.php?nameid=<?php echo $snoid; ?>" class="btn btn-sm btn-success" title="Tree Structure"><i class="fas fa-tree"></i></a>
                    <a href="../associate/changepassword.php?snoid=<?php echo base64_encode($snoid); ?>" class="btn btn-sm btn-danger" title="Change Password"><i class="fa fa-key"></i></a>
					</td>
                  </tr>
                <?php } ?>
                </tbody>
              </table>
            </div>
          </div>
        </div>	

<?php include("../footer2.php"); 
}else{
	header("Location: ../logout.php");
}
?>
