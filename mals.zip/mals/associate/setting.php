<?php
ob_start();
include("../db.php");
include("../header2.php");

if(!isset($_SESSION['sno'])){
    header("Location: ../admin_login");
    exit(); 
}

if(isset($_SESSION['sno']) && !empty($_SESSION['sno'])){
$sessionid = $_SESSION['sno'];
$result1 = "SELECT sno,type,password FROM users WHERE sno = '$sessionid'";
$getusers = mysqli_query($con, $result1);
$rowusers = mysqli_fetch_assoc($getusers);
	$loggedid = mysqli_real_escape_string($con, $rowusers['sno']);
	$adminrole = mysqli_real_escape_string($con, $rowusers['type']);
	$pswdrole = mysqli_real_escape_string($con, $rowusers['password']);
}else{
	$loggedid = '';
	$adminrole = '';
	$pswdrole = '';
}

if($adminrole == 'Super_admin'){
?>

<?php
if(!empty($_GET['snoid'])){
	$chngId = base64_decode($_GET['snoid']);
	$orgid = $_GET['snoid'];
}else{
	$chngId = '';
	$orgid = '';
}

if(isset($_POST['gen_password'])){
	$old_pass=md5(sha1($_POST['old_pass']));
	$new_pass=md5(sha1($_POST['new_pass']));
	$re_pass=md5(sha1($_POST['re_pass']));
	$new_pass_org=$_POST['new_pass'];
		
	$data_pwd= $pswdrole;
	if($data_pwd==$old_pass){
	if($new_pass==$re_pass){
		$update_pwd=mysqli_query($con,"UPDATE `users` SET  `password` = '$new_pass', `orgpass`='$new_pass_org' WHERE `sno` = $chngId");
		echo "<script>alert('Password Updated Sucessfully'); window.location='setting.php?snoid=$orgid'</script>";
	}else{
		echo "<script>alert('Your New and Confirm New Password do not match'); window.location='setting.php?snoid=$orgid'</script>";
	}
	}else{
	   echo "<script>alert('Old password is wrong'); window.location='setting.php?snoid=$orgid'</script>";
	}                     
}
?>

<div id="wrapper">
    <?php include("../sidebar2.php"); ?>
	
    <div id="content-wrapper">
      <div class="container-fluid">
	   
<?php if(isset($_GET['msg'])){
	if(isset($_GET['msg']) == 'successfully'){ 
?>
	<div class='alertdiv'>
		<div class='alert alert-danger' style="text-align:center;">
			<?php echo 'Successfully Saved'; ?>
		</div>
    </div>     
<?php } } ?>
	  
        <!-- Breadcrumbs-->
        <ol class="breadcrumb">
          <li class="breadcrumb-item">
            <a href="../dashboard">Dashboard</a>
          </li>
          <li class="breadcrumb-item active">Change Password</li>
        </ol>

        <!-- Icon Cards-->
        <div class="row">
			<div class="col-lg-12">
			<div class="panel panel-default">
	<form method="post" id="chnageformpass" autocomplete="off">
		<div class="panel-body">		
			<div class="form-group">
				<div class="row">
					<div class="col-sm-3">
						<label>Old Password <span class="required">*</span></label>
					</div>
					<div class="col-sm-9">
						<input type="password" name="old_pass" class="form-control is_require_once" id="opass" placeholder="Old Password..." value="" />
					</div>
				</div>
			</div>
			<div class="form-group">
				<div class="row">
					<div class="col-sm-3">
						<label>New Password <span class="required">*</span></label>
					</div>
					<div class="col-sm-9">
						<input type="password" name="new_pass" class="form-control is_require_once" id="password" placeholder="New Password..." />
					</div>
				</div>
			</div>
			<div class="form-group">
				<div class="row">
					<div class="col-sm-3">
						<label>Confirm Password <span class="required">*</span></label>
					</div>
					<div class="col-sm-9">
						<input type="password" name="re_pass" class="form-control is_require_once" id="cpassword" placeholder="Confirm New Password..." />
					</div>
				</div>
			</div>
			
			<div class="form-group">
			<div class="row">
				<div class="col-md-3"></div>
				<div class="col-md-3">
					<input type="submit" name="gen_password" value="Change Password" class="btn btn-success">					
				</div>
				<div class="col-md-6"></div>
			</div>
			</div>
        </div>
		</form>
        </div>
        </div>
        </div>

        <!-- DataTables Example -->
        <div class="card mb-3">
          
        </div>
   </div>
  
<style>
.error11{ background-color: #FFAAAA; }
.validError1{ background-color: #fff;}
</style>
<script>   
  $(document).ready(function () {
	$("#chnageformpass").submit(function () {
		var submit = true;
		$(".is_require_once:visible").each(function(){
			if($(this).val() == '') {
					$(this).addClass('error11');
					submit = false;
			} else {
					$(this).addClass('validError1');
			}
		});
		if(submit == true) {
			return true;        
		} else {
			$('.is_require_once').keyup(function(){
				$(this).removeClass('error11');
			});
			return false;        
		}
	});
	});
</script>
   
<?php include("../footer2.php"); 
}else{
	header("Location: ../logout.php");
}
?>
