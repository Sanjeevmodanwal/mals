<?php
ob_start();
include("../db.php");
include("../header2.php");

if(!isset($_SESSION['sno'])){
    header("Location: ../admin_login");
    exit(); 
}

if(isset($_SESSION['sno']) && !empty($_SESSION['sno'])){
$sessionid = $_SESSION['sno'];
$result1 = "SELECT sno,type FROM users WHERE sno = '$sessionid'";
$getusers = mysqli_query($con, $result1);
$rowusers = mysqli_fetch_assoc($getusers);
	$loggedid = mysqli_real_escape_string($con, $rowusers['sno']);
	$adminrole = mysqli_real_escape_string($con, $rowusers['type']);
}else{
	$loggedid = '';
	$adminrole = '';
}

if($adminrole == 'Super_admin'){
?>
<div id="wrapper">
    <?php include("../sidebar2.php"); ?>
	
    <div id="content-wrapper">
      <div class="container-fluid">
		<div class="card mb-3">
          <div class="card-header">
            <i class="fas fa-table"></i>
            Total Join</div>
			
          <div class="card-body">
            <div class="table-responsive">
              <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                  <tr>
					<th>User Id</th>
					<th>Joining Date</th>
                  </tr>
                </thead>
                <tbody>
				<?php 
				$resultAssociate = mysqli_query($con,"SELECT username,created FROM users WHERE type!='Super_admin'");
				while ($row_asso = mysqli_fetch_assoc($resultAssociate)) {
					$username = mysqli_real_escape_string($con, $row_asso['username']);
					$created = mysqli_real_escape_string($con, $row_asso['created']);
					
				?>
                  <tr>
                    <td><?php echo $created; ?></td>
                    <td><?php echo $username; ?></td>
                  </tr>
                <?php } ?>
                </tbody>
              </table>
            </div>
          </div>
        </div>	

<?php include("../footer2.php"); 
}else{
	header("Location: ../logout.php");
}
?>
