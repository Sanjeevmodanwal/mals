<?php
ob_start();
include("../db.php");
include("../header2.php");

if(!isset($_SESSION['sno'])){
    header("Location: ../admin_login");
    exit(); 
}

if(isset($_SESSION['sno']) && !empty($_SESSION['sno'])){
$sessionid = $_SESSION['sno'];
$result1 = "SELECT sno,type,sa_access FROM users WHERE sno = '$sessionid'";
$getusers = mysqli_query($con, $result1);
$rowusers = mysqli_fetch_assoc($getusers);
	$loggedid = mysqli_real_escape_string($con, $rowusers['sno']);
	$adminrole = mysqli_real_escape_string($con, $rowusers['type']);
	$sa_access = mysqli_real_escape_string($con, $rowusers['sa_access']);
}else{
	$loggedid = '';
	$adminrole = '';
	$sa_access = '';
}

if($adminrole == 'Super_admin'){
?>
<div id="wrapper">
    <?php include("../sidebar2.php"); ?>
	
    <div id="content-wrapper">
      <div class="container-fluid">
	  <div class="col-sm-12">
		<form method="post" action="all_export.php">
			<button name="alldownload" type="submit" class="btn btn-sm btn-success text-right mb-4">ALL Details Download</button>
		</form>
		</div>
		<div class="card mb-3">
          <div class="card-header">
            <i class="fas fa-table"></i>
            Users Table</div>
			
          <div class="card-body">
            <div class="table-responsive">
              <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                  <tr>
					<th>Username</th>
                    <th>Associate Name</th>
                    <th>Parent Name</th>
                    <th>Introduser Id</th>
                    <th>Position(Size-Shirt No.)</th>
                    <th>Created</th>
                    <th>Courier Details</th>
                    <th>Rcnt Login</th>
                    <th>Action</th>
                  </tr>
                </thead>
                <tbody>
				<?php 
				$resultAssociate = mysqli_query($con,"SELECT sno, associate_name, username, parent_id, sponser_id, mobile, position, size, lenght, created, shirt_delivered_date, courier_type, courier_company, courier_mobile, id_red_or_green FROM users WHERE type!='Super_admin'");
				while ($row_asso = mysqli_fetch_assoc($resultAssociate)) {
					$snoid = mysqli_real_escape_string($con, $row_asso['sno']);
					$associate_name = mysqli_real_escape_string($con, $row_asso['associate_name']);
					$sponser_id = mysqli_real_escape_string($con, $row_asso['sponser_id']);
					$parent_id = mysqli_real_escape_string($con, $row_asso['parent_id']);
					$username = mysqli_real_escape_string($con, $row_asso['username']);
					$position = mysqli_real_escape_string($con, $row_asso['position']);
					$size = mysqli_real_escape_string($con, $row_asso['size']);
					$lenght = mysqli_real_escape_string($con, $row_asso['lenght']);
					$created = mysqli_real_escape_string($con, $row_asso['created']);
					$shirt_delivered_date = mysqli_real_escape_string($con, $row_asso['shirt_delivered_date']);
					$courier_type = mysqli_real_escape_string($con, $row_asso['courier_type']);
					$courier_company = mysqli_real_escape_string($con, $row_asso['courier_company']);
					$courier_mobile = mysqli_real_escape_string($con, $row_asso['courier_mobile']);
					$id_red_or_green = mysqli_real_escape_string($con, $row_asso['id_red_or_green']);
					
					$prnt_qry = mysqli_query($con,"SELECT username FROM users where sno='$sponser_id'");					if(mysqli_num_rows($prnt_qry)){	
						 while ($row_prnt_qry = mysqli_fetch_assoc($prnt_qry)) {
						 $sponser_id_name = mysqli_real_escape_string($con, $row_prnt_qry['username']);
					}					}else{						$sponser_id_name = '';					}
					$prnt_qry1 = mysqli_query($con,"SELECT username FROM users where sno='$parent_id'");					if(mysqli_num_rows($prnt_qry1)){
						 while ($row_prnt_qry1 = mysqli_fetch_assoc($prnt_qry1)) {
						 $parent_id_name = mysqli_real_escape_string($con, $row_prnt_qry1['username']);
					}					}else{						$parent_id_name = '';					}				
					if(!empty($lenght) && !empty($size)){
						$lenght_1 = "($size - $lenght)";
					}else{
						if(!empty($lenght)){
							$lenght_1 = "($lenght)";
						}
						if(!empty($size)){
							$lenght_1 = "($size)";
						}
					}					
					if($id_red_or_green == '' || $id_red_or_green == 'red'){
						$id_btn_name = "<span class='btn btn-sm btn-danger idColorDiv' data-val='green' data-id='$snoid' id='id_btn_change$snoid' style='margin-top: 5px;float: right;width: 100%;'>Change</span>";
					}else{
						$id_btn_name = "<span class='btn btn-sm btn-success idColorDiv' data-val='red' data-id='$snoid' id='id_btn_change$snoid' style='margin-top: 5px;float: right;width: 100%;'>Change</span>";
					}
					
					$resultAssociate_1 = "SELECT created_datetime FROM login_time WHERE user_id='$snoid' order by sno desc";
					$sasasa = mysqli_query($con, $resultAssociate_1);
					$row_asso_1 = mysqli_fetch_assoc($sasasa);
					$created_datetime = mysqli_real_escape_string($con, $row_asso_1['created_datetime']);
					if(!empty($created_datetime)){
						$created_time_login = date("d/m/Y H:i:s A",strtotime($created_datetime));
					}else{
						$created_time_login = '';	
					}
				?>
                  <tr>
                    <td><?php echo $username; ?></td>
                    <td><?php echo $associate_name; ?></td>
                    <td><?php echo $parent_id_name; ?></td>
                    <td><?php echo $sponser_id_name; ?></td>
                    <td><?php echo $position.''.$lenght_1; ?></td>
                    <td><?php echo $created; ?></td>
                    <td>
					<span class="showDiv<?php echo $snoid;?>">
						<?php if(!empty($shirt_delivered_date)){ ?>
							<b>Company: </b><?php echo $courier_company; ?><br>
							<b>Mobile: </b><?php echo $courier_mobile; ?><br>
							<b>Date: </b><?php echo $shirt_delivered_date; ?><br>
							<b>Type: </b><?php echo $courier_type; 
						}else{
							echo '';
						}
						?>
					</span>
					<span class="btn btn-sm btn-warning changebtn" data-id="<?php echo $snoid;?>" id="changebtn<?php echo $snoid;?>">Change</span>
					
					<span class="inputDiv<?php echo $snoid;?>" style="display:none;">
					<input type="text" class="courier_company<?php echo $snoid;?> mb-2" placeholder="Courier Company">
					<input type="text" class="courier_mobile<?php echo $snoid;?> mb-2" placeholder="Contact Number">
					<input type="text" class="datepicker123 shirt_delivered_date<?php echo $snoid;?> mb-2" placeholder="Shirt Delivered Date">
					<select class="courier_type<?php echo $snoid;?> mb-2"><option>Select Courier Type</option><option>On the Spot</option><option>By hand</option></select>
					<button class="btn btn-sm btn-success updatebtn" data-id="<?php echo $snoid;?>">Save</button>
					</span>					
					</td>
					<td><?php echo $created_time_login; ?></td>
                    <td>
					<?php if($sa_access == 'Yes'){ ?>
					<a href="../associate/edituser.php?snoid=<?php echo base64_encode($snoid); ?>" class="btn btn-sm btn-warning" title="Edit"><i class="far fa-edit"></i></a>
					<?php }else{ ?>
					<a href="../associate/profile.php?snoid=<?php echo base64_encode($snoid); ?>" class="btn btn-sm btn-warning" title="Profile"><i class="far fa-eye"></i></a>
					<?php } ?>
                    <a href="../associate/tree_level.php?nameid=<?php echo $snoid; ?>" class="btn btn-sm btn-success" title="Tree Structure"><i class="fas fa-tree"></i></a>
                    <a href="../associate/changepassword.php?snoid=<?php echo base64_encode($snoid); ?>" class="btn btn-sm btn-danger" title="Change Password"><i class="fa fa-key"></i></a>
					<a href="../associate/payout.php?snoid=<?php echo base64_encode($snoid); ?>" class="btn btn-sm btn-success" title="Payout(Passbook)"><i class="fa fa-credit-card"></i></a>
					<?php echo $id_btn_name; ?>
					<a href="../associate/login_time.php?snoid=<?php echo base64_encode($snoid); ?>" class="btn btn-sm btn-info" title="Signin Logs"><i class="fa fa-user"></i></a>
					</td>
                  </tr>
                <?php } ?>
                </tbody>
              </table>
            </div>
          </div>
        </div>
		
<script>
$(document).on('click', '.changebtn', function(){
	var getid = $(this).attr('data-id');
	$('.inputDiv'+getid).show();
	$('.showDiv'+getid).hide();
	$('#changebtn'+getid).hide();	
});
$(document).on('click', '.updatebtn', function(){
	var getid = $(this).attr('data-id');
	var shirt_delivered_date = $('.shirt_delivered_date'+getid).val();
	var courier_type = $('.courier_type'+getid).val();
	var courier_company = $('.courier_company'+getid).val();
	var courier_mobile = $('.courier_mobile'+getid).val();
	$.post("../response.php?tag=getdelivered",{"getid":getid, "shirt_delivered_date":shirt_delivered_date, "courier_type":courier_type, "courier_company":courier_company, "courier_mobile":courier_mobile},function(d){
		if(d == '1'){
			$('.showDiv'+getid).show();
			$('.inputDiv'+getid).hide();
			$('#changebtn'+getid).show();
			var html_val = 'Company: '+courier_company+'<br>Mobile: '+courier_mobile+'<br>Date: '+shirt_delivered_date+'<br> Type: '+courier_type+'';
			$('.showDiv'+getid).html(html_val);
		}
	});
});

$(document).on('click', '.idColorDiv', function(){
	var getid = $(this).attr('data-id');
	var getval = $(this).attr('data-val');
		
	var checkstr =  confirm('Are you sure you want to change this?');
	if(checkstr == true){
		
		if(getval == 'green'){
			$('#id_btn_change'+getid).css({"color": "#fff","background-color": "green","border-color": "#bd2130"});
			$('#id_btn_change'+getid).attr('data-val', 'red');
		}
		if(getval == 'red'){
			$('#id_btn_change'+getid).css({"color": "#fff","background-color": "#c82333","border-color": "#bd2130"});
			$('#id_btn_change'+getid).attr('data-val', 'green');
		}
		$.post("../response.php?tag=getcolorChange",{"getid":getid, "getval":getval},function(d){
			
		});
	}else{
		return false;
	}
});
</script>

<?php include("../footer2.php"); 
}else{
	header("Location: ../logout.php");
}
?>
