<?php
ob_start();
include("../db.php");
include("../header2.php");

if(!isset($_SESSION['sno'])){
    header("Location: ../admin_login");
    exit(); 
}

if(isset($_SESSION['sno']) && !empty($_SESSION['sno'])){
$sessionid = $_SESSION['sno'];
$result1 = "SELECT sno,type FROM users WHERE sno = '$sessionid'";
$getusers = mysqli_query($con, $result1);
$rowusers = mysqli_fetch_assoc($getusers);
	$loggedid = mysqli_real_escape_string($con, $rowusers['sno']);
	$adminrole = mysqli_real_escape_string($con, $rowusers['type']);
}else{
	$loggedid = '';
	$adminrole = '';
}

if($adminrole == 'Super_admin'){
?>
<div id="wrapper">
    <?php include("../sidebar2.php"); ?>
	
    <div id="content-wrapper">
      <div class="container-fluid">
		
		<div class="col-sm-12  mb-3">
		<div class="row">
		<div class="col-sm-3">
			<select class="form-control spid">
				<option value="">Select Sponser Id</option>
				<?php $queryDrop = "SELECT sno,username FROM users WHERE type!='Super_admin'";
				$rsltQuery = mysqli_query($con, $queryDrop);
				while($rowstr = mysqli_fetch_array($rsltQuery)){
					$username = mysqli_real_escape_string($con, $rowstr['username']);
				?>
				<option value="<?php echo $username;?>"><?php echo $username;?></option>
				<?php } ?>
			</select>
		</div>
		<div class="col-sm-3">
				<select class="form-control bnknme">
					<option value="">Select Bank</option>
					<option value="ALLAHABAD BANK">ALLAHABAD BANK</option>
					<option value="ALLAHABAD UP GRAMIN BANK">ALLAHABAD UP GRAMIN BANK</option>
					<option value="ANDHRA BANK">ANDHRA BANK</option>
					<option value="AXIS BANK">AXIS BANK</option>
					<option value="BANDHAN BANK">BANDHAN BANK</option>
					<option value="BANGIYA GURAMIN VIKAS BANK">BANGIYA GURAMIN VIKAS BANK</option>
					<option value="BANK OF BARODA">BANK OF BARODA</option>
					<option value="BANK OF INDIA">BANK OF INDIA</option>
					<option value="BANK OF MAHARASHTRA">BANK OF MAHARASHTRA</option>
					<option value="BARODA  UTTAR PRADESH GARMIN  BANK">BARODA  UTTAR PRADESH GARMIN  BANK</option>
					<option value="BHART CO BANK">BHART CO BANK</option>
					<option value="BIHAR GRAMIN  BANK">BIHAR GRAMIN  BANK</option>
					<option value="BIHAR GRAMIN BANK">BIHAR GRAMIN BANK</option>
					<option value="CANARA BANK">CANARA BANK</option>
					<option value="CAPITAL SMALL FINANCE BANK">CAPITAL SMALL FINANCE BANK</option>
					<option value="CENTRAL BANK OF INDIA">CENTRAL BANK OF INDIA</option>
					<option value="CORPORATION BANK">CORPORATION BANK</option>
					<option value="DENA BANK">DENA BANK</option>
					<option value="DOMBIVLI NAGRI SAHAKARI BANK LTD">DOMBIVLI NAGRI SAHAKARI BANK LTD</option>
					<option value="FEDERAL BANK">FEDERAL BANK</option>
					<option value="HDFC">HDFC</option>
					<option value="ICICI BANK">ICICI BANK</option>
					<option value="IDBI BANK LIMITED">IDBI BANK LIMITED</option>
					<option value="IDFC BANK">IDFC BANK</option>
					<option value="INDIAN BANK">INDIAN BANK</option>
					<option value="INDIAN OVERSEAS BANK">INDIAN OVERSEAS BANK</option>
					<option value="INDUSIND BANK">INDUSIND BANK</option>
					<option value="KARNATKA BANK LTD.">KARNATKA BANK LTD.</option>
					<option value="KOTAK MAHINDRA BANK">KOTAK MAHINDRA BANK</option>
					<option value="MALDA  CENTRAL CO - OPERATIVE BANK">MALDA  CENTRAL CO - OPERATIVE BANK</option>
					<option value="ORIENTAL BANK OF COMMERCE">ORIENTAL BANK OF COMMERCE</option>
					<option value="PNB">PNB</option>
					<option value="PRATHAMA BANK">PRATHAMA BANK</option>
					<option value="PUNJAB AND SIND BANK">PUNJAB AND SIND BANK</option>
					<option value="RBL BANK">RBL BANK</option>
					<option value="SARSWAT BANK">SARSWAT BANK</option>
					<option value="SBI">SBI</option>
					<option value="SYNDICATE BANK">SYNDICATE BANK</option>
					<option value="UCO BANK">UCO BANK</option>
					<option value="UNION BANK">UNION BANK</option>
					<option value="UNION BANK BANK OF INDIA">UNION BANK BANK OF INDIA</option>
					<option value="UNITED BANK OF INDIA">UNITED BANK OF INDIA</option>
					<option value="VANACHAL GRAMIN BANK">VANACHAL GRAMIN BANK</option>
					<option value="VIJAY BANK">VIJAY BANK</option>
					<option value="YES BANK">YES BANK</option>
				</select>
		</div>
		<div class="col-sm-3">
		<button name="submit" type="submit" class="btn btn-sm btn-success searchAcbtn">Search</button>
		</div>
		<div class="col-sm-3 text-right">
		<form method="post" action="export_report.php">
		<input type="hidden" name="usid" class="usid" value="">
		<input type="hidden" name="ubnkname" class="ubnkname" value="">
		<button name="searchbtn" type="submit" class="btn btn-sm btn-success btnserchbnk" style="display:none;">Download Excel Sheet</button>
		</form>
		</div>
		</div>
		</div>
		<div class="card mb-3">
          <div class="card-header">
            <i class="fas fa-table"></i>
          </div>
          <div class="card-body">
            <div class="table-responsive">
              <table class="table table-bordered" width="100%" cellspacing="0">
                <thead>
                  <tr>
					<th>Username<br>(SponserId)</th>
                    <th>Account No</th>
                    <th>Account Holder Name</th>
                    <th>Bank Name</th>
                    <th>Branch Name</th>
                    <th>ifsc</th>
                    <th>Action</th>
                  </tr>
                </thead>
				<div class="showLoading"></div>
                <tbody class="resultAccountList">				
                </tbody>
              </table>
            </div>
          </div>
        </div>

<script>
$(document).on('click', '.searchAcbtn', function(){
	var sponserid = $('.spid').val();
	var bnkname = $('.bnknme').val();
	$('.showLoading').show();
	$('.usid').attr('value' ,sponserid);
	$('.ubnkname').attr('value' ,bnkname);	
	$.post("../response.php?tag=acntList",{"sponserid":sponserid, "bnkname":bnkname},function(d){		
	if(d == ""){	
		alert("Not found");
		$('.resultAccountList').html(" ");
		$('.showLoading').hide();
		$('.btnserchbnk').hide();
	}else{	
		$('.resultAccountList').html(" ");		
		$('.btnserchbnk').show();		
		for (i in d) {
			$('<tr>' +
			'<td>'+d[i].spnid+'</td>' +
			'<td>'+d[i].account_no+'</td>' +
			'<td>'+d[i].ahn+'</td>' + 
			'<td>'+d[i].bank_name+'</td>' + 
			'<td>'+d[i].branch_name+'</td>'+
			'<td>'+d[i].ifsc+'</td>'+
			'<td>'+d[i].btnedit+'</td>'+
			'</tr>').appendTo(".resultAccountList");
		}
	}
	$('.showLoading').hide();
	});
});
</script>

<?php include("../footer2.php"); 
}else{
	header("Location: ../logout.php");
}
?>
