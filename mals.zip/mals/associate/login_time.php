<?php
ob_start();
include("../db.php");
include("../header2.php");

if(!isset($_SESSION['sno'])){
    header("Location: ../admin_login");
    exit(); 
}

if(isset($_SESSION['sno']) && !empty($_SESSION['sno'])){
$sessionid = $_SESSION['sno'];
$result1 = "SELECT sno,type,sa_access FROM users WHERE sno = '$sessionid'";
$getusers = mysqli_query($con, $result1);
$rowusers = mysqli_fetch_assoc($getusers);
	$loggedid = mysqli_real_escape_string($con, $rowusers['sno']);
	$adminrole = mysqli_real_escape_string($con, $rowusers['type']);
	$sa_access = mysqli_real_escape_string($con, $rowusers['sa_access']);
}else{
	$loggedid = '';
	$sa_access = '';
}

if($adminrole == 'Super_admin'){
	
?>
<div id="wrapper">
    <?php include("../sidebar2.php"); ?>
	
    <div id="content-wrapper">
      <div class="container-fluid">
	  
		<div class="col-sm-12 mb-3">
		<div class="row">
		<div class="col-sm-6">
			<input type="text" class="form-control getvalClass" placeholder="Search by Id or Phone number">
		</div>
		<div class="col-sm-2">
			<button name="submit" type="submit" class="btn btn-sm btn-success searchAcbtn">Search Login Id</button>
		</div>
		</div>
		</div>
	  
		<div class="card mb-3">
          <div class="card-header">
            <i class="fas fa-table"></i>
            Recent Login</div>
			
          <div class="card-body">
            <div class="table-responsive">
              <table class="table table-bordered" id="dataTable_1212san" width="100%" cellspacing="0">
                <thead>
                  <tr>
					<th>Username</th>
                    <th>Associate Name</th>
                    <th>Ph. No.</th>
                    <th>Login Datetime</th>
                  </tr>
                </thead>
                <tbody class="searchResult">
				<?php
				if(!empty($_GET['snoid'])){
					$snoid_3 = base64_decode($_GET['snoid']);
					$resultAssociate = mysqli_query($con,"SELECT * FROM login_time WHERE user_id='$snoid_3' order by sno desc");
				}else{
					$resultAssociate = mysqli_query($con,"SELECT * FROM login_time order by sno desc");
				}
				
				if(mysqli_num_rows($resultAssociate)){
				while ($row_asso = mysqli_fetch_assoc($resultAssociate)) {
					$snoid = mysqli_real_escape_string($con, $row_asso['sno']);
					$associate_name = mysqli_real_escape_string($con, $row_asso['associate_name']);
					$username = mysqli_real_escape_string($con, $row_asso['username']);
					$mobile = mysqli_real_escape_string($con, $row_asso['mobile']);
					$created_datetime = mysqli_real_escape_string($con, $row_asso['created_datetime']);
					$created_datetime_1 = date("d/m/Y H:i:s A",strtotime($created_datetime));
					
				?>
                  <tr>
                    <td><?php echo $username; ?></td>
                    <td><?php echo $associate_name; ?></td>
                    <td><?php echo $mobile; ?></td>
                    <td><?php echo $created_datetime_1; ?></td>
                  </tr>
                <?php }
				}else{
				?>
				<tr>			
				<td colspan="4" style="text-align:center;color:red;">Not Found Logs</td>
				</tr>
				<?php }	?>
                </tbody>
              </table>
            </div>
          </div>
        </div>
		
<script>
$(document).on('click', '.searchAcbtn', function(){
	var getvalClass = $('.getvalClass').val();
	$('.showLoading').show();
	$.post("../response.php?tag=logsList",{"getval":getvalClass},function(d){		
	if(d == ""){	
		alert("Not Found Logs");
		$('.searchResult').html(" ");
		$('.showLoading').hide();
	}else{
		$('.searchResult').html(" ");
		for (i in d) {
			$('<tr class="delsno'+d[i].snoid+'">' +
			'<td>'+d[i].username+'</td>' + 
			'<td>'+d[i].associate_name+'</td>' +
			'<td>'+d[i].mobile+'</td>' +
			'<td>'+d[i].created+'</td>' +
			'</tr>').appendTo(".searchResult");
		}
	}
	});	
	$('.showLoading').hide();	
});


</script>
<?php include("../footer2.php"); 
}else{
	header("Location: ../logout.php");
}
?>
