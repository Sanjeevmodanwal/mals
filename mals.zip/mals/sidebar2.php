<!-- Sidebar -->
    <ul class="sidebar navbar-nav">	
<?php if($rolegt == 'Super_admin'){ 
	$randomMALS = base64_encode(rand());
?>
      <li class="nav-item active">
        <a class="nav-link" href="../dashboard">
          <i class="fas fa-fw fa-tachometer-alt"></i>
          <span>Dashboard</span>
        </a>
      </li>	  	  <li class="nav-item active">        <a class="nav-link" href="../shop"  target="_blank">          <i class='fas fa-shopping-cart'></i>          <span>Go to Products</span>        </a>      </li>	  	  <li class="nav-item">        <a class="nav-link" href="../products">          <i class='fas fa-shopping-basket'></i>          <span>Products List</span>        </a>      </li>	  	  <li class="nav-item">        <a class="nav-link" href="../products/add_edit.php?snopid=&<?php echo $randomMALS;?>">          <i class="fas fa-shopping-bag"></i>          <span>New Product Add</span>        </a>      </li>	  	  <li class="nav-item">        <a class="nav-link" href="../products/cat_index.php?snopid=&<?php echo $randomMALS;?>">          <i class="fas fa-shopping-bag"></i>          <span>Product Categories</span>        </a>      </li>	 
      <!--li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="pagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          <i class="fas fa-fw fa-folder"></i>
          <span>Pages</span>
        </a>
        <div class="dropdown-menu" aria-labelledby="pagesDropdown">
          <h6 class="dropdown-header">Login Screens:</h6>
          <a class="dropdown-item" href="login.html">Login</a>
          <a class="dropdown-item" href="register.html">Register</a>
          <a class="dropdown-item" href="forgot-password.html">Forgot Password</a>
          <div class="dropdown-divider"></div>
          <h6 class="dropdown-header">Other Pages:</h6>
          <a class="dropdown-item" href="404.html">404 Page</a>
          <a class="dropdown-item" href="blank.html">Blank Page</a>
        </div>
      </li-->
      <li class="nav-item">
        <a class="nav-link" href="../associate">
          <i class="fas fa-fw fa-users"></i>
          <span>Total Users</span></a>
      </li>
	  <li class="nav-item">
        <a class="nav-link" href="../associate/index_descorder.php?<?php echo $randomMALS;?>">
          <i class="fas fa-fw fa-users"></i>
          <span>Recent Add Users</span></a>
      </li>
	  <li class="nav-item">
        <a class="nav-link" href="../associate/adduser.php">
          <i class="fas fa-fw fa-user"></i>
          <span>New Add</span></a>
      </li>
	  <li class="nav-item">
        <a class="nav-link" href="../associate/search.php">
          <i class="fas fa-fw fa-user"></i>
          <span>Search Account Details</span></a>
      </li>
	  <li class="nav-item">
        <a class="nav-link" href="../associate/payout.php?snoid=">
          <i class="fas fa-credit-card"></i>
          <span>Payout</span></a>
      </li>
	  
	  <li class="nav-item">
        <a class="nav-link" href="../associate/delete_id.php">
          <i class="fas fa-credit-card"></i>
          <span>Delete Id</span></a>
      </li>
	  
	  <li class="nav-item">
        <a class="nav-link" href="../associate/login_time.php?snoid=&<?php echo $randomMALS;?>">
          <i class="fas fa-credit-card"></i>
          <span>Recent Login</span></a>
      </li>
	   
<?php } 
if($rolegt == 'Admin'){ ?>
	<li class="nav-item active">
        <a class="nav-link" href="../dashboardag">
          <i class="fas fa-fw fa-tachometer-alt"></i>
          <span>Dashboard</span>
        </a>
    </li>		<li class="nav-item active">        <a class="nav-link" href="../shop" target="_blank">		<i class='fas fa-shopping-cart'></i>          <span>Go to Products</span>        </a>      </li>
	<li class="nav-item">
        <a class="nav-link" href="../associateag">
          <i class="fas fa-fw fa-users"></i>
          <span>Associate</span></a>
    </li>
	<?php if($username12 == 'mals_admin'){ ?>
	<li class="nav-item">
        <a class="nav-link" href="../associateag/adduser.php">
          <i class="fas fa-fw fa-user"></i>
          <span>New Add</span></a>
    </li>
	<?php } ?>
	<li class="nav-item">
        <a class="nav-link" href="../associateag/tree.php">
          <i class="fas fa-fw fa-user"></i>
          <span>Structure Chart</span></a>
    </li>
	<!--li class="nav-item">
        <a class="nav-link" href="../associateag/totalteam.php">
          <i class="fas fa-fw fa-user"></i>
          <span>Total Team</span></a>
    </li-->
	<li class="nav-item">
        <a class="nav-link" href="../associateag/payout.php">
          <i class="fas fa-credit-card"></i>
          <span>Passbook</span></a>
      </li>

<?php } ?>
    </ul>