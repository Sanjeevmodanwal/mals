<?php
ob_start();
include 'db.php';
if(!isset($_SESSION)){
	 session_start();
}
date_default_timezone_set("Asia/Kolkata");
if(isset($_SESSION['sno']) && !empty($_SESSION['sno'])){
$uname = $_SESSION['sno'];
$result = mysqli_query($con,"SELECT sno,type FROM users WHERE sno = '$uname'");
while ($row = mysqli_fetch_assoc($result)){
   $agntid = mysqli_real_escape_string($con, $row['sno']);
   $type = mysqli_real_escape_string($con, $row['type']);
   $created = date('Y-m-d H:i:s');
}
}else{
	$agntid = '';
	$type = '';
	$created = '';
}


if(isset($_POST['addsbmtbtn'])){	
	$associate_name1 = $_POST['associate_name'];
	$parent_id1 = $_POST['parent_id'];	
	$get_parent_id1 = mysqli_query($con, "SELECT sno FROM users where username='$parent_id1'");
	$get_parent_id_qry1 = mysqli_fetch_assoc($get_parent_id1);		
	$parent_id = $get_parent_id_qry1['sno'];	
	$sponser_id = $_POST['sponser_id'];
	$position = $_POST['position'];
	$username = $_POST['username'];
	$mobile = $_POST['mobile'];
	$email_address = $_POST['email_address'];
	$lenght = $_POST['lenght'];
	$size = $_POST['size'];
	$gstin_no = $_POST['gstin_no'];
	$password = md5(sha1($_POST['password']));
	$orgpass = $_POST['password'];
	$associate_address = $_POST['associate_address'];
	$country = $_POST['country'];
	$state = $_POST['state'];
	$city = $_POST['city'];
	$pin_code = $_POST['pin_code'];
	$dob = $_POST['dob'];
	$nominee_name = $_POST['nominee_name'];
	$nominee_age = $_POST['nominee_age'];
	$nominee_relation = $_POST['nominee_relation'];
	$account_holder_name = $_POST['account_holder_name'];
	$bank_name = $_POST['bank_name'];
	$branch_name = $_POST['branch_name'];
	$ifsc = $_POST['ifsc'];
	$pan_card_no = $_POST['pan_card_no'];
	$adhar_no = $_POST['adhar_no'];
	$account_no = $_POST['account_no'];
	$addsbmtbtn = $_POST['addsbmtbtn'];
	
	$get_parent_id = mysqli_query($con, "SELECT sno FROM users where username='$sponser_id'");
	$get_parent_id_qry = mysqli_fetch_assoc($get_parent_id);		
	$sponser_id_get = $get_parent_id_qry['sno'];
	
	$associate_name = str_replace(' ', '', $associate_name1);
	
	$name_upload_pan = $_FILES['upload_pan']['name'];
	$tmp_upload_pan = $_FILES['upload_pan']['tmp_name'];	
	if($name_upload_pan == ''){	
		$img_name = '';		
	}else{
		$extension = pathinfo($name_upload_pan, PATHINFO_EXTENSION);
		$img_name = 'PAN'.'_'.$associate_name.'_'.date('is').'.'.$extension;
		move_uploaded_file($tmp_upload_pan, 'uploads/'.$img_name);
	}
	
	$name_upload_aadhar_front = $_FILES['upload_aadhar_front']['name'];
	$tmp_upload_aadhar_front = $_FILES['upload_aadhar_front']['tmp_name'];	
	if($name_upload_aadhar_front == ''){	
		$img_name2 = '';		
	}else{
		$extension2 = pathinfo($name_upload_aadhar_front, PATHINFO_EXTENSION);
		$img_name2 = 'Aadhar_fornt'.'_'.$associate_name.'_'.date('is').'.'.$extension2;
		move_uploaded_file($tmp_upload_aadhar_front, 'uploads/'.$img_name2);
	}
	
	$name_upload_aadhar_back = $_FILES['upload_aadhar_back']['name'];
	$tmp_upload_aadhar_back = $_FILES['upload_aadhar_back']['tmp_name'];	
	if($name_upload_aadhar_back == ''){	
		$img_name3 = '';		
	}else{
		$extension3 = pathinfo($name_upload_aadhar_back, PATHINFO_EXTENSION);
		$img_name3 = 'Aadhar_back'.'_'.$associate_name.'_'.date('is').'.'.$extension3;
		move_uploaded_file($tmp_upload_aadhar_back, 'uploads/'.$img_name3);
	}
	
	$name_associate_image = $_FILES['associate_image']['name'];
	$tmp_associate_image = $_FILES['associate_image']['tmp_name'];	
	if($name_associate_image == ''){	
		$img_name4 = '';		
	}else{
		$extension4 = pathinfo($name_associate_image, PATHINFO_EXTENSION);
		$img_name4 = 'Associate_Image'.'_'.$associate_name.'_'.date('is').'.'.$extension4;
		move_uploaded_file($tmp_associate_image, 'uploads/'.$img_name4);
	}
	
    $assoQuery = "INSERT INTO `users` (`type`, `parent_id`, `sponser_id`, `position`, `associate_name`, `username`, `password`, `orgpass`, `mobile`, `email_address`, `gstin_no`, `associate_address`, `country`, `state`, `city`, `pin_code`, `dob`, `lenght`, `size`, `nominee_name`, `nominee_age`, `nominee_relation`, `account_no`, `account_holder_name`, `bank_name`, `branch_name`, `ifsc`, `pan_card_no`, `adhar_no`, `upload_pan`, `upload_aadhar_front`, `upload_aadhar_back`, `associate_image`, `created`, `status`) VALUES ('Admin', '$parent_id', '$sponser_id_get', '$position', '$associate_name', '$username', '$password', '$orgpass', '$mobile', '$email_address', '$gstin_no', '$associate_address', '$country', '$state', '$city', '$pin_code', '$dob', '$lenght', '$size', '$nominee_name', '$nominee_age', '$nominee_relation', '$account_no', '$account_holder_name', '$bank_name', '$branch_name', '$ifsc', '$pan_card_no', '$adhar_no', '$img_name', '$img_name2', '$img_name3', '$img_name4', '$created', '1')";
	mysqli_query($con, $assoQuery);	
	
	$m1 = "Dear $associate_name";
	$m2 = "<p>Welcome in Mals</p>";
	$m3 = "<p>Your Login Details is: </p>";
	$m4 = "<table>
	<tr><th>Your Id</th><td>$username</td></tr>
	<tr><th>Password</th><td>$orgpass</td></tr>
	</table>";
	$m5 = "<p>Thanks & Regards</p>";
	$m6 = "<p>MALS Team</p>";
	$m7 = "<p>Website : www.mals.co.in</p>";
	
	$body = $m1.''.$m2.''.$m3.''.$m4.''.$m5.''.$m6.''.$m7;
	
	$headers = "MIME-Version: 1.0" . "\r\n";
	$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";	
	$subject = "Register Id - MALS";
	$to = $email_address;	
	$headers .= 'From: MALS <support@mals.co.in>' . "\r\n";	
	mail($to,$subject,$body,$headers);
	
	header("Location: associate?msg=successfully");	
}

if(isset($_POST['editsbmtbtn'])){
	// print_r($_POST);
	// die;
	$associate_name1 = $_POST['associate_name'];
	$parent_id = $_POST['parent_id'];
	$sponser_id = $_POST['sponser_id'];
	$position = $_POST['position'];
	$mobile = $_POST['mobile'];
	$email_address = $_POST['email_address'];
	$gstin_no = $_POST['gstin_no'];
	// $password = md5(sha1($_POST['password']));
	// $orgpass = $_POST['password'];
	$associate_address = $_POST['associate_address'];
	$country = $_POST['country'];
	$state = $_POST['state'];
	$city = $_POST['city'];
	$pin_code = $_POST['pin_code'];
	$dob = $_POST['dob'];
	$size = $_POST['size'];
	$lenght = $_POST['lenght'];
	$nominee_name = $_POST['nominee_name'];
	$nominee_age = $_POST['nominee_age'];
	$nominee_relation = $_POST['nominee_relation'];
	$account_holder_name = $_POST['account_holder_name'];
	$bank_name = $_POST['bank_name'];
	$branch_name = $_POST['branch_name'];
	$ifsc = $_POST['ifsc'];
	$pan_card_no = $_POST['pan_card_no'];
	$adhar_no = $_POST['adhar_no'];
	$account_no = $_POST['account_no'];
	$snoEdit = $_POST['snoEdit'];
	$btnname = $_POST['btnname'];
	$created1 = $_POST['created'];
	$created = $created1.' '.date('H:i:s');
	
	if($btnname == 'profileEdit'){
		$get_parent_id = mysqli_query($con, "SELECT sno FROM users where username='$parent_id'");
		$get_parent_id_qry = mysqli_fetch_assoc($get_parent_id);		
		$parent_id_get = $get_parent_id_qry['sno'];
	}else{
		$parent_id_get = $parent_id;	
	}
	
	$get_sponser_id = mysqli_query($con, "SELECT sno FROM users where username='$sponser_id'");
	$get_sponser_id_qry = mysqli_fetch_assoc($get_sponser_id);		
	$sponser_id_get = $get_sponser_id_qry['sno'];	
	
	$associate_name = str_replace(' ', '', $associate_name1);
	
	$delete_foldr=mysqli_query($con, "SELECT upload_pan,upload_aadhar_front,upload_aadhar_back,associate_image FROM users where sno='$snoEdit'");
	$dltlist = mysqli_fetch_assoc($delete_foldr);		
	$upload_pan1 = $dltlist['upload_pan'];
	$upload_aadhar_front1 = $dltlist['upload_aadhar_front'];
	$upload_aadhar_back1 = $dltlist['upload_aadhar_back'];
	$associate_image1 = $dltlist['associate_image'];	
	
	$name_upload_pan = $_FILES['upload_pan']['name'];
	$tmp_upload_pan = $_FILES['upload_pan']['tmp_name'];	
	if($name_upload_pan == ''){
	if(!empty($upload_pan1)){
		$img_name = $upload_pan1;
	}else{
		$img_name = '';
	}				
	}else{
		if(!empty($upload_pan1)){
			unlink("uploads/$upload_pan1");
		}
		$extension = pathinfo($name_upload_pan, PATHINFO_EXTENSION);
		$img_name = 'PAN'.'_'.$associate_name.'_'.date('is').'.'.$extension;
		move_uploaded_file($tmp_upload_pan, 'uploads/'.$img_name);
	}
	
	$name_upload_aadhar_front = $_FILES['upload_aadhar_front']['name'];
	$tmp_upload_aadhar_front = $_FILES['upload_aadhar_front']['tmp_name'];	
	if($name_upload_aadhar_front == ''){	
	if(!empty($upload_aadhar_front1)){
		$img_name2 = $upload_aadhar_front1;
	}else{
		$img_name2 = '';
	}	
	}else{
		if(!empty($upload_aadhar_front1)){
			unlink("uploads/$upload_aadhar_front1");
		}
		$extension2 = pathinfo($name_upload_aadhar_front, PATHINFO_EXTENSION);
		$img_name2 = 'Aadhar_fornt'.'_'.$associate_name.'_'.date('is').'.'.$extension2;
		move_uploaded_file($tmp_upload_aadhar_front, 'uploads/'.$img_name2);
	}
	
	$name_upload_aadhar_back = $_FILES['upload_aadhar_back']['name'];
	$tmp_upload_aadhar_back = $_FILES['upload_aadhar_back']['tmp_name'];	
	if($name_upload_aadhar_back == ''){	
	if(!empty($upload_aadhar_back1)){
		$img_name3 = $upload_aadhar_back1;
	}else{
		$img_name3 = '';
	}		
	}else{
		if(!empty($upload_aadhar_back1)){
			unlink("uploads/$upload_aadhar_back1");
		}
		$extension3 = pathinfo($name_upload_aadhar_back, PATHINFO_EXTENSION);
		$img_name3 = 'Aadhar_back'.'_'.$associate_name.'_'.date('is').'.'.$extension3;
		move_uploaded_file($tmp_upload_aadhar_back, 'uploads/'.$img_name3);
	}
	
	$name_associate_image = $_FILES['associate_image']['name'];
	$tmp_associate_image = $_FILES['associate_image']['tmp_name'];	
	if($name_associate_image == ''){	
	if(!empty($associate_image1)){
		$img_name4 = $associate_image1;
	}else{
		$img_name4 = '';
	}	
	}else{
		if(!empty($associate_image1)){
			unlink("uploads/$associate_image1");
		}
		$extension4 = pathinfo($name_associate_image, PATHINFO_EXTENSION);
		$img_name4 = 'Associate_Image'.'_'.$associate_name.'_'.date('is').'.'.$extension4;
		move_uploaded_file($tmp_associate_image, 'uploads/'.$img_name4); 
	}
	
	$update2 = "update `users` set `associate_name`='$associate_name',`parent_id`='$parent_id_get',`sponser_id`='$sponser_id_get',`position`='$position',`mobile`='$mobile',`email_address`='$email_address',`gstin_no`='$gstin_no',`associate_address`='$associate_address',`country`='$country',`state`='$state',`city`='$city',`pin_code`='$pin_code',`dob`='$dob',`lenght`='$lenght',`size`='$size',`nominee_name`='$nominee_name',`nominee_age`='$nominee_age',`nominee_relation`='$nominee_relation',`account_no`='$account_no',`account_holder_name`='$account_holder_name',`bank_name`='$bank_name',`branch_name`='$branch_name',`ifsc`='$ifsc',`pan_card_no`='$pan_card_no',`adhar_no`='$adhar_no',`upload_pan`='$img_name',`upload_aadhar_front`='$img_name2',`upload_aadhar_back`='$img_name3',`associate_image`='$img_name4', `created`='$created' where `sno`='$snoEdit'";
	mysqli_query($con, $update2); 
	$snoid = base64_encode($snoEdit);	
	if($btnname == 'profileEdit'){
		header("Location: associateag/profile.php?snoid=$snoid&msg=successfully");
	}else{
		header("Location: associate/?msg=successfully");
	}
}


if(isset($_POST['addsbmtbtn_agent'])){
	$associate_name1 = $_POST['associate_name'];
	$parent_id1 = $_POST['parent_id'];
	$get_parent_id = mysqli_query($con, "SELECT sno FROM users where username='$parent_id1'");
	$get_parent_id_qry = mysqli_fetch_assoc($get_parent_id);		
	$parent_id = $get_parent_id_qry['sno'];	
	
	$sponser_id1 = $_POST['sponser_id'];
	$get_parent_id1 = mysqli_query($con, "SELECT sno FROM users where username='$sponser_id1'");
	$get_parent_id_qry1 = mysqli_fetch_assoc($get_parent_id1);		
	$sponser_id = $get_parent_id_qry1['sno'];
	
	$position = $_POST['position'];
	$username = $_POST['username'];
	$mobile = $_POST['mobile'];
	$email_address = $_POST['email_address'];
	$lenght = $_POST['lenght'];
	$size = $_POST['size'];
	$gstin_no = $_POST['gstin_no'];
	$password = md5(sha1($_POST['password']));
	$orgpass = $_POST['password'];
	$associate_address = $_POST['associate_address'];
	$country = $_POST['country'];
	$state = $_POST['state'];
	$city = $_POST['city'];
	$pin_code = $_POST['pin_code'];
	$dob = $_POST['dob'];
	$nominee_name = $_POST['nominee_name'];
	$nominee_age = $_POST['nominee_age'];
	$nominee_relation = $_POST['nominee_relation'];
	$account_holder_name = $_POST['account_holder_name'];
	$bank_name = $_POST['bank_name'];
	$branch_name = $_POST['branch_name'];
	$ifsc = $_POST['ifsc'];
	$pan_card_no = $_POST['pan_card_no'];
	$adhar_no = $_POST['adhar_no'];
	// $occupation = $_POST['occupation'];
	$account_no = $_POST['account_no'];
	// $policy_no = $_POST['policy_no'];
	$addsbmtbtn = $_POST['addsbmtbtn'];
	
	$associate_name = str_replace(' ', '', $associate_name1);
	
	$name_upload_pan = $_FILES['upload_pan']['name'];
	$tmp_upload_pan = $_FILES['upload_pan']['tmp_name'];	
	if($name_upload_pan == ''){	
		$img_name = '';		
	}else{
		$extension = pathinfo($name_upload_pan, PATHINFO_EXTENSION);
		$img_name = 'PAN'.'_'.$associate_name.'_'.date('is').'.'.$extension;
		move_uploaded_file($tmp_upload_pan, 'uploads/'.$img_name);
	}
	
	$name_upload_aadhar_front = $_FILES['upload_aadhar_front']['name'];
	$tmp_upload_aadhar_front = $_FILES['upload_aadhar_front']['tmp_name'];	
	if($name_upload_aadhar_front == ''){	
		$img_name2 = '';		
	}else{
		$extension2 = pathinfo($name_upload_aadhar_front, PATHINFO_EXTENSION);
		$img_name2 = 'Aadhar_fornt'.'_'.$associate_name.'_'.date('is').'.'.$extension2;
		move_uploaded_file($tmp_upload_aadhar_front, 'uploads/'.$img_name2);
	}
	
	$name_upload_aadhar_back = $_FILES['upload_aadhar_back']['name'];
	$tmp_upload_aadhar_back = $_FILES['upload_aadhar_back']['tmp_name'];	
	if($name_upload_aadhar_back == ''){	
		$img_name3 = '';		
	}else{
		$extension3 = pathinfo($name_upload_aadhar_back, PATHINFO_EXTENSION);
		$img_name3 = 'Aadhar_back'.'_'.$associate_name.'_'.date('is').'.'.$extension3;
		move_uploaded_file($tmp_upload_aadhar_back, 'uploads/'.$img_name3);
	}
	
	$name_associate_image = $_FILES['associate_image']['name'];
	$tmp_associate_image = $_FILES['associate_image']['tmp_name'];	
	if($name_associate_image == ''){	
		$img_name4 = '';		
	}else{
		$extension4 = pathinfo($name_associate_image, PATHINFO_EXTENSION);
		$img_name4 = 'Associate_Image'.'_'.$associate_name.'_'.date('is').'.'.$extension4;
		move_uploaded_file($tmp_associate_image, 'uploads/'.$img_name4);
	}
	
	// $name_associate_sign = $_FILES['associate_sign']['name'];
	// $tmp_associate_sign = $_FILES['associate_sign']['tmp_name'];	
	// if($name_associate_sign == ''){	
		// $img_name5 = '';		
	// }else{
		// $extension5 = pathinfo($name_associate_sign, PATHINFO_EXTENSION);
		// $img_name5 = 'Associate_Sign'.'_'.$associate_name.'_'.date('is').'.'.$extension5;
		// move_uploaded_file($tmp_associate_sign, 'uploads/'.$img_name5);
	// }
	
	$assoQuery = "INSERT INTO `users` (`type`, `parent_id`, `sponser_id`, `position`, `associate_name`, `username`, `password`, `orgpass`, `mobile`, `email_address`, `gstin_no`, `associate_address`, `country`, `state`, `city`, `pin_code`, `dob`, `lenght`, `size`, `nominee_name`, `nominee_age`, `nominee_relation`, `account_no`, `account_holder_name`, `bank_name`, `branch_name`, `ifsc`, `pan_card_no`, `adhar_no`, `upload_pan`, `upload_aadhar_front`, `upload_aadhar_back`, `associate_image`, `created`, `status`) VALUES ('Admin', '$parent_id', '$sponser_id', '$position', '$associate_name', '$username', '$password', '$orgpass', '$mobile', '$email_address', '$gstin_no', '$associate_address', '$country', '$state', '$city', '$pin_code', '$dob', '$lenght', '$size', '$nominee_name', '$nominee_age', '$nominee_relation', '$account_no', '$account_holder_name', '$bank_name', '$branch_name', '$ifsc', '$pan_card_no', '$adhar_no', '$img_name', '$img_name2', '$img_name3', '$img_name4', '$created', '1')";
	mysqli_query($con, $assoQuery);
	
	$m1 = "Dear $associate_name";
	$m2 = "<p>Welcome in Mals.</p>";
	$m3 = "<p>Your Login Details is: </p>";
	$m4 = "<table>
	<tr><th>Your Id</th><td>$username</td></tr>
	<tr><th>Password</th><td>$orgpass</td></tr>
	</table>";
	$m5 = "<p>Thanks & Regards</p>";
	$m6 = "<p>MALS Team</p>";
	$m7 = "<p>Website : www.mals.co.in</p>";
	
	$body = $m1.''.$m2.''.$m3.''.$m4.''.$m5.''.$m6.''.$m7;
	
	$headers = "MIME-Version: 1.0" . "\r\n";
	$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";	
	$subject = "Register Id - MALS";
	$to = $email_address;	
	$headers .= 'From: MALS <support@mals.co.in>' . "\r\n";	
	mail($to,$subject,$body,$headers);	
	
	header("Location: associateag?msg=successfully");	
}


if(isset($_POST['editsbmtbtn_agent'])){
	$associate_name1 = $_POST['associate_name'];
	$parent_id = $_POST['parent_id'];
	$mobile = $_POST['mobile'];
	$email_address = $_POST['email_address'];
	$gstin_no = $_POST['gstin_no'];
	// $password = md5(sha1($_POST['password']));
	// $orgpass = $_POST['password'];
	$associate_address = $_POST['associate_address'];
	$country = $_POST['country'];
	$state = $_POST['state'];
	$city = $_POST['city'];
	$pin_code = $_POST['pin_code'];
	$dob = $_POST['dob'];
	$size = $_POST['size'];
	$lenght = $_POST['lenght'];
	$nominee_name = $_POST['nominee_name'];
	$nominee_age = $_POST['nominee_age'];
	$nominee_relation = $_POST['nominee_relation'];
	$account_holder_name = $_POST['account_holder_name'];
	$bank_name = $_POST['bank_name'];
	$branch_name = $_POST['branch_name'];
	$ifsc = $_POST['ifsc'];
	$pan_card_no = $_POST['pan_card_no'];
	$adhar_no = $_POST['adhar_no'];
	$occupation = $_POST['occupation'];
	$account_no = $_POST['account_no'];
	$policy_no = $_POST['policy_no'];
	$snoEdit = $_POST['snoEdit'];
	
	$associate_name = str_replace(' ', '', $associate_name1);
	
	$delete_foldr=mysqli_query($con, "SELECT upload_pan,upload_aadhar_front,upload_aadhar_back,associate_image,associate_sign FROM users where sno='$snoEdit'");
	$dltlist = mysqli_fetch_assoc($delete_foldr);		
	$upload_pan1 = $dltlist['upload_pan'];
	$upload_aadhar_front1 = $dltlist['upload_aadhar_front'];
	$upload_aadhar_back1 = $dltlist['upload_aadhar_back'];
	$associate_image1 = $dltlist['associate_image'];
	$associate_sign1 = $dltlist['associate_sign'];	
	
	$name_upload_pan = $_FILES['upload_pan']['name'];
	$tmp_upload_pan = $_FILES['upload_pan']['tmp_name'];	
	if($name_upload_pan == ''){
	if(!empty($upload_pan1)){
		$img_name = $upload_pan1;
	}else{
		$img_name = '';
	}				
	}else{
		if(!empty($upload_pan1)){
			unlink("uploads/$upload_pan1");
		}
		$extension = pathinfo($name_upload_pan, PATHINFO_EXTENSION);
		$img_name = 'PAN'.'_'.$associate_name.'_'.date('is').'.'.$extension;
		move_uploaded_file($tmp_upload_pan, 'uploads/'.$img_name);
	}
	
	$name_upload_aadhar_front = $_FILES['upload_aadhar_front']['name'];
	$tmp_upload_aadhar_front = $_FILES['upload_aadhar_front']['tmp_name'];	
	if($name_upload_aadhar_front == ''){	
	if(!empty($upload_aadhar_front1)){
		$img_name2 = $upload_aadhar_front1;
	}else{
		$img_name2 = '';
	}	
	}else{
		if(!empty($upload_aadhar_front1)){
			unlink("uploads/$upload_aadhar_front1");
		}
		$extension2 = pathinfo($name_upload_aadhar_front, PATHINFO_EXTENSION);
		$img_name2 = 'Aadhar_fornt'.'_'.$associate_name.'_'.date('is').'.'.$extension2;
		move_uploaded_file($tmp_upload_aadhar_front, 'uploads/'.$img_name2);
	}
	
	$name_upload_aadhar_back = $_FILES['upload_aadhar_back']['name'];
	$tmp_upload_aadhar_back = $_FILES['upload_aadhar_back']['tmp_name'];	
	if($name_upload_aadhar_back == ''){	
	if(!empty($upload_aadhar_back1)){
		$img_name3 = $upload_aadhar_back1;
	}else{
		$img_name3 = '';
	}		
	}else{
		if(!empty($upload_aadhar_back1)){
			unlink("uploads/$upload_aadhar_back1");
		}
		$extension3 = pathinfo($name_upload_aadhar_back, PATHINFO_EXTENSION);
		$img_name3 = 'Aadhar_back'.'_'.$associate_name.'_'.date('is').'.'.$extension3;
		move_uploaded_file($tmp_upload_aadhar_back, 'uploads/'.$img_name3);
	}
	
	$name_associate_image = $_FILES['associate_image']['name'];
	$tmp_associate_image = $_FILES['associate_image']['tmp_name'];	
	if($name_associate_image == ''){	
	if(!empty($associate_image1)){
		$img_name4 = $associate_image1;
	}else{
		$img_name4 = '';
	}	
	}else{
		if(!empty($associate_image1)){
			unlink("uploads/$associate_image1");
		}
		$extension4 = pathinfo($name_associate_image, PATHINFO_EXTENSION);
		$img_name4 = 'Associate_Image'.'_'.$associate_name.'_'.date('is').'.'.$extension4;
		move_uploaded_file($tmp_associate_image, 'uploads/'.$img_name4);
	}
	
	$name_associate_sign = $_FILES['associate_sign']['name'];
	$tmp_associate_sign = $_FILES['associate_sign']['tmp_name'];	
	if($name_associate_sign == ''){	
	if(!empty($associate_sign1)){
		$img_name5 = $associate_sign1;
	}else{
		$img_name5 = '';
	}		
	}else{
		if(!empty($associate_sign1)){
			unlink("uploads/$associate_sign1");
		}
		$extension5 = pathinfo($name_associate_sign, PATHINFO_EXTENSION);
		$img_name5 = 'Associate_Sign'.'_'.$associate_name.'_'.date('is').'.'.$extension5;
		move_uploaded_file($tmp_associate_sign, 'uploads/'.$img_name5);
	}
	
	$update2 = "update `users` set `associate_name`='$associate_name',`parent_id`='$parent_id',`mobile`='$mobile',`email_address`='$email_address',`gstin_no`='$gstin_no',`associate_address`='$associate_address',`country`='$country',`state`='$state',`city`='$city',`pin_code`='$pin_code',`dob`='$dob',`lenght`='$lenght',`size`='$size',`nominee_name`='$nominee_name',`nominee_age`='$nominee_age',`nominee_relation`='$nominee_relation',`account_no`='$account_no',`account_holder_name`='$account_holder_name',`bank_name`='$bank_name',`branch_name`='$branch_name',`ifsc`='$ifsc',`pan_card_no`='$pan_card_no',`adhar_no`='$adhar_no',`occupation`='$occupation',`policy_no`='$policy_no',`upload_pan`='$img_name',`upload_aadhar_front`='$img_name2',`upload_aadhar_back`='$img_name3',`associate_image`='$img_name4',`associate_sign`='$img_name5' where `sno`='$snoEdit'";
	mysqli_query($con, $update2); 
	$snoid = base64_encode($snoEdit);
	header("Location: associateag?$snoid&msg=successfully");	
}


if(isset($_POST['btnpayinsert'])){
	$level = $_POST['level'];
	$income = $_POST['income'];
	$amount = $_POST['amount'];
	$user_sno = $_POST['user_sno'];
	
	$rslt_payout = "SELECT * FROM payout_passbook_list WHERE user_id = '$user_sno' AND level = '$level' AND income_name = '$income'";
	$qry_rslt = mysqli_query($con, $rslt_payout);
	$rowpayout = mysqli_fetch_assoc($qry_rslt);
	$id = $rowpayout['sno'];
	if(mysqli_num_rows($qry_rslt)){
		$update2 = "update `payout_passbook_list` set `amount`='$amount', `datetime`='$created' where `sno`='$id'";
		mysqli_query($con, $update2);
		
		$snoid = base64_encode($user_sno);
		header("Location: associate/payout.php?snoid=$snoid");
		
	}else{
		if(!empty($user_sno)){
			$queyFind = "INSERT INTO `payout_passbook_list` (`user_id`, `level`, `income_name`, `amount`, `datetime`) VALUES ('$user_sno', '$level', '$income', '$amount', '$created')";
			$get_query = mysqli_query($con, $queyFind);	
			
			$snoid = base64_encode($user_sno);
			header("Location: associate/payout.php?snoid=$snoid");
			
		}else{
			header("Location: associate/payout.php?success=not_found&snoid=");
		}
	}
}

if(isset($_POST['btnsignup'])){
	$associate_name = $_POST['associate_name'];	
	
	// $parent_id1 = $_POST['parent_id'];
	// $get_parent_id = mysqli_query($con, "SELECT sno FROM users where username='$parent_id1'");
	// $get_parent_id_qry = mysqli_fetch_assoc($get_parent_id);		
	// $parent_id = $get_parent_id_qry['sno'];	
	
	$sponser_id1 = $_POST['sponser_id'];
	$get_parent_id1 = mysqli_query($con, "SELECT sno FROM users where username='$sponser_id1'");
	$get_parent_id_qry1 = mysqli_fetch_assoc($get_parent_id1);		
	$sponser_id = $get_parent_id_qry1['sno'];
	
	// $position = $_POST['position'];
	$username = $_POST['username'];
	$password = $_POST['password'];
	$password1 = md5(sha1($password));
	$mobile = $_POST['mobile'];
	$email_address = $_POST['email_address'];
	$associate_address = $_POST['associate_address'];
	$state = $_POST['state'];
	$created = date('Y-m-d H:i:s');
	$fourdigitrandom = rand(1000,9999);
	
	$queyFind = "INSERT INTO `users` (type, `associate_name`, `sponser_id`, `username`, password, orgpass, mobile, email_address, associate_address, state, otp, created) VALUES ('Admin', '$associate_name', '$sponser_id', '$username', '$password1', '$password', '$mobile', '$email_address', '$associate_address', '$state', '$fourdigitrandom', '$created')";
	$get_query = mysqli_query($con, $queyFind);
	$last_insert_id = mysqli_insert_id($con);
	
	$m1 = "Dear $associate_name";
	$m2 = "<p>Welcome in Mals</p>";
	$m3 = "<p>Your Login Details is: </p>";
	$m4 = "<table style='border:1px solid #000;'><thead>
	<tr><th>Your Id</th><th>Password</th><th>Otp</th></tr></thead>
	<tbody><tr><td>$username</td><td>$orgpass</td><td>$fourdigitrandom</td></tr></tbody>
	</table>";
	$m5 = "<p>Thanks & Regards</p>";
	$m6 = "<p>MALS Team</p>";
	$m7 = "<p>Website : www.mals.co.in</p>";
	
	$body = $m1.''.$m2.''.$m3.''.$m4.''.$m5.''.$m6.''.$m7;
	
	$headers = "MIME-Version: 1.0" . "\r\n";
	$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";	
	$subject = "Register Id & Match OTP - MALS";
	$to = $email_address;	
	$headers .= 'From: MALS <support@mals.co.in>' . "\r\n";	
	mail($to,$subject,$body,$headers);
	
	$ottp = base64_encode('otp');
	$match = base64_encode('Match');
	$no = base64_encode($fourdigitrandom);
	header("Location: signup/otp.php?$ottp&$no&srno=$last_insert_id&$match&msg=verify");
	
	// $_SESSION['sno'] = $last_insert_id;
    // $_SESSION['username'] = $username;
	
	// if(!empty($_SESSION["cart_item"])) {
		// foreach($_SESSION["cart_item"] as $k => $v) {
			// $product_id = $v['pro_id'];
			// $size = $v['size'];
			// $quantity = $v['pro_quantity'];						
			// $Chest_Width = $v['pro_cw'];						
			// $Waist = $v['pro_w'];						
			// $Body_Length = $v['pro_bl'];						
			// $Sleeve_Length = $v['pro_sl'];	
			// $created_date = date('Y-m-d');
				// $add_to_cart ="INSERT INTO `cart_items`(`user_id`, `product_id`, size, `quantity`, pro_cw, pro_w, pro_bl, pro_sl, `created_date`,`cart_status`) VALUES ('$last_insert_id','$product_id', '$size', '$quantity','$Chest_Width', '$Waist', '$Body_Length', '$Sleeve_Length', '$created_date','0')";						
				// $get_pro_res = mysqli_query($con, $add_to_cart);
				// if($get_pro_res=='true'){
					// unset($_SESSION["cart_item"]);							   
				// }
		// }
	// }
	
	// $check_exit ="Select sno from cart_items where user_id='$last_insert_id'";
	 // $check_exit_res = mysqli_query($con, $check_exit);
	 // $check_data=mysqli_num_rows($check_exit_res);
	 // if($check_data > 0){
		// header("Location: checkout");
	 // } else {
		// header("Location: dashboardag");
	 // }	
}
?>