<?php
session_start();
include("db.php");
date_default_timezone_set("Asia/Kolkata");

if(!empty($_SESSION["username"])) {
	  $user_email_noti = $_SESSION['username'];
	 $get_user_noti_query = "SELECT sno FROM users where username='$user_email_noti'";
	 $get_user_noiti_res = mysqli_query($con, $get_user_noti_query);
	 $get_user_noti_data = mysqli_fetch_array($get_user_noiti_res);
	 $user_noti_id = $get_user_noti_data['sno'];
	 $add_to_cart_noti = "SELECT * FROM cart_items where user_id='$user_noti_id' and cart_status='0'";
	 $get_pro_res_noti_1 = mysqli_query($con, $add_to_cart_noti);
	 while ($get_prodata_noti_1 = mysqli_fetch_array($get_pro_res_noti_1)){
		$id_noti  = $get_prodata_noti_1['sno'];
		$sess_pro_noti_id[]  = $get_prodata_noti_1['product_id'];
	 }
} else {
	
	if(!empty($_SESSION["cart_item"])) {
		foreach($_SESSION["cart_item"] as $k => $v) {
			$sess_pro_noti_id[]  = $v['pro_id'];
			
		}
	}
}

?>
        <b><?php if(!empty($sess_pro_noti_id)) { echo count($sess_pro_noti_id); } else { echo 0; }?></b>
		<ul class="dropdown-menu dropdown-menu-right">
			<li class="text-left">
			<?php 		
			if(!empty($sess_pro_noti_id)) {
				$imp_item_not_data = implode("','", $sess_pro_noti_id);
			}else{
				$imp_item_not_data = '';
			}
			$get_pro_noti = "SELECT * FROM products where id IN ('$imp_item_not_data') and status='1'";
			$get_pro_noti_res = mysqli_query($con, $get_pro_noti);
			while($item_data_noti = mysqli_fetch_array($get_pro_noti_res)){
				$product_img1 = $item_data_noti['product_img1'];
				$product_title = $item_data_noti['product_title'];
			?>
				<a class="dropdown-item text-dark" href="../checkout">
				<img class="img-fluid" src="../uploads/products/<?php echo $product_img1; ?>" alt="" style="width:40px;height:40px; margin-right: 5px;">
				<?php echo $product_title; ?>
				</a>
			<?php } ?>
			</li>
			<?php
			if(!empty($sess_pro_noti_id)) {
				?>
			<li  class="text-center" style="background: #eee;">
				<a href="../checkout/" style=" line-height: 28px;color:#3a5371; border:0px;" class=""><i class="fa fa-eye"></i> Show All</a>
			</li>
			<?php }else{ ?>
			<li  class="text-center">Not Found</li>
			<?php } ?>
		</ul>
		