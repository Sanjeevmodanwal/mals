<?php

require('config.php');
include("db.php");
require('razorpay-php/Razorpay.php');
use Razorpay\Api\Api;
$api = new Api($keyId, $keySecret);
$crncy = $_POST['currency'];
$orderData = [
    'receipt'         => 3456,
    'amount'          => $_POST['amount'] * 100,
    'currency'        => $_POST['currency'],
    'payment_capture' => 1
	

];
$razorpayOrder = $api->order->create($orderData);
$razorpayOrderId = $razorpayOrder['id'];
$_SESSION['razorpay_order_id'] = $razorpayOrderId; 
$displayAmount = $amount = $orderData['amount'];
if ($displayCurrency !== 'INR') {
    // $url = "https://api.fixer.io/latest?symbols=$displayCurrency&base=$crncy";
    $url = "http://data.fixer.io/api/latest?access_key=117029076f0378b9b31cc5831bbda2c2&symbols=$displayCurrency";
    $exchange = json_decode(file_get_contents($url), true);

    $displayAmount = $exchange['rates'][$displayCurrency] * $amount / 100;
}

$data = [
    "key"               => $keyId,
    "amount"            => $amount,
    "name"              => $_POST['item_name'],
    "description"       => $_POST['item_description'],
    "image"             => "",
    "prefill"           => [
    "name"              => $_POST['cust_name'],
    "email"             => $_POST['email'],
    "contact"           => $_POST['contact'],
    ],
    "notes"             => [
    "merchant_order_id" => "12312321",
    ],
    "theme"             => [
    "color"             => "#F37254"
    ],
    "order_id"          => $razorpayOrderId,
]; 
	$key              = $keyId;
    $amounts            = $_POST['amount'];
    $name             = $_POST['item_name'];
    $description       = $_POST['item_description'];
    $uname              = $_POST['cust_name'];
    $email             = $_POST['email'];
    $contact          = $_POST['contact'];
    $merchant_order_id = "12312321";
	$user_id = $_POST['user_id'];
	$client_id = $_POST['client_id'];
	$item_number = $_POST['item_number'];
	
    $order_id          = $razorpayOrderId;
	$time = date('Y-m-d h:i:s'); 
	

if ($displayCurrency !== 'INR')
{
    $other_currency  = $displayCurrency;
    $data_display_amount    = $displayAmount;
}

$inserted = "INSERT INTO `payment_status` (user_id, client_id, `email`, amount, `mobile`, `status`, `payment_request_id`, `paymentdate`) VALUES ('$user_id', '$client_id', '$email', '$amounts', '$contact', 'Pending', '$order_id', '$time')";
mysqli_query($con, $inserted);  
$json = json_encode($data);
?>
<div class=" p-0 col-lg-6 offset-lg-3 mb-4">
	<div class="table-responsive">
    <table class="table table-bordered table-hover table-striped">
					<tr><td><b>Visa Type :</b></td>
					 <td><?php echo $name; ?></td>
					 <td><b>Processing Priority</b></td>
					 <td><?php echo $description; ?></td></tr>  	 
					
					 <tr><td><b>Name :</b></td>
					 <td><?php echo $uname; ?></td>
					<td><b>Email ID:</b></td>
					 <td><?php echo $email; ?></td></tr> 					 
					 <tr><td><b> Mobile No:</b></td>
					 <td><?php echo '+91 '.$contact; ?></td>
					 <td><b> Amount:</b></td>
					 <td> <?php echo $amounts; ?></td></tr>
    </table>	
	</div>
	</div>
<?php
require("checkout/manual.php");
?>
</div>
<div class="insert-post-ads1" style="margin-top:20px;">

</div>
</div>
</div>
