<?php
$con = mysqli_connect("localhost", "travel_partners", "travel_partners@4321", "travel_partners");
if (mysqli_connect_errno()) {
  printf("Connect failed: %s\n", mysqli_connect_error());
  exit();
}
// mysqli_close($con);
?>