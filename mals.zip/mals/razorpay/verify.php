<?php
include("db.php");

require('config.php');
require('razorpay-php/Razorpay.php');
use Razorpay\Api\Api;
use Razorpay\Api\Errors\SignatureVerificationError;

$success = true;

$error = "Payment Failed";

if (empty($_POST['razorpay_payment_id']) === false)
{
    $api = new Api($keyId, $keySecret);

    try
    {
        // Please note that the razorpay order ID must
        // come from a trusted source (session here, but
        // could be database or something else)
        $attributes = array(
            'razorpay_order_id' => $_POST['razorpay_order_id'],
            'razorpay_payment_id' => $_POST['razorpay_payment_id'],
            'razorpay_signature' => $_POST['razorpay_signature']
        );

        $api->utility->verifyPaymentSignature($attributes);
    }
    catch(SignatureVerificationError $e)
    {
        $success = false;
        $error = 'Razorpay Error : ' . $e->getMessage();
    }
}

if ($success === true)
{
    /*$html = "<p>Your payment was successful</p>
             <p>Payment ID: {$_POST['razorpay_payment_id']}</p>";  */
			 
	$pamentid = $_POST['razorpay_payment_id'];
	$payment_request_id = $_POST['razorpay_order_id'];
	$update_query = "UPDATE `payment_status` SET `status`= 'Complete',`payment_id`='$pamentid' WHERE payment_request_id='$payment_request_id'";
	$payment_rqst_id = mysqli_query($con, $update_query);
	
	$get_data = 'SELECT * From payment_status where payment_id="'.$pamentid.'"';	
	$rsltqry_data = mysqli_query($con, $get_data);
    $rowpay_data = mysqli_fetch_array($rsltqry_data);
	// echo '<pre>';
	// print_r($rowpay_data);
	// die;
	$email = $rowpay_data['email'];
	$mobile = $rowpay_data['mobile'];
	$amount = $rowpay_data['amount'];
	$pay_status = $rowpay_data['status'];
	$payment_id = $rowpay_data['payment_id'];
	$paymentdate = $rowpay_data['paymentdate'];
	$user_done = $rowpay_data['complete'];
		
		echo '<p style="padding-top:50px; padding-bottom:0px; text-align:center; font-size:16px; font-weight:500;"><span style="text-align:center;"><i style="font-size: 26px;
    background: green;
    color: #fff;
    height: 60px;
    width: 60px;
    border-radius: 50%;
    line-height: 60px;" class="fa fa-check" aria-hidden="true"></i></span></p>';
	?>
	<div class=" p-0 col-lg-6 offset-lg-3 mb-4">
	<div class="table-responsive">
    <table class="table table-bordered table-hover table-striped">
		<tr>
		  <th scope="row">Amount</th>
		  <td><?php echo 'Rs.'.$amount;?></td>
		</tr>
		<tr>
		  <th scope="row">Payment Status</th>
		  <td><?php echo $pay_status;?></td>
		</tr>		
		<tr>
		  <th scope="row">Your Transaction ID is</th>
		  <td><?php echo $payment_id;?></td>
		</tr>
		<tr>
		  <th scope="row">Payment Date</th>
		  <td><?php echo $paymentdate;?></td>
		</tr>
    </table>	
	</div>
	</div>
	
	<?php
		
   	if($user_done == ''){
	$subject2 = "testfsdf - Fees Paid Successfully";
	$to2 = $email;
	$msg1 = "<b>Dear,</b><br><br>";
	$msg2 = "<p>Thank you for paying the fee at testfsdf. </p>";
	$msg3 = "<p>Amount is : $amount </p>";
	$msg31 = "<p>Payment Status is : $pay_status </p>";
	$msg32 = "<p>Your Transaction ID is : $payment_id </p>";
	$msg4 = "<p>For any further information / queries, please contact us at +91-00000000.</p>";
	$msg5 = "<p>We wish you all the best.</p>";
	$msg6 = "<p>Thanks,</p>";
	$msg7 = "<p> testfsdf</p>";
	$msg8 = "<p>+91-000000000</p>";
	$msg9 = "<p>afsfsf</p>";
	$message2 = $msg1.''.$msg2.''.$msg3.''.$msg31.''.$msg32.''.$msg4.''.$msg5.''.$msg6.''.$msg7.''.$msg8.''.$msg9;
	
	$headers2 = "MIME-Version: 1.0" . "\r\n";
	$headers2 .= "Content-type:text/html;charset=UTF-8" . "\r\n";
	$headers2 .= 'From: preety@essglobal.com'. "\r\n";
	
	mail ($to2,$subject2,$message2,$headers2);

	}
	
	$update_query = "UPDATE `payment_status` SET `complete`='1' WHERE payment_request_id='$payment_request_id'";
	mysqli_query($con, $update_query);
	
}
else
{
   /* $html = "<p>Your payment failed</p>
             <p>{$error}</p>"; */
	$pamentid = $_POST['razorpay_payment_id'];
	$payment_request_id = $_POST['razorpay_order_id'];
	$update_query = "UPDATE `payment_status` SET `status`= 'Failed',`payment_id`='$pamentid' WHERE payment_request_id='$payment_request_id'";
	if(mysqli_query($con, $update_query))
	{	
		echo 'Payment failed';
	}
}


