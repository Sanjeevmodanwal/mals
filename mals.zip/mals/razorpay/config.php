<?php
$keyId = 'rzp_live_u9U6QrrpYDqFi7';
$keySecret = 'cMXzhbIVHBre4qjzJr3zzt9M';
$displayCurrency = 'USD';
error_reporting(E_ALL);
ini_set('display_errors', 1);
