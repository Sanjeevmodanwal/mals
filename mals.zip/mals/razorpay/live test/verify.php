<?php
ob_start();
session_start();
include("../db.php");
require('config.php');
require('razorpay-php/Razorpay.php');
use Razorpay\Api\Api;
use Razorpay\Api\Errors\SignatureVerificationError;

include("../header.php");

if(!isset($_SESSION['id'])){
    header("Location: ../login");
    exit(); 
}

$success = true;

$error = "Payment Failed";

if (empty($_POST['razorpay_payment_id']) === false)
{
    $api = new Api($keyId, $keySecret);

    try
    {
        // Please note that the razorpay order ID must
        // come from a trusted source (session here, but
        // could be database or something else)
        $attributes = array(
            'razorpay_order_id' => $_POST['razorpay_order_id'],
            'razorpay_payment_id' => $_POST['razorpay_payment_id'],
            'razorpay_signature' => $_POST['razorpay_signature']
        );

        $api->utility->verifyPaymentSignature($attributes);
    }
    catch(SignatureVerificationError $e)
    {
        $success = false;
        $error = 'Razorpay Error : ' . $e->getMessage();
    }
}

if ($success === true)
{
    /*$html = "<p>Your payment was successful</p>
             <p>Payment ID: {$_POST['razorpay_payment_id']}</p>";  */
			 
	$pamentid = $_POST['razorpay_payment_id'];
	$payment_request_id = $_POST['razorpay_order_id'];
	$update_query = "UPDATE `payment_status` SET `pay_status`= 'Complete',`payment_id`='$pamentid' WHERE payment_request_id='$payment_request_id'";
	$payment_rqst_id = mysqli_query($con, $update_query);
	
	$get_data = 'SELECT * From payment_status where payment_id="'.$pamentid.'"';	
	$rsltqry_data = mysqli_query($con, $get_data);
    $rowpay_data = mysqli_fetch_array($rsltqry_data);
	// echo '<pre>';
	// print_r($rowpay_data);
	// die;
	$email = $rowpay_data['pay_email'];
	$mobile = $rowpay_data['mobile'];
	$amount = $rowpay_data['amount'];
	$pay_status = $rowpay_data['pay_status'];
	$payment_id = $rowpay_data['payment_id'];
	$paymentdate = $rowpay_data['paymentdate'];
	$user_done = $rowpay_data['complete'];
	$hotel_id = $rowpay_data['hotel_id'];

	$get_data1 = 'SELECT company_name, user_id From travel_description where id="'.$hotel_id.'"';	
	$rsltqry_data1 = mysqli_query($con, $get_data1);
    $rowpay_data1 = mysqli_fetch_array($rsltqry_data1);
	$company_name = $rowpay_data1['company_name'];
	$user_id = $rowpay_data1['user_id'];

	$get_data3 = 'SELECT username From users where id="'.$user_id.'"';	
	$rsltqry_data3 = mysqli_query($con, $get_data3);
    $rowpay_data3 = mysqli_fetch_array($rsltqry_data3);
	$username = $rowpay_data3['username'];
		
		echo '<section class="container-fluid users_form">
            <div class="container pt-5">
           <div class="row">
    <p class="col-12" style="padding-bottom:20px; text-align:center; font-size:16px; font-weight:500;"><span style="text-align:center;"><i style="font-size: 26px;
    background: green;
    color: #fff;
    height: 60px;
    width: 60px;
    border-radius: 50%;
    line-height: 60px;" class="fa fa-check" aria-hidden="true"></i></span></p>';
	?>
	<div class=" p-0 col-lg-6 offset-lg-3 mb-4">
	<div class="table-responsive">
    <table class="table table-bordered table-hover table-striped">
    	<tr>
		  <th scope="row">Company Name</th>
		  <td><?php echo $company_name;?></td>
		</tr>
		<tr>
		  <th scope="row">Amount</th>
		  <td><?php echo '&pound;'.$amount;?></td>
		</tr>
		<tr>
		  <th scope="row">Payment Status</th>
		  <td><?php echo $pay_status;?></td>
		</tr>		
		<tr>
		  <th scope="row">Your Transaction ID is</th>
		  <td><?php echo $payment_id;?></td>
		</tr>
		<tr>
		  <th scope="row">Payment Date</th>
		  <td><?php echo $paymentdate;?></td>
		</tr>
    </table>	
	</div>
	</div>
	</div>
	</div>
	</section>
	<?php
		
   	if($user_done == ''){
	$subject2 = "Outbound Traveller - Fees Paid Successfully";
	$to2 = $email;
	$msg1 = "<b>Dear $username,</b><br>";
	$msg2 = "<p>Thank you for listing your company at Outbound Traveller. Please find your payment details below: </p>";
	$msg3 = "<p>Amount is &pound;$amount </p>";
	$msg4 = "<p>Payment Status is : $pay_status </p>";
	$msg5 = "<p>Your Transaction ID is : $payment_id </p>";
	// $msg6 = "<p>For any further information / queries, please contact us at +91-00000000.</p>";
	$msg7 = "<p>We wish you all the best.</p>";
	$msg8 = "<p>Thanks,</p>";
	$msg9 = "<p>Team Outbound Traveller</p>";
	$message2 = $msg1.''.$msg2.''.$msg3.''.$msg4.''.$msg5.''.$msg7.''.$msg8.''.$msg9;
	
	$headers2 = "MIME-Version: 1.0" . "\r\n";
	$headers2 .= "Content-type:text/html;charset=UTF-8" . "\r\n";
	$headers2 .= 'From: Outbound Traveller <info@outboundtraveller.co.uk>'. "\r\n";
	
	mail ($to2,$subject2,$message2,$headers2);


	$subject3 = "Outbound Traveller - Fees Paid Successfully($username, $mobile)";
	$to3 = 'perfectmultimediamail@gmail.com';
	$msg42 = "<p>A new listing has been created on Outbound Traveller find the details below: </p>";
	$msg43 = "<p>Username: $username </p>";
	$msg44 = "<p>Email Address: $email </p>";
	$msg45 = "<p>Company Name: $company_name </p>";
	$msg46 = "<p>Amount: &pound;$amount </p>";
	$msg47 = "<p>Payment Status : $pay_status </p>";
	$msg48 = "<p>Transaction ID : $payment_id </p>";
	$message3 = $msg42.''.$msg43.''.$msg44.''.$msg45.''.$msg46.''.$msg47.''.$msg48;

	$headers3 = "MIME-Version: 1.0" . "\r\n";
	$headers3 .= "Content-type:text/html;charset=UTF-8" . "\r\n";
	$headers3 .= 'From: no-reply <info@outboundtraveller.co.uk>'. "\r\n";
	
	mail ($to3,$subject3,$message3,$headers3);

	}
	
	$update_query = "UPDATE `payment_status` SET `complete`='1' WHERE payment_request_id='$payment_request_id'";
	mysqli_query($con, $update_query);
	
}
else
{
   /* $html = "<p>Your payment failed</p>
             <p>{$error}</p>"; */
	$pamentid = $_POST['razorpay_payment_id'];
	$payment_request_id = $_POST['razorpay_order_id'];
	$update_query = "UPDATE `payment_status` SET `pay_status`= 'Failed',`payment_id`='$pamentid' WHERE payment_request_id='$payment_request_id'";
	if(mysqli_query($con, $update_query))
	{	
		echo 'Payment failed';
	}
}

?>
<?php include("../footer.php"); ?>
