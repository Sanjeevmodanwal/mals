<?php
ob_start();
session_start();
include("../db.php");
require('config.php');
require('razorpay-php/Razorpay.php');
use Razorpay\Api\Api;
$api = new Api($keyId, $keySecret);
$crncy = $_POST['currency'];
$orderData = [
    'receipt'         => 3456,
    'amount'          => $_POST['amount'] * 100,
    'currency'        => $_POST['currency'],
    'payment_capture' => 1
    

];
$razorpayOrder = $api->order->create($orderData);
$razorpayOrderId = $razorpayOrder['id'];
$_SESSION['razorpay_order_id'] = $razorpayOrderId; 
$displayAmount = $amount = $orderData['amount'];
if ($displayCurrency !== 'INR') {
    // $url = "https://api.fixer.io/latest?symbols=$displayCurrency&base=$crncy";
    $url = "http://data.fixer.io/api/latest?access_key=117029076f0378b9b31cc5831bbda2c2&symbols=$displayCurrency";
    $exchange = json_decode(file_get_contents($url), true);

    $displayAmount = $exchange['rates'][$displayCurrency] * $amount / 100;
}

include("../header.php");

if(!isset($_SESSION['id'])){
    header("Location: ../login");
    exit(); 
}


$data = [
    "key"               => $keyId,
    "amount"            => $amount,
    "name"              => $_POST['hotel_type'],
    "prefill"           => [
    "name"              => $_POST['contact_person'],
    "email"             => $_POST['email'],
    "telephone"           => $_POST['telephone'],
    ],
    "notes"             => [
    "merchant_order_id" => "12312321",
    ],
    "theme"             => [
    "color"             => "#F37254"
    ],
    "order_id"          => $razorpayOrderId,
]; 
	$key              = $keyId;
    $amounts            = $_POST['amount'];
    // $name             = $_POST['hotel_type'];
    // $description       = $_POST['description'];
    // $uname              = $_POST['contact_person'];
    // $email             = $_POST['email'];
    // $contact          = $_POST['contact'];
    $merchant_order_id = "12312321";
	// $user_id = $_POST['user_id'];
	// $client_id = $_POST['client_id'];
	// $item_number = $_POST['item_number'];
	
    $order_id          = $razorpayOrderId;
	$time = date('Y-m-d h:i:s'); 
	

if ($displayCurrency !== 'INR')
{
    $other_currency  = $displayCurrency;
    $data_display_amount    = $displayAmount;
}


$tid = $_POST['tid'];
    $user_id = $_POST['user_id'];
    $hotel_type = $_POST['hotel_type'];
    $company_name = $_POST['company_name'];
    $address = $_POST['address_2'];
    $country = $_POST['country'];
    $city = $_POST['city'];
    $pin = $_POST['pin'];
    $telephone = $_POST['telephone'];
    $email = $_POST['email'];
    $website = $_POST['website'];
    $paid_type = $_POST['paid_type'];
    $contact_person = $_POST['contact_person'];

    if($hotel_type == 'Hotel'){
        $description = $_POST['description'];
        $star_category = $_POST['star_category'];
        if(!empty($_POST['facilities'])){
            $facilities_1 = $_POST['facilities'];            
            $facilities = implode(',', $facilities_1);
        }else{
            $facilities = '';
        }
        $tariff_starting_from = $_POST['tariff_starting_from'];
        $distance_from_airport = $_POST['distance_from_airport'];

        $cuisines = '';
        $timings = '';
        $entry_fees = '';
        $airport_transfers = '';
        $apt_fix_departures = '';
        $fleet_details = '';
        $travel_agents_countries_covered = '';
        $travel_agents_packages = '';
    }

    elseif($hotel_type == 'Travel Agents'){
        $description = $_POST['description'];
        $travel_agents_countries_covered = $_POST['travel_agents_countries_covered'];
        $travel_agents_packages = $_POST['travel_agents_packages'];

        $cuisines = '';
        $timings = '';      
        $star_category = '';
        $facilities = '';
        $tariff_starting_from = '';
        $distance_from_airport = '';
        $entry_fees = '';
        $airport_transfers = '';
        $apt_fix_departures = '';
        $fleet_details = '';
    }

    elseif($hotel_type == 'Transport'){
        $description = $_POST['description'];
        $airport_transfers_1 = $_POST['airport_transfers'];
        $airport_transfers = implode(',', $airport_transfers_1);

        // if($airport_transfers == 'Fix Departures'){
            if(!empty($_POST['apt_fix_departures'])){
                $apt_fix_departures_1 = $_POST['apt_fix_departures'];       
                $apt_fix_departures = implode(',', $apt_fix_departures_1);
            }else{
                $apt_fix_departures = '';
            }
        // }else{
        //  $apt_fix_departures = '';
        // }
        
        $fleet_details = $_POST['fleet_details'];

        $cuisines = '';
        $timings = '';      
        $star_category = '';
        $facilities = '';
        $tariff_starting_from = '';
        $distance_from_airport = '';
        $entry_fees = '';
        $travel_agents_countries_covered = '';
        $travel_agents_packages = '';
    }
    elseif($hotel_type == 'Attractions'){
        $description = $_POST['description'];
        $entry_fees = $_POST['entry_fees'];

        $cuisines = '';
        $timings = '';      
        $star_category = '';
        $facilities = '';
        $tariff_starting_from = '';
        $distance_from_airport = '';
        $airport_transfers = '';
        $apt_fix_departures = '';
        $fleet_details = '';
        $travel_agents_countries_covered = '';
        $travel_agents_packages = '';
    }

    elseif($hotel_type == 'Restaurants'){
        $description = $_POST['description'];
        $cuisines = $_POST['cuisines'];
        $timings = $_POST['timings'];   
        
        $star_category = '';
        $facilities = '';
        $tariff_starting_from = '';
        $distance_from_airport = '';
        $entry_fees = '';
        $airport_transfers = '';
        $apt_fix_departures = '';
        $fleet_details = '';
        $travel_agents_countries_covered = '';
        $travel_agents_packages = '';
        

    }else{
        $description = '';

        $cuisines = '';
        $timings = '';
        
        $star_category = '';
        $facilities = '';
        $tariff_starting_from = '';
        $distance_from_airport = '';

        $entry_fees = '';

        $airport_transfers = '';
        $apt_fix_departures = '';
        $fleet_details = '';

        $travel_agents_countries_covered = '';
        $travel_agents_packages = '';
    }   
    


    $name1 = $_FILES['logo']['name'];
    $tmp1 = $_FILES['logo']['tmp_name'];

    $name11 = $_FILES['photos1']['name'];
    $tmp11 = $_FILES['photos1']['tmp_name'];

    $name2 = $_FILES['photos2']['name'];
    $tmp2 = $_FILES['photos2']['tmp_name'];

    $name3 = $_FILES['photos3']['name'];
    $tmp3 = $_FILES['photos3']['tmp_name'];

    $name4 = $_FILES['photos4']['name'];
    $tmp4 = $_FILES['photos4']['tmp_name'];

    $firstname = str_replace(' ', '', $company_name);

if(empty($tid)){
    $extension = pathinfo($name1, PATHINFO_EXTENSION);          
        if($extension=='JPG' || $extension=='jpg' || $extension=='jpeg' || $extension=='JPEG' || $extension=='png' || $extension=='PNG'){
            $img_name1 = 'Logo_'.$firstname.'_'.date('is').'.'.$extension;
            move_uploaded_file($tmp1, '../uploads/'.$img_name1);
        }else{
            echo '2';  //File is not Supported
            exit;           
        }

        if(!empty($name11)){
        $extension11 = pathinfo($name11, PATHINFO_EXTENSION);               
        if($extension11=='JPG' || $extension11=='jpg' || $extension11=='jpeg' || $extension11=='JPEG' || $extension11=='png' || $extension11=='PNG'){
            $img_name11 = 'Photo1_'.$firstname.'_'.date('is').'.'.$extension11;
            move_uploaded_file($tmp11, '../uploads/'.$img_name11);
        }else{
            echo '11';  //File is not Supported
            exit;           
        }
        }else{
            $img_name11 = '';
        }

        if(!empty($name2)){
        $extension2 = pathinfo($name2, PATHINFO_EXTENSION);             
        if($extension2=='JPG' || $extension2=='jpg' || $extension2=='jpeg' || $extension2=='JPEG' || $extension2=='png' || $extension2=='PNG'){
            $img_name2 = 'Photo2_'.$firstname.'_'.date('is').'.'.$extension2;
            move_uploaded_file($tmp2, '../uploads/'.$img_name2);
        }else{
            echo '2';  //File is not Supported
            exit;           
        }
        }else{
            $img_name2 = '';
        }   

        if(!empty($name3)){
        $extension3 = pathinfo($name3, PATHINFO_EXTENSION);             
        if($extension3=='JPG' || $extension3=='jpg' || $extension3=='jpeg' || $extension3=='JPEG' || $extension3=='png' || $extension3=='PNG'){
            $img_name3 = 'Photo3_'.$firstname.'_'.date('is').'.'.$extension3;
            move_uploaded_file($tmp3, '../uploads/'.$img_name3);
        }else{
            echo '3';  //File is not Supported
            exit;           
        }
        }else{
            $img_name3 = '';
        }

        if(!empty($name4)){
        $extension4 = pathinfo($name4, PATHINFO_EXTENSION);             
        if($extension4=='JPG' || $extension4=='jpg' || $extension4=='jpeg' || $extension4=='JPEG' || $extension4=='png' || $extension4=='PNG'){
            $img_name4 = 'Photo4_'.$firstname.'_'.date('is').'.'.$extension4;
            move_uploaded_file($tmp4, '../uploads/'.$img_name4);
        }else{
            echo '4';  //File is not Supported
            exit;           
        }
        }else{
            $img_name4 = '';
        }
    
$inserted12 = "INSERT INTO `travel_description` (`user_id`, `paid_type`, `hotel_type`, `company_name`, `address`, `country`, `city`, `pin`, `telephone`, `email`, `website`, `logo`, star_category, facilities, tariff_starting_from, distance_from_airport, contact_person, photos1, photos2, photos3, photos4, description, travel_agents_countries_covered, travel_agents_packages, airport_transfers, apt_fix_departures, fleet_details, entry_fees, cuisines, timings) VALUES ('$user_id', '$paid_type', '$hotel_type', '$company_name', '$address', '$country', '$city', '$pin', '$telephone', '$email', '$website', '$img_name1', '$star_category', '$facilities', '$tariff_starting_from', '$distance_from_airport', '$contact_person', '$img_name11',  '$img_name2', '$img_name3', '$img_name4', '$description', '$travel_agents_countries_covered', '$travel_agents_packages', '$airport_transfers', '$apt_fix_departures', '$fleet_details', '$entry_fees', '$cuisines', '$timings')";
mysqli_query($con, $inserted12);
$last_insert_id = mysqli_insert_id($con);
}else{

    $delete_foldr=mysqli_query($con, "SELECT logo, photos1, photos2, photos3, photos4 FROM travel_description where id='$tid'");
        $dltlist = mysqli_fetch_assoc($delete_foldr);
        $logo = $dltlist['logo'];
        $photos1_1 = $dltlist['photos1'];
        $photos2_1 = $dltlist['photos2'];
        $photos3_1 = $dltlist['photos3'];
        $photos4_1 = $dltlist['photos4'];

        $expldc23 = explode(',', $airport_transfers);
        if (in_array('Fix Departures', $expldc23)){
                $fixd = $apt_fix_departures;            
        }else{
                $fixd = '';
        }

        if($name1 == ''){   
                $img_name1 = $logo; 
        }else{                              
            $extension = pathinfo($name1, PATHINFO_EXTENSION);              
            if($extension=='JPG' || $extension=='jpg' || $extension=='jpeg' || $extension=='JPEG' || $extension=='png' || $extension=='PNG'){
                if(!empty($logo)){
                    unlink("../uploads/$logo");
                }
                $img_name1 = 'Logo_'.$firstname.'_'.date('is').'.'.$extension;
                move_uploaded_file($tmp1, '../uploads/'.$img_name1);
            }else{
                echo '2';  //File is not Supported
                exit;
            }               
        }

        if(!empty($name11)){
        $extension11 = pathinfo($name11, PATHINFO_EXTENSION);               
        if($extension11=='JPG' || $extension11=='jpg' || $extension11=='jpeg' || $extension11=='JPEG' || $extension11=='png' || $extension11=='PNG'){
            $img_name11 = 'Photo1_'.$firstname.'_'.date('is').'.'.$extension11;
            move_uploaded_file($tmp11, '../uploads/'.$img_name11);
        }else{
            echo '11';  //File is not Supported
            exit;           
        }
        }else{
            $img_name11 = $photos1_1;
        }

        if(!empty($name2)){
        $extension2 = pathinfo($name2, PATHINFO_EXTENSION);             
        if($extension2=='JPG' || $extension2=='jpg' || $extension2=='jpeg' || $extension2=='JPEG' || $extension2=='png' || $extension2=='PNG'){
            $img_name2 = 'Photo2_'.$firstname.'_'.date('is').'.'.$extension2;
            move_uploaded_file($tmp2, '../uploads/'.$img_name2);
        }else{
            echo '2';  //File is not Supported
            exit;           
        }
        }else{
            $img_name2 = $photos2_1;
        }   

        if(!empty($name3)){
        $extension3 = pathinfo($name3, PATHINFO_EXTENSION);             
        if($extension3=='JPG' || $extension3=='jpg' || $extension3=='jpeg' || $extension3=='JPEG' || $extension3=='png' || $extension3=='PNG'){
            $img_name3 = 'Photo3_'.$firstname.'_'.date('is').'.'.$extension3;
            move_uploaded_file($tmp3, '../uploads/'.$img_name3);
        }else{
            echo '3';  //File is not Supported
            exit;           
        }
        }else{
            $img_name3 = $photos3_1;
        }

        if(!empty($name4)){
        $extension4 = pathinfo($name4, PATHINFO_EXTENSION);             
        if($extension4=='JPG' || $extension4=='jpg' || $extension4=='jpeg' || $extension4=='JPEG' || $extension4=='png' || $extension4=='PNG'){
            $img_name4 = 'Photo4_'.$firstname.'_'.date('is').'.'.$extension4;
            move_uploaded_file($tmp4, '../uploads/'.$img_name4);
        }else{
            echo '4';  //File is not Supported
            exit;           
        }
        }else{
            $img_name4 = $photos4_1;
        }

        $uqry = "update `travel_description` set `company_name`='$company_name', `address`='$address', `country`='$country', `city`='$city', `pin`='$pin', `telephone`='$telephone', `email`='$email', `website`='$website', `logo`='$img_name1', star_category='$star_category', facilities='$facilities', tariff_starting_from='$tariff_starting_from', distance_from_airport='$distance_from_airport', contact_person='$contact_person', photos1='$img_name11', photos2='$img_name2', photos3='$img_name3', photos4='$img_name4',  description='$description', travel_agents_countries_covered='$travel_agents_countries_covered', travel_agents_packages='$travel_agents_packages', airport_transfers='$airport_transfers', apt_fix_departures='$fixd', fleet_details='$fleet_details', entry_fees='$entry_fees', cuisines='$cuisines', timings='$timings' where `id`='$tid'";
        $update_query = mysqli_query($con, $uqry);
        $last_insert_id = $tid;

}


$inserted = "INSERT INTO `payment_status` (user_id, hotel_id, `pay_email`, amount, `mobile`, `pay_status`, `payment_request_id`, `paymentdate`) VALUES ('$user_id', '$last_insert_id', '$email', '$amounts', '$telephone', 'Pending', '$order_id', '$time')";
mysqli_query($con, $inserted);  
$json = json_encode($data);
?><section class="container-fluid users_form">

  <div class="container pt-5">

    <div class="row">


<div class=" p-0 col-lg-6 offset-lg-3 mb-4">
    <h2 class="text-center mb-5">Pay and Continue</h2>
	<div class="table-responsive">
    <table class="table table-bordered table-hover table-striped">
		<tr>
          <td><b>Company Name :</b></td>
		 <td><?php echo $company_name; ?></td>
		        </tr>
		<tr>
           <td><b>Email Id:</b></td>
		   <td><?php echo $email; ?></td>
		  </tr>
        <tr>
         <td><b>Contact Number</b></td>
         <td><?php echo $telephone; ?></td>
        </tr>
        <tr>
           <td><b> Amount:</b></td>
           <td>&pound;<?php echo $amounts; ?> </td>
        </tr>
    </table>	
	</div>
	</div>
 
<?php
require("checkout/manual.php");
?>
</div>
<div class="insert-post-ads1" style="margin-top:20px;">

</div>
</div>
</div>
   </div>
    </div>
</section>
<?php include("../footer.php"); ?>
