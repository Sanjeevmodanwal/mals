<?php
ob_start();
include("../db.php");
include("../header.php");

if(!isset($_SESSION['id'])){
    header("Location: ../login");
    exit(); 
}


if(!empty($_GET['tid'])){
	$getid = $_GET['tid'];

	$results_paid = "SELECT * FROM travel_description WHERE id='$getid'";
	$resultsstr = mysqli_query($con, $results_paid);
	$rowsPaid = mysqli_fetch_assoc($resultsstr);
	$id = mysqli_real_escape_string($con, $rowsPaid['id']);
	$user_id = mysqli_real_escape_string($con, $rowsPaid['user_id']);
	$hotel_type2 = mysqli_real_escape_string($con, $rowsPaid['hotel_type']);
	$company_name = mysqli_real_escape_string($con, $rowsPaid['company_name']);
	$address = mysqli_real_escape_string($con, $rowsPaid['address']);
	$city = mysqli_real_escape_string($con, $rowsPaid['city']);
	$country = mysqli_real_escape_string($con, $rowsPaid['country']);
	$pin = mysqli_real_escape_string($con, $rowsPaid['pin']);
	$telephone = mysqli_real_escape_string($con, $rowsPaid['telephone']);
	$email = mysqli_real_escape_string($con, $rowsPaid['email']);
	$website = mysqli_real_escape_string($con, $rowsPaid['website']);
	$logo = mysqli_real_escape_string($con, $rowsPaid['logo']);
	$star_category = mysqli_real_escape_string($con, $rowsPaid['star_category']);
	$facilities = mysqli_real_escape_string($con, $rowsPaid['facilities']);
	$tariff_starting_from = mysqli_real_escape_string($con, $rowsPaid['tariff_starting_from']);
	$distance_from_airport = mysqli_real_escape_string($con, $rowsPaid['distance_from_airport']);
	$contact_person = mysqli_real_escape_string($con, $rowsPaid['contact_person']);
	$description = mysqli_real_escape_string($con, $rowsPaid['description']);
	$travel_agents_countries_covered = mysqli_real_escape_string($con, $rowsPaid['travel_agents_countries_covered']);
	$travel_agents_packages = mysqli_real_escape_string($con, $rowsPaid['travel_agents_packages']);

	$airport_transfers = mysqli_real_escape_string($con, $rowsPaid['airport_transfers']);
	$apt_fix_departures = mysqli_real_escape_string($con, $rowsPaid['apt_fix_departures']);
	$fleet_details = mysqli_real_escape_string($con, $rowsPaid['fleet_details']);
	$entry_fees = mysqli_real_escape_string($con, $rowsPaid['entry_fees']);
	$cuisines = mysqli_real_escape_string($con, $rowsPaid['cuisines']);
	$timings = mysqli_real_escape_string($con, $rowsPaid['timings']);
	$photos1 = mysqli_real_escape_string($con, $rowsPaid['photos1']);
	$photos2 = mysqli_real_escape_string($con, $rowsPaid['photos2']);
	$photos3 = mysqli_real_escape_string($con, $rowsPaid['photos3']);
	$photos4 = mysqli_real_escape_string($con, $rowsPaid['photos4']);

}else{

	$getid = '';
	$id = '';
	$user_id = $sessionid1;
	$hotel_type2 = $hotel_type1;
	$company_name = '';
	$address = '';
	$country = '';
	$city = '';
	$pin = '';
	$telephone = '';
	$email = '';
	$website = '';
	$logo = '';
	$star_category = '';
	$facilities = '';
	$tariff_starting_from = '';
	$distance_from_airport = '';
	$contact_person = '';
	$description = '';
	$travel_agents_countries_covered = '';
	$travel_agents_packages = '';

	$airport_transfers = '';
	$apt_fix_departures = '';
	$fleet_details = '';
	$entry_fees = '';
	$cuisines = '';
	$timings = '';
	$photos1 = '';
	$photos2 = '';
	$photos3 = '';
	$photos4 = '';

}

$random_2 = base64_encode(rand());
?>

<section class="container-fluid users_form">
  <div class="container pb-5">
    <div class="row">
      <div class="col-12 col-xl-10 offset-xl-1">
        <h2 class="text-center">
        	<?php 
        	if(!empty($getid)){
        		echo 'Edit ';
        	}else{
        		echo 'Add ';
        	}
        	echo $hotel_type2; 
        	?>        		
        </h2>
<!--form method="post" autocomplete="off" name="registerFrm" id="registerFrm"-->
<form method="post" autocomplete="off" action="pay.php" id="registerFrm" enctype="multipart/form-data">
         <div class="add_partners_form mt-5">
<div class="choose_tabs mb-5 text-center">
  <ul>
  	<li><a class="first_tab">Paid Listing</a>	</li>
  	<li><a class=" btn-dark text-white" href="../travel_register/unpaid.php?type=Unpaid&<?php echo $random_2;?>" style="">Go To Free Listing</a>	</li>
</div>
  <div class="form-group">
    <label for="name">Company Name:</label>
    <input type="text" name="company_name" class="form-control company_name" id="company_name" value="<?php echo $company_name; ?>" required>
  </div>

   <div class="form-group">
    <label for="address_2">Address:</label>
    <input type="text" name="address_2" class="form-control address_2" id="address_2" value="<?php echo $address; ?>" required>
  </div>

  <div class="form-group">
    <label for="city">City:</label>
    <select name="city" class="form-control CityOption city" id="city" required>
		<option value="">Select Option</option>
		<?php 
		$results_city = "SELECT name FROM cities WHERE status='1' ORDER by name";
		$str_city = mysqli_query($con, $results_city);
		while($city_row = mysqli_fetch_assoc($str_city)){
			$name_23 = mysqli_real_escape_string($con, $city_row['name']);
		?>
		<option value="<?php echo $name_23; ?>" <?php if($name_23 == $city) { echo 'selected="selected"'; } ?>><?php echo $name_23; ?></option>
		<?php } ?>
	</select> 
	<input type="text" name="city_new" class="form-control city_new" id="city_new" style="display: none;">
	<p class="error_city"></p>
	<span class="btn btn-success saveCity" style="display: none;">Save</span>

	<a href="javascript:void(0)" class="CityDiv">Add your city</a>  
	<a href="javascript:void(0)" class="CityOldbtn" style="display: none;">Cancel</a>  
  </div>

   <div class="form-group">
    <label for="country">Country:</label>
    <input type="text" name="country" class="form-control country" id="country" value="<?php echo $country; ?>" required>
  </div>

    <div class="form-group">
    <label for="pin">Pin Code:</label>
    <input type="text" name="pin" class="form-control pin" id="pin" value="<?php echo $pin; ?>" required>
  </div>

  <div class="form-group">
    <label for="telephone">Contact Number:</label>
    <input type="text" name="telephone" class="form-control telephone" id="telephone" value="<?php echo $telephone; ?>" required>
  </div>

  <div class="form-group">
    <label for="email">Email:</label>
    <input type="email" name="email" class="form-control email" id="email" value="<?php echo $email; ?>" required>
  </div>

  <div class="form-group">
    <label for="website">Website url:</label>
    <input type="website" name="website" class="form-control website" id="website" value="<?php echo $website; ?>" required>
  </div>

  <div class="form-group">
    <label for="logo">Logo: <span style="color:red;">(Note:only upload jpg, png and jpeg)</span></label>
    <?php if(empty($logo)){ ?>
    	<input type="file" name="logo" class="my-pond logo" id="logo" value="<?php echo $logo; ?>" required/>
	<?php }else{ ?>
		<input type="file" name="logo" class="my-pond logo" id="logo" value="<?php echo $logo; ?>" />
    <?php } 
    if(!empty($logo)){ ?>
    <a href="../uploads/<?php echo $logo; ?>" download>Download</a>
    <?php } ?>
  </div>

  <?php if($hotel_type2 == 'Hotel'){ ?>
   <div class="form-group">
    <label for="logo">Star category:</label>
    <select name="star_category" class="form-control star_category" id="star_category" required>
    	<option value="">Select Option</option>
    	<option value="1"<?php if($star_category == "1") { echo 'selected="selected"'; } ?>>1</option>
    	<option value="2"<?php if($star_category == "2") { echo 'selected="selected"'; } ?>>2</option>
    	<option value="3"<?php if($star_category == "3") { echo 'selected="selected"'; } ?>>3</option>
    	<option value="4"<?php if($star_category == "4") { echo 'selected="selected"'; } ?>>4</option>
    	<option value="5"<?php if($star_category == "5") { echo 'selected="selected"'; } ?>>5</option>
    </select>
   </div>

   <div class="form-group">
    <label for="Facilities" class="w-100">Facilities And Services:</label>
    <div class="row">
    <?php 
   		$expldc = explode(',', $facilities);
		$results_facilities = "SELECT id, name FROM facilities WHERE status='1'";
		$str_facilities = mysqli_query($con, $results_facilities);
		while($row_facilities = mysqli_fetch_assoc($str_facilities)){
			$id_fac = mysqli_real_escape_string($con, $row_facilities['id']);
			$name_fac = mysqli_real_escape_string($con, $row_facilities['name']);

			if (in_array($name_fac, $expldc)){
				$fdf = 'checked="checked"';			
			}else{
				$fdf = '';
			}
		?>

 <div class="col-md-4 col-sm-6 boxes_check">
  	<input type="checkbox" id="box-<?php echo $id_fac; ?>" class="float-left w-auto facilitiesDiv" style="margin-top: 6px;" name="facilities[]" value="<?php echo $name_fac; ?>"<?php echo $fdf; ?>>
  <label for="box-<?php echo $id_fac; ?>"  class="checkbox-inline"><?php echo $name_fac; ?></label>

</div>
	<?php } ?>

	
	
   </div>
   </div>

   <div class="form-group">
    <label for="tariff_starting_from">Tariff Starting from:</label>
    <input type="text" name="tariff_starting_from" class="form-control tariff_starting_from" id="tariff_starting_from" value="<?php echo $tariff_starting_from; ?>" required>
   </div>

   <div class="form-group">
    <label for="distance_from_airport">Distance from Airport:</label>
    <input type="text" name="distance_from_airport" class="form-control distance_from_airport" id="distance_from_airport" value="<?php echo $distance_from_airport; ?>" required>
   </div>

   <div class="form-group">
	    <label for="Description">Description:</label>
	    <input type="text" name="description" class="form-control description" id="description" value="<?php echo $description; ?>" required>
	</div>
<?php } ?>

   <div class="form-group">
    <label for="contact_person">Contact Person:</label>
    <input type="text" name="contact_person" class="form-control contact_person" id="contact_person" value="<?php echo $contact_person; ?>" required>
   </div>  

   <?php if($hotel_type2 == 'Travel Agents'){ ?>
   		 <div class="form-group">
		    <label for="Description">Description:</label>
		    <input type="text" name="description" class="form-control description" id="description" value="<?php echo $description; ?>" required>
		 </div>

		 <div class="form-group">
		    <label for="travel_agents_countries_covered">Countries covered:</label>
		    <input type="text" name="travel_agents_countries_covered" class="form-control travel_agents_countries_covered" id="travel_agents_countries_covered" value="<?php echo $travel_agents_countries_covered; ?>" required>
		 </div>

		 <div class="form-group">
		    <label for="travel_agents_packages">Packages Starting From:</label>
		    <input type="text" name="travel_agents_packages" class="form-control travel_agents_packages" id="travel_agents_packages" value="<?php echo $travel_agents_packages; ?>" required>
		 </div>
		 
   <?php } ?>

   <?php if($hotel_type2 == 'Transport'){ ?>
   		 <div class="form-group">
		    <label for="Description">Description:</label>
		    <input type="text" name="description" class="form-control description" id="description" value="<?php echo $description; ?>" required>
		 </div>

		<?php
		$expldc2 = explode(',', $airport_transfers);
		if (in_array('Flexible Timings', $expldc2)){
				$flex = 'checked="checked"';			
			}else{
				$flex = '';
			}
		if (in_array('Fix Departures', $expldc2)){
				$fixd = 'checked="checked"';			
			}else{
				$fixd = '';
			}
		if (in_array('All Terminals', $expldc2)){
				$allt = 'checked="checked"';			
			}else{
				$allt = '';
			}
		?>

		 <div class="form-group row"> 


<div class="col-md-4 col-sm-6 boxes_check">
	<label for="airport_transfers">Airport Transfers:</label>
  	<input type="checkbox" id="box-2" name="airport_transfers[]" class="airport_transfers" id="airport_transfers" value="Flexible Timings" <?php echo $flex; ?>>
  <label for="box-2"  class="checkbox-inline">Flexible Timings</label>

  <input type="checkbox" id="box-3" name="airport_transfers[]" class="airport_transfersfix" id="airport_transfers" value="Fix Departures" <?php echo $fixd; ?>> 
  <label for="box-3"  class="checkbox-inline">Fix Departures</label>
  <input type="checkbox" id="box-7" name="airport_transfers[]" class="airport_transfers" id="airport_transfers" value="All Terminals" <?php echo $allt; ?>>   <label for="box-7"  class="checkbox-inline">All Terminals</label>
</div>

		    
		    <!---input type="checkbox" name="airport_transfers[]" class="airport_transfers" id="airport_transfers" value="Flexible Timings" <?php //echo $flex; ?>> Flexible Timings

		    <input type="checkbox" name="airport_transfers[]" class="airport_transfersfix" id="airport_transfers" value="Fix Departures" <?php //echo $fixd; ?>> Fix Departures---->

	<?php
	$expldc3 = explode(',', $apt_fix_departures);
		if (in_array('Every 30 min', $expldc3)){
				$e30min = 'checked="checked"';			
			}else{
				$e30min = '';
			}
		if (in_array('Every 1 hour', $expldc3)){
				$fixd1 = 'checked="checked"';			
			}else{
				$fixd1 = '';
			}			
	?>



<div class="form-group fix_departures_class col-md-4 col-sm-6" style="display: none;">
<label>Fix Departures</label>
 <div class="boxes_check">
  	<input type="checkbox" id="box-4" name="apt_fix_departures[]" class="apt_fix_departures" id="apt_fix_departures" value="Every 30 min" <?php echo $e30min; ?>>
  	<label for="box-4"  class="checkbox-inline">Every 30 min</label>
	<input type="checkbox" id="box-6" name="apt_fix_departures[]" class="apt_fix_departures" id="apt_fix_departures" value="Every 1 hour" <?php echo $fixd1; ?>>
	<label for="box-6"  class="checkbox-inline"> Every 1 hour</label>
</div>	    

		  
</div>

		 <div class="form-group col-12">
		    <label for="fleet_details">Fleet Details:</label>
		    <input type="text" name="fleet_details" class="form-control fleet_details" id="fleet_details" value="<?php echo $fleet_details; ?>" required>
		 </div>		 
   <?php } ?>

   <?php if($hotel_type2 == 'Attractions'){ ?>
   		 <div class="form-group">
		    <label for="Description">Description:</label>
		    <input type="text" name="description" class="form-control description" id="description" value="<?php echo $description; ?>" required>
		 </div>

		 <div class="form-group">
		    <label for="entry_fees">Entry Fees:</label>
		    <input type="text" name="entry_fees" class="form-control entry_fees" id="entry_fees" value="<?php echo $entry_fees; ?>" required>
		 </div>	 
   <?php } ?>

   <?php if($hotel_type2 == 'Restaurants'){ ?>
   		 <div class="form-group">
		    <label for="Description">Description:</label>
		    <input type="text" name="description" class="form-control description" id="description" value="<?php echo $description; ?>" required>
		 </div>

		 <div class="form-group">
		    <label for="cuisines">Cuisines:</label>
		    <input type="text" name="cuisines" class="form-control cuisines" id="cuisines" value="<?php echo $cuisines; ?>" required>
		 </div>	 

		 <div class="form-group">
		    <label for="timings">Timings:</label>
		    <input type="text" name="timings" class="form-control timings" id="timings" value="<?php echo $timings; ?>" required>
		 </div>
   <?php } ?>

   
   </div>

   <div class="add_partners_form mt-4">
   	<label for="Photos">Photos: <span style="color:red;">(Note:only upload jpg, png and jpeg)</span></label>
        <div class="row">
		  <div class="col-sm-6 mb-4">
		  	<input type="file" name="photos1" class="my-pond photos1" id="photos1" value="<?php echo $photos1; ?>" />
		  	<?php if(!empty($photos1)){ ?>
		    	<a href="../uploads/<?php echo $photos1; ?>" download>Download</a>
		    <?php } ?>
		  </div>

		  <div class="col-sm-6 mb-4">
		  	<input type="file" name="photos2" class="my-pond photos2" id="photos2" value="<?php echo $photos2; ?>" />
		  	<?php if(!empty($photos2)){ ?>
		    	<a href="../uploads/<?php echo $photos2; ?>" download>Download</a>
		    <?php } ?>
		  </div>

		  <div class="col-sm-6 mb-4">
		  	<input type="file" name="photos3" class="my-pond photos3" id="photos3" value="<?php echo $photos3; ?>" />
		  	<?php if(!empty($photos3)){ ?>
		    	<a href="../uploads/<?php echo $photos3; ?>" download>Download</a>
		    <?php } ?>
		  </div>

		  <div class="col-sm-6 mb-4">
		  	<input type="file" name="photos4" class="my-pond photos4" id="photos4" value="<?php echo $photos4; ?>" />
		  	<?php if(!empty($photos4)){ ?>
		    	<a href="../uploads/<?php echo $photos4; ?>" download>Download</a>
		    <?php } ?>
		  </div>
   
    </div>
</div>
	
   <input type="hidden" name="amount" value="1">
   <input type="hidden" name="currency" value="GBP">
   <input type="hidden" name="tid" value="<?php echo $getid; ?>">
   <input type="hidden" name="user_id" value="<?php echo $user_id; ?>">
   <input type="hidden" name="hotel_type" value="<?php echo $hotel_type2; ?>">
   <input type="hidden" name="paid_type" value="Paid">
   

    <button type="submit" class="btn btn-default submit_btn float-right" id="registerbtn">SUBMIT</button>

          </form>
       </div>
    </div>
  </div>  
</section>

<div class="loading_icon"></div>

<?php include("../footer.php"); ?>
<?php
if(!empty($apt_fix_departures)){			
?>
<script>
	$('.fix_departures_class').show();
</script>
<?php } ?>

<?php if(!empty($getid)){
    $logo_3 = "$('#logo').attr('value')";
 }else{
 	$logo_3 = "$('#logo').val()"; 	
 } ?>

<?php if($roles1 == 'Admin'){
    $url_redirect = "window.location.href='../list_all';";
 }else{
 	$url_redirect = "window.location.href='../travel_list';"; 	
 } ?>

<script>
$('.airport_transfersfix').on('click', function(){
	if($(this).is(':checked')){
  		$('.fix_departures_class').show();
  	}else{
 		$('.fix_departures_class').hide();
 	}	
});
</script>

<script>
$('.CityDiv').on('click', function(){
	$('.city_new').show();
	$('.saveCity').show();
	$('.CityOption').hide();
	$('.CityOldbtn').show();
	$('.CityDiv').hide();
	$(".CityOption option:first-child").html("<option value=''>Select Option</option>");	
});

$('.CityOldbtn').on('click', function(){
	$('.loading_icon').show();
	$('.CityOldbtn').hide();
	$('.CityDiv').show();
	$('.CityOption').show();
	$('.city_new').hide();
	$('.saveCity').hide();

	$.post("../response.php?tag=CityShow", function(d){
		$(".CityOption").html(" ");
		$(".CityOption").html("<option value=''>Select Option</option>");		
		for (i in d) {
			$('<option value="' + d[i].namecity + '">'+ d[i].namecity +'</option>').appendTo(".CityOption");
		}
	$('.loading_icon').hide();		
	});
});

var exitCity;
$(document).ready(function () {
	$('#city_new').keyup(CityInput);
});

function CityInput(){
	var city2 = $('.city_new').val();
	$.post("../response.php?tag=cityExist", {"city": city2}, function (d) {
		if (d == true) {
			exitCity = '0';
			$('.error_city').html(" ").css({"color": "#fff", "background-color": "#fff", "width": "100%", "padding":"0"});
		}
		if (d == false) {
			exitCity = '1';
			$('.error_city').html("City already exist!!!").css({"color": "#fff", "background-color": "#ee9715", "left": "10%", "top": "84px", "text-align": "center", "position": "absolute", "font-size": "12px", "padding": "7px", "border-radius":"5px", "width":"88%"});
		}		
	});
}

$('.saveCity').on('click', function(){
	$('.loading_icon').show();
	var city2 = $('.city_new').val();
	if(city2 == "") {
		$('.city_new').css({"border":"1px solid red"});		
	}
	if(city2 == "" || exitCity == '1'){
		$('.loading_icon').hide();
		return false;
	}

	$.post("../response.php?tag=newCityAdd", {"city": city2}, function (d) {
	if(d == 1){
			$('.CityOption').show();
			$('.city_new').val(" ");
			$('.city_new').hide();
			$('.saveCity').hide();

	$.post("../response.php?tag=CityShow", function(d){
		$(".CityOption").html(" ");
		$(".CityOption").html("<option value=''>Select Option</option>");		
		for (i in d) {
			$('<option value="' + d[i].namecity + '">'+ d[i].namecity +'</option>').appendTo(".CityOption");
		}
	$('.loading_icon').hide();		
	});	


		}
	});	
});
</script>
<script>
var emailValid_Reg;
var mobileValid_Reg;
var validDigit;
$(document).ready(function () {
	$('#company_name').keyup(company_name);
	$('#address_2').keyup(address_2);
	$('#country').keyup(country);
	$('#city').keyup(city);
	$('#pin').keyup(pin);
	$('#telephone').keyup(telephone);
	$('#email').keyup(email);
	$('#website').keyup(website);
	$('#logo').keyup(logo);
	$('#star_category').keyup(star_category);
	$('#contact_person').keyup(contact_person);
});

function company_name(){	
	var company_name1 = $('#company_name').val();
	if(company_name1 == "") {
		$('.company_name').css({"border":"1px solid red"});
	} else {
		$('.company_name').css({"border":"1px solid #CCCCCC"});
	}
} 

function email(){	
	var email1 = $('#email').val();
	var validformateEmail = /^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/;		
	if(email1 == "") {
		$('.email').css({"border-bottom":"1px solid red"});
	} else {
		$('.email').css({"border-bottom":"1px solid #CCCCCC"});
	}
	if (validformateEmail.test(email1) == false){
		emailValid_Reg = '1';
		$('.email').css({"border-bottom":"1px solid red"});
		
	}
	if (validformateEmail.test(email1) == true){
		emailValid_Reg = '0';
		$('.email').css({"border-bottom":"1px solid #CCCCCC"});
	}
}

function telephone(){	
	var telephone1 = $('#telephone').val();	
	var validateMobNum = /^\d*(?:\.\d{1,2})?$/;				
	if(telephone1 == "") {
		$('.telephone').css({"border-bottom":"1px solid red"});
	} else {
		$('.telephone').css({"border-bottom":"1px solid #CCCCCC"});
	}
	if (validateMobNum.test(telephone1) == false){
		mobileValid_Reg = '1';
		$('.telephone').css({"border-bottom":"1px solid red"});
	}
	if (validateMobNum.test(telephone1) == true){
		mobileValid_Reg = '0';
		$('.telephone').css({"border-bottom":"1px solid #CCCCCC"});
	}	
	var cntMobileNo = telephone1.length;
	
	if(cntMobileNo == 10){
		validDigit = 0;
		$('.error_calling_reg').html(" ").css({"color": "#fff", "background-color": "#fff", "padding":"0"});
	}else{
		validDigit = 1;
		$('.error_calling_reg').html("Please enter 10 digit valid mobile number.").css({"color": "#fff", "background-color": "rgb(72, 65, 59)", "font-size": "13px", "float": "left", "padding": "5px 5px", "position": "absolute", "text-align": "center", "width": "92%", "z-index": "1", "border-radius":"5px"});
	}
	
}

function address_2(){	
	var address1 = $('#address_2').val();
	if(address1 == "") {
		$('.address_2').css({"border-bottom":"1px solid red"});
	} else {
		$('.address_2').css({"border-bottom":"1px solid #CCCCCC"});
	}
}

function country(){	
	var country1 = $('#country').val();
	if(country1 == "") {
		$('.country').css({"border-bottom":"1px solid red"});
	} else {
		$('.country').css({"border-bottom":"1px solid #CCCCCC"});
	}
}

function city(){	
	var city1 = $('#city').val();
	if(city1 == "") {
		$('.city').css({"border-bottom":"1px solid red"});
	} else {
		$('.city').css({"border-bottom":"1px solid #CCCCCC"});
	}
}

function pin(){	
	var pin1 = $('#pin').val();
	if(pin1 == "") {
		$('.pin').css({"border-bottom":"1px solid red"});
	} else {
		$('.pin').css({"border-bottom":"1px solid #CCCCCC"});
	}
}

function website(){	
	var website1 = $('#website').val();
	if(website1 == "") {
		$('.website').css({"border-bottom":"1px solid red"});
	} else {
		$('.website').css({"border-bottom":"1px solid #CCCCCC"});
	}
}

function logo(){	
	var logo1 = $('#logo').val();
	if(logo1 == "") {
		$('.logo').css({"border-bottom":"1px solid red"});
	} else {
		$('.logo').css({"border-bottom":"1px solid #CCCCCC"});
	}
}

function star_category(){	
	var star_category1 = $('#star_category').val();
	if(star_category1 == "") {
		$('.star_category').css({"border-bottom":"1px solid red"});
	} else {
		$('.star_category').css({"border-bottom":"1px solid #CCCCCC"});
	}
}

function contact_person(){	
	var contact_person1 = $('#contact_person').val();
	if(contact_person1 == "") {
		$('.contact_person').css({"border-bottom":"1px solid red"});
	} else {
		$('.contact_person').css({"border-bottom":"1px solid #CCCCCC"});
	}
}

</script>

<?php if($hotel_type2 == 'Hotel'){ ?>
<script>
$("#registerbtn").click(function(){
    var checked = $('[name="facilities[]"]:checked').length > 0;
    if (!checked){
        alert("Please check at least one facilities");
        return false;
    }
});
</script>
<?php } ?>

<?php if($hotel_type2 == 'Transport'){ ?>
<script>
$("#registerbtn").click(function(){
    var checked2 = $('[name="airport_transfers[]"]:checked').length > 0;
    if (!checked2){
        alert("Please check at least one airport transfers");
        return false;
    }
});
</script>
<?php } ?>

<script>
// $('#registerbtn').on('click', function(e){

// $('.loading_icon').show();
// $("#registerbtn").attr("disabled", true);
// 	e.preventDefault();
// 	var company_name2 = $('#company_name').val();
// 	var address2 = $('#address_2').val();
// 	var city2 = $('#city').val();
// 	var pin2 = $('#pin').val();
// 	var telephone2 = $('#telephone').val();
// 	var email2 = $('#email').val();
// 	var website2 = $('#website').val();
// 	var country2 = $('#country').val();
// 	var logo2 = <?php //echo $logo_3; ?>

// 	var star_category2 = $('#star_category').val();
// 	var contact_person2 = $('#contact_person').val();	
	
// 	if(company_name2 == "") {
// 		$('.company_name').css({"border-bottom":"1px solid red"});		
// 	}
// 	if(address2 == "") {
// 		$('.address_2').css({"border-bottom":"1px solid red"});		
// 	} 
// 	if(country2 == "") {
// 		$('.country').css({"border-bottom":"1px solid red"});		
// 	}
// 	if(city2 == "") {
// 		$('.city').css({"border-bottom":"1px solid red"});		
// 	}
// 	if(pin2 == "") {
// 		$('.pin').css({"border-bottom":"1px solid red"});		
// 	}	
// 	if(telephone2 == "") {
// 		$('.telephone').css({"border-bottom":"1px solid red"});		
// 	}
// 	if(email2 == "") {
// 		$('.email').css({"border-bottom":"1px solid red"});		
// 	}
// 	if(website2 == "") {
// 		$('.website').css({"border-bottom":"1px solid red"});		
// 	}
// 	if(logo2 == "") {
// 		$('.logo').css({"border-bottom":"1px solid red"});		
// 	}else{		
// 		 $(".logo").css({"border-bottom":"1px solid #CCCCCC"});		
// 	}
// 	if(star_category2 == "") {
// 		$('.star_category').css({"border-bottom":"1px solid red"});		
// 	}
	
// 	if(contact_person2 == "") {
// 		$('.contact_person').css({"border-bottom":"1px solid red"});		
// 	}
	
	
	// if(company_name2 == "" || address2 == "" || city2 == ""  || pin2 == "" || emailValid_Reg == 1 ||  mobileValid_Reg == 1 ||  telephone2 == "" || email2 == "" || website2 == "" || logo2 == "" || star_category2 == "" || contact_person2 == ""){
	// $("#registerbtn").attr("disabled", false);
	// $('.loading_icon').hide();
	// 	return false;
	// }
	
	// var form=document.getElementById('registerFrm');
	// var fdata=new FormData(form); 
	// $.ajax({
	// 	type: "POST",
	// 	url: '../response.php?tag=newHotelpaid',
	// 	data: fdata,
	// 	contentType: false,
	// 	cache: false,
	// 	processData:false,
	// 	success: function(result){
	// 		if(result == 1){
	// 		  <?php //echo $url_redirect; ?> 
	// 		  $("#registerFrm")[0].reset();
	// 		  $("#registerbtn").attr("disabled", false);
	// 		  $('.loading_icon').hide();
	// 		  return false;
	// 		}
	// 		if(result == 11 || result == 2 || result == 3 || result == 4){
	// 			alert('File is not Supported (Please upload the JPG, PNG and JPEG Files)');
	// 			$('.loading_icon').hide();
	// 			$("#registerbtn").attr("disabled", false);
	// 			return false;
	// 		}
	// 	}
	// });	
	
// });	
</script>