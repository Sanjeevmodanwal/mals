<form method="post" action="pay.php">
	<!--<input type="hidden" name="visa_amount_total" value="<?php echo $country_price_2;?>">
	<input type="hidden" name="mobile_number" value="<?php //echo $mobile;?>">
	<input type="hidden" name="email_id" value="<?php// echo $email_id;?>">	
	<input type="hidden" name="user_id" value="<?php //echo $sess_id; ?>">
	<input type="hidden" name="client_id" value="<?php// echo $lastid_client;?>">--->
	
	<input type="hidden" name="item_name" value="test">
	<input type="hidden" name="item_description" value="rsting alfa">
	<input type="hidden" name="item_number" value="aydsaysufsudgfu sdu">
	<input type="hidden" name="amount" value="1">
	<input type="hidden" name="currency" value="USD">	
	<input type="hidden" name="cust_name" value="Sanjiv Kumar">								
	<input type="hidden" name="email" value="sanjiv@essglobal.com">	
	<input type="hidden" name="contact" value="9115656334">	
	<input type="hidden" name="user_id" value="1">
	<input type="hidden" name="client_id" value="123">
	
   <button type="submit" class="btn btn-default action-button mr-sm-5 mr-4 float-right">Make Payment</button>
</form>