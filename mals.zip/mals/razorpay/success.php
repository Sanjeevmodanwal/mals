<?php
include("db.php");

?>
<div class="container">
<div class="row">
<div class="col-12">

<?php
if($_GET['payment_status']=='Credit')
{
	$pamentid = $_GET['payment_id'];
	$payment_request_id = $_GET['payment_request_id'];
	$update_query = "UPDATE `payment_status` SET `status`= 'Complete',`payment_id`='$pamentid' WHERE payment_request_id='$payment_request_id'";
	$payment_rqst_id = mysqli_query($con, $update_query);
	
	$get_data = 'SELECT * From payment_status where payment_id="'.$pamentid.'"';	
	$rsltqry_data = mysqli_query($con, $get_data);
    $rowpay_data = mysqli_fetch_array($rsltqry_data);
	// echo '<pre>';
	// print_r($rowpay_data);
	// die;
	$email = $rowpay_data['email'];
	$mobile = $rowpay_data['mobile'];
	$amount = $rowpay_data['amount'];
	$pay_status = $rowpay_data['status'];
	$payment_id = $rowpay_data['payment_id'];
	$paymentdate = $rowpay_data['paymentdate'];
	$user_done = $rowpay_data['complete'];
		
		echo '<p style="padding-top:50px; padding-bottom:0px; text-align:center; font-size:16px; font-weight:500;"><span style="text-align:center;"><i style="font-size: 26px;
    background: green;
    color: #fff;
    height: 60px;
    width: 60px;
    border-radius: 50%;
    line-height: 60px;" class="fa fa-check" aria-hidden="true"></i></span></p>';
	?>
	<div class=" p-0 col-lg-6 offset-lg-3 mb-4">
	<div class="table-responsive">
    <table class="table table-bordered table-hover table-striped">
		<tr>
		  <th scope="row">Amount</th>
		  <td><?php echo 'Rs.'.$amount;?></td>
		</tr>
		<tr>
		  <th scope="row">Payment Status</th>
		  <td><?php echo $pay_status;?></td>
		</tr>		
		<tr>
		  <th scope="row">Your Transaction ID is</th>
		  <td><?php echo $payment_id;?></td>
		</tr>
		<tr>
		  <th scope="row">Payment Date</th>
		  <td><?php echo $paymentdate;?></td>
		</tr>
    </table>	
	</div>
	</div>
	
	<?php
		
   	if($user_done == ''){
	$subject2 = "Testindatat - Fees Paid Successfully";
	$to2 = $email;
	$msg1 = "<b>Dear,</b><br><br>";
	$msg2 = "<p>Thank you for paying the fee atTestingdatat. </p>";
	$msg3 = "<p>Your Transaction ID is : $payment_id </p>";
	$msg4 = "<p>For any further information / queries, please contact us at +91-00000000.</p>";
	$msg5 = "<p>We wish you all the best.</p>";
	$msg6 = "<p>Thanks,</p>";
	$msg7 = "<p> testing data</p>";
	$msg8 = "<p>+91-000000000</p>";
	$msg9 = "<p>dysagucsucsgu</p>";
	$message2 = $msg1.''.$msg2.''.$msg3.''.$msg4.''.$msg5.''.$msg6.''.$msg7.''.$msg8.''.$msg9;
	
	$headers2 = "MIME-Version: 1.0" . "\r\n";
	$headers2 .= "Content-type:text/html;charset=UTF-8" . "\r\n";
	$headers2 .= 'From: sfyusdfgis<virendra@essglobal.com>' . "\r\n";
   // $headers2 .= 'Cc: info@o' . "\r\n";
   
	
	mail ($to2,$subject2,$message2,$headers2);
	
	
	//////////////////////////To cc/////////////////////
	
	$subject3 = "tesinguag - $email - $mobile";

	$to12 = 'virendra@essglobal.com';	
	$message3 = '<!DOCTYPE html>
<html lang="en">
<head>
  <title>testing dATA</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
 <style>
 table { border:0px;  border-collapse:collapse;}
 .mail-table {max-width:652px; width:100%; height:100%; 
 margin:7% auto; box-shadow:0px 0px 10px #999;}
 .mail-table td {max-width:652px; width:100%;text-align:left; }
 .top_bg { width:100%; }
 .bottom_bg { width:100%;margin: 0px -3px -20px 0px; }
 .logo {position: relative;margin-top: 5%;width: 40%;margin-left: 40px;text-align: center;
 width: 17%;}
 .mail-table h4{margin-left: 40px;margin-bottom: 8px;}
  .mail-table h3 { font-size:21px;margin-bottom:0;    
  color: #c6163e; margin-right:40px; margin-left:40px;}
    .mail-table p.text { padding:0px 40px 0px;  width:86%; 
	margin-bottom:-25px; position:relative; z-index:999;}
    .mail-table p.phone { padding:20px 40px;  position:absolute; z-index:999; max-width:270px; float:right;}
	.footer_text { width:220px; float:right;margin-top:-18%; position:relative; }	
	.footer_text p a { color:#fff; text-decoration:none; }
	.footer_text p img { margin:6px 5px;}	
 </style>
</head><body>
<table class="mail-table">
<tbody>
<tr>
<td>
<img src="" class="logo" alt="logo">
</td></tr>
<tr><td>
<p class="text">Dear Team,</p><br><br>
<p class="text" style="font-size:13px;">New BOOKING FOR TESTING DATAT.</p><br><br>
<b>Transaction ID is </b> '.$pamentid.'<br>
</p>
</td></tr>
<tr>
<td>
<h4 style="color:#cc3054;margin-top:40px;">Best Wishes,<br> Team SFYSDFGSDFSD 
</h4>
</td>
</tr>
<tr>
<td>
<img src="" class="bottom_bg" alt=""></td>
</tr>
</tbody>
</table>
</body>
</html>';
	
	$headers12 = "MIME-Version: 1.0" . "\r\n";
	$headers12 .= "Content-type:text/html;charset=UTF-8" . "\r\n";
	$headers12 .= 'From: ASYSFSD<virendra@essglobal>' . "\r\n";
   
	
	
	mail ($to12,$subject3,$message3,$headers12);
	
	}
	
	$update_query = "UPDATE `payment_status` SET `complete`='1' WHERE payment_request_id='$payment_request_id'";
	mysqli_query($con, $update_query);
	
	// }
}
else
{
	$pamentid = $_GET['payment_id'];
	$payment_request_id = $_GET['payment_request_id'];
	$update_query = "UPDATE `payment_status` SET `pstatus`= 'Failed',`payment_id`='$pamentid' WHERE payment_request_id='$payment_request_id'";
	if(mysqli_query($con, $update_query))
	{	
		echo 'Payment failed';
	}
}



?>

</div>
</div>
</div>

