<?php
session_start();
include("../db.php");
date_default_timezone_set("Asia/Kolkata");

if(isset($_GET['add_to_cart'])){
	
	if(isset($_POST['size'])){
		$size = $_POST['size'];
	} else {
		$size = '';
	} 
	
	if(isset($_POST['quantity'])){
		$quantity = $_POST['quantity'];
	} else {
		$quantity = '';
	} 
	
	if(!empty($_POST['Chest_Width'])){
		$Chest_Width = $_POST['Chest_Width'];
	} else {
		$Chest_Width = '';
	} 
	if(!empty($_POST['Waist'])){
		$Waist = $_POST['Waist'];
	} else {
		$Waist = '';
	}  
	if(!empty($_POST['Body_Length'])){
		$Body_Length = $_POST['Body_Length'];
	} else {
		$Body_Length = '';
	} 

	if(!empty($_POST['Sleeve_Length'])){
		$Sleeve_Length = $_POST['Sleeve_Length'];
	} else {
		$Sleeve_Length = '';
	}
	
	if(!empty($_POST['p_id'])){
		$p_id = $_POST['p_id'];
	} else {
		$p_id = '';
	}
	
	$created_date = date('Y-m-d');
	$pro_item = "SELECT * FROM products where id ='$p_id' and status='1'";
	$get_pro_res = mysqli_query($con, $pro_item);
	while($pro_data = mysqli_fetch_array($get_pro_res)){
		 $pro_id = $pro_data['id'];
		 $itemArray = array($p_id=>array('pro_id'=>$pro_id, 'size'=>$size, 'pro_cw'=>$Chest_Width, 'pro_w'=>$Waist, 'pro_bl'=>$Body_Length, 'pro_sl'=>$Sleeve_Length, 'pro_quantity'=>$quantity));
	}
	
	if(!empty($_SESSION["username"])) {
		 $user_email = $_SESSION['username'];
		 $get_user_query = "SELECT sno FROM users where username='$user_email'";
		 $get_user_res = mysqli_query($con, $get_user_query);
		 $get_user_data = mysqli_fetch_array($get_user_res);
		 $user_id = $get_user_data['sno'];
		 $add_to_cart ="INSERT INTO `cart_items`(`user_id`, `product_id`, size, `quantity`, pro_cw, pro_w, pro_bl, pro_sl, `created_date`,`cart_status`) VALUES ('$user_id','$p_id', '$size', '$quantity','$Chest_Width', '$Waist', '$Body_Length', '$Sleeve_Length', '$created_date','0')";
		  $get_pro_res = mysqli_query($con, $add_to_cart);
	} else {
			if(!empty($_SESSION["cart_item"])) {
				if(in_array($p_id,array_keys($_SESSION["cart_item"]))) {
					foreach($_SESSION["cart_item"] as $k => $v) {
							if($p_id == $k) {
								if(empty($_SESSION["cart_item"][$k]["pro_quantity"])) {
									$_SESSION["cart_item"][$k]["pro_quantity"] = 0;
								}
								$_SESSION["cart_item"][$k]["pro_quantity"] += $quantity; 
								
							}
					}
				} else {
					$_SESSION["cart_item"] = array_merge($_SESSION["cart_item"],$itemArray);
				}
			} else {
				$_SESSION["cart_item"] = $itemArray;
			}
		}
	
	echo 1;
	exit();
}

if(isset($_GET['buy_now_btn'])){
	if(isset($_POST['size'])){
		$size = $_POST['size'];
	} else {
		$size = '';
	}
	
	if(isset($_POST['quantity'])){
		$quantity = $_POST['quantity'];
	} else {
		$quantity = '';
	} 
	
	if(!empty($_POST['Chest_Width'])){
		$Chest_Width = $_POST['Chest_Width'];
	} else {
		$Chest_Width = '';
	} 
	if(!empty($_POST['Waist'])){
		$Waist = $_POST['Waist'];
	} else {
		$Waist = '';
	}  
	if(!empty($_POST['Body_Length'])){
		$Body_Length = $_POST['Body_Length'];
	} else {
		$Body_Length = '';
	} 

	if(!empty($_POST['Sleeve_Length'])){
		$Sleeve_Length = $_POST['Sleeve_Length'];
	} else {
		$Sleeve_Length = '';
	}
	
	if(!empty($_POST['p_id'])){
		$p_id = $_POST['p_id'];
	} else {
		$p_id = '';
	}
	
	$created_date = date('Y-m-d');
	$pro_item = "SELECT * FROM products where id ='$p_id' and status='1'";
	$get_pro_res = mysqli_query($con, $pro_item);
	while($pro_data = mysqli_fetch_array($get_pro_res)){
		 $pro_id = $pro_data['id'];
		 $itemArray = array($p_id=>array('pro_id'=>$pro_id, 'size'=>$size, 'pro_cw'=>$Chest_Width, 'pro_w'=>$Waist, 'pro_bl'=>$Body_Length, 'pro_sl'=>$Sleeve_Length, 'pro_quantity'=>$quantity));
	}
	
	if(!empty($_SESSION["username"])) {
		 $user_email = $_SESSION['username'];
		 $get_user_query = "SELECT sno FROM users where username='$user_email'";
		 $get_user_res = mysqli_query($con, $get_user_query);
		 $get_user_data = mysqli_fetch_array($get_user_res);
		 $user_id = $get_user_data['sno'];
		 $add_to_cart ="INSERT INTO `cart_items`(`user_id`, `product_id`, size, `quantity`, pro_cw, pro_w, pro_bl, pro_sl, `created_date`,`cart_status`) VALUES ('$user_id','$p_id', '$size', '$quantity','$Chest_Width', '$Waist', '$Body_Length', '$Sleeve_Length', '$created_date','0')";
		  $get_pro_res = mysqli_query($con, $add_to_cart);
		 echo 1;
		 die();
	} else {
		if(!empty($_SESSION["cart_item"])) {
				if(in_array($p_id,array_keys($_SESSION["cart_item"]))) {
					foreach($_SESSION["cart_item"] as $k => $v) {
							if($p_id == $k) {
								if(empty($_SESSION["cart_item"][$k]["pro_quantity"])) {
									$_SESSION["cart_item"][$k]["pro_quantity"] = 0;
								}
								$_SESSION["cart_item"][$k]["pro_quantity"] += $quantity; 
								
							}
					}
				} else {
					$_SESSION["cart_item"] = array_merge($_SESSION["cart_item"],$itemArray);
				}
			} else {
				$_SESSION["cart_item"] = $itemArray;
			}
		}
	
	echo 2;
	exit();
}


?>

