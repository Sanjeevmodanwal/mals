<?php
session_start();
include("db.php"); 
date_default_timezone_set("Asia/Kolkata");
?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>Mals</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="../css/bootstrap.min.css">
<link rel="stylesheet" href="../css/style-sheet.css">
<link rel="stylesheet" href="../css/responsive.css">
<link rel="stylesheet" href="../css/all.css">
<script src="../js/jquery.min.js"></script>
<script src="../js/script.js"></script>
<script src="../js/bootstrap.min.js"></script>
<link href="https://fonts.googleapis.com/css?family=Roboto+Condensed" rel="stylesheet">
</head>
<body>
<div class="body-inner">
	<div id="top-bar" class="top-bar">
		<div class="container">
			<div class="row">
				
				<div class="col-md-6 col-sm-4 col-12 top-social">
					<ul class="unstyled">
						<li>
							<a title="Facebook" href="#">
								<span class="social-icon"><i class="fab fa-facebook"></i></span>
							</a>
							<a title="Twitter" href="#">
								<span class="social-icon"><i class="fab fa-twitter"></i></span>
							</a>
							<a title="Google+" href="#">
								<span class="social-icon"><i class="fab fa-google-plus"></i></span>
							</a>
							<a title="Linkdin" href="#">
								<span class="social-icon"><i class="fab fa-linkedin"></i></span>
							</a>
							<a title="instagram" href="#">
								<span class="social-icon"><i class="fab fa-instagram"></i></span>
							</a>
						</li>
					</ul>
				</div><!--/ Top social end -->

				<div class="col-md-6 col-sm-8 col-12 top-menu ">
					<ul class="unstyled">
						<li><a href="tel:7508225311">750 822 5311</a></li>
						<!--li><a href="signup/">Registration</a></li-->
						<?php if(!empty($_SESSION["username"])) {
						 $sno121s = $_SESSION["sno"];
						 $get_user_noti_query323 = "SELECT otp FROM users where sno='$sno121s'";
						 $get_user_noiti_res323 = mysqli_query($con, $get_user_noti_query323);
						 $get_user_noti_data323 = mysqli_fetch_array($get_user_noiti_res323);
						 $user_otp = $get_user_noti_data323['otp'];
						 if(empty($user_otp)){
						?>
							<li><a href="../dashboardag/">My Account</a></li>
						<?php } ?>
							<li><a href="../logout.php">Logout</a></li>
						<?php }else{ ?>
							<li><a href="../login/">Login</a></li>
							
						<?php } ?>
						
					</ul>
				</div><!--/ Top menu end -->

			</div><!--/ Content row end -->
		</div><!--/ Container end -->
	</div><!--/ Topbar end -->

	<!-- Header start -->
	<header id="header" class="header">
		<div class="container">
			<div class="row">
				<div class="logo col-12 col-sm-3 col-xl-2">
                <a href="index.php">
                	<img src="../images/logo.png" class="img-fluid float-left" alt="" width="100">
					<p class="mt-sm-2 mt-5 text-left pt-sm-1" style="font-size: 14px; font-weight: bold; margin-top: 14px; margin-bottom:0px;">Mals Enterprises Pvt. Ltd.</p>
                </a>
         	</div><!-- logo end -->

         	<div class="col-12 col-sm-9 col-xl-10 header-right float-right">
         		<ul class="top-info">
						
						<li>
							<div class="info-box"><span class="info-icon"><i class="fa fa-map-marker-alt">&nbsp;</i></span>
								<div class="info-box-content">
									<p class="info-box-title">Mals</p>
									<p class="info-box-subtitle">#399,Vill.-Jawahar Puri,Teh.-Dera Bassi,<br>Dist.-Mohali</p>
								</div>
							</div>
						</li>
						<li>
							<div class="info-box"><span class="info-icon"><i class="fa fa-phone">&nbsp;</i></span>
								<div class="info-box-content">
									<p class="info-box-title"><a href="tel:7508225311">750 822 5311</a></p>
									<p class="info-box-subtitle"><a href="mailto:support@mals.co.in">support@mals.co.in</a></p>
								</div>
							</div>
						</li>
						<li>
							<div class="info-box  d-none d-sm-block"><span class="info-icon"><i class="far fa-compass">&nbsp;</i></span>
								<div class="info-box-content">
									<p class="info-box-title">9.30 Am- 5.00 Pm</p>
									<p class="info-box-subtitle">Monday to Saturday</p>
								</div>
							</div>
						</li>
					
					</ul>
         	</div><!-- header right end -->
</div></div></header>

<nav class="navbar site-navigation navbar-expand-lg"><div class="container">
<div class="site-nav-inner float-left">
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
  <i class="fas fa-bars"></i>
  </button>
  <div class="collapse navbar-collapse justify-content-end" id="collapsibleNavbar">
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" href="/">Home</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="../about">About Us</a>
      </li>
	  <li class="nav-item">
        <a class="nav-link" href="../shop/">Products</a>
      </li>
	  
	  <!--li class="nav-item"><a class="nav-link"  href="../plans"> Income Opportunity</a></li>
	   <li class="nav-item"><a class="nav-link"  href="../rewards">Rewards</a></li-->
	   
    <!---  <li class="nav-item">
        <a class="nav-link" href="../faq">Faq</a>
      </li>--->
	  <li class="nav-item">
        <a class="nav-link" href="../terms_conditions">Terms & Conditions</a>
      </li>        
	    <li class="nav-item">
        <a class="nav-link" href="../contact">Contact Us</a>
      </li>    
    </ul>
  </div>  
  </div>
  
	<div class="find-agent float-right dropdown">
		<a class="dropdown-toggle" data-toggle="dropdown" href="#">Cart</a>
		<span id="notification_data">
		<?php
			if(!empty($_SESSION["username"])) {
				  $user_email_noti = $_SESSION['username'];
				 $get_user_noti_query = "SELECT sno FROM users where username='$user_email_noti'";
				 $get_user_noiti_res = mysqli_query($con, $get_user_noti_query);
				 $get_user_noti_data = mysqli_fetch_array($get_user_noiti_res);
				 $user_noti_id = $get_user_noti_data['sno'];
				 $add_to_cart_noti = "SELECT * FROM cart_items where user_id='$user_noti_id' and cart_status='0'";
				 $get_pro_res_noti_1 = mysqli_query($con, $add_to_cart_noti);
				 while ($get_prodata_noti_1 = mysqli_fetch_array($get_pro_res_noti_1)){
					$id_noti  = $get_prodata_noti_1['sno'];
					$sess_pro_noti_id[]  = $get_prodata_noti_1['product_id'];
				 }
			} else {
				
				if(!empty($_SESSION["cart_item"])) {
					foreach($_SESSION["cart_item"] as $k => $v) {
						$sess_pro_noti_id[]  = $v['pro_id'];
						
					}
				}
			}
			
		?>		
		<b><?php if(!empty($sess_pro_noti_id)) { echo count($sess_pro_noti_id); } else { echo 0; }?></b>
		<ul class="dropdown-menu dropdown-menu-right">		
			<li class="text-left">
			<?php
			if(!empty($sess_pro_noti_id)) {
				$imp_item_not_data = implode("','", $sess_pro_noti_id);
			}else{
				$imp_item_not_data = '';
			}
			$get_pro_noti = "SELECT * FROM products where id IN ('$imp_item_not_data') and status='1'";
			$get_pro_noti_res = mysqli_query($con, $get_pro_noti);
			while($item_data_noti = mysqli_fetch_array($get_pro_noti_res)){
				$product_img1 = $item_data_noti['product_img1'];
				$product_title = $item_data_noti['product_title'];
			?>
				<a class="dropdown-item text-dark" href="../checkout">
				<img class="img-fluid" src="../uploads/products/<?php echo $product_img1; ?>" alt="" style="width:30px;height:30px; border-radius:30px; margin-right: 5px;"> 
				<?php echo $product_title; ?>
				</a>
			<?php } ?>
			</li>
			<?php
			if(!empty($sess_pro_noti_id)) {
				?>
			<li  class="text-center" style="background: #eee;">
				<a href="../checkout/" style="line-height: 28px;color:#3a5371;border:0px;" class=""><i class="fa fa-eye"></i> Show All</a>
			</li>
			<?php }else{ ?>
			<li  class="text-center">Not Found</li>
			<?php } ?>
		</ul>
		</span>
	</div>
	
  </div>
</nav>
	
	<!--div class="banner"> <img src="../images/banner-img.jpg" class="img-fluid banner-img"> </div-->