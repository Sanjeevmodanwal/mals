<?php
session_start();
include("../db.php");
if(!empty($_GET["action"])) {
switch($_GET["action"]) {
	case "quantiy":
		if(!empty($_POST["cartid"])) {
			$cartid = $_POST['cartid'];
			$getval = $_POST['getval'];
			$update_table = "UPDATE cart_items set quantity='$getval' where sno='$cartid'";
			$update_res = mysqli_query($con, $update_table);
			if($update_res== 'TRUE'){
				echo 1;
				exit();
			}
		}
	break;
  
}
}

?>

