<?php
ob_start();
include("../db.php");
include("../header.php");
date_default_timezone_set("Asia/Kolkata");

if(!isset($_SESSION['sno'])){
    header("Location: ../login");
    exit();
}

if(!empty($_SESSION['username'])){	
	if(!empty($_GET["action"])) {
	switch($_GET["action"]) {
		case "remove":
		if(isset($_GET['code'])){
			$code = $_GET['code'];
			$cart_delete = "DELETE FROM cart_items WHERE sno='$code'";
			mysqli_query($con, $cart_delete);			
		}
		break;
		case "empty":
			unset($_SESSION["cart_item"]);
		break;	
	}
	}

$sess_id = $_SESSION['sno'];
$add_to_cart_noti = "SELECT * FROM cart_items where user_id='$sess_id' and cart_status='0'";
$get_pro_res_noti_1 = mysqli_query($con, $add_to_cart_noti);
$get_num_of_data  = mysqli_num_rows($get_pro_res_noti_1);
	
if($get_num_of_data < 1){
	header("location:../shop/");
}
?>

<script>
jQuery(document).ready(function(){	
	$('.qty').change(function(e){
		var getval =  $(this).val();
		var cartid = $(this).attr('cartid');
		 $.ajax({
			type: "POST",
			url: "ajaxdata.php?action=quantiy",
			data: {getval: getval,cartid: cartid},
			success: function(data){
				setTimeout(function(){
						location.reload(); 
					}, 500); 
				
			}
		});
	});
});
</script>

<section class="checkout py-lg-4 py-md-3 py-sm-3 py-3">
<div class="container py-lg-5 py-md-4 py-sm-4 py-3">
<div class="col-md-12 col-sm-12 col-lg-12 col-12 col-xl-12 text-justify">
			
			<h2 class="text-pink text-center font-weight-bold">Checkout</h2>
			<div class="bottom-line text-center mb-5"></div>
			</div>
			<div class="shop_inner_inf">
			<div class="table-responsive">

			<table class="table table-bordered">
			  
				  <tr>
					 <th>Sr No.</th>
					 <th>Photo</th>
					 <th>Product Name</th>
					 <th>Unit Price</th>	
					 <th>SIZE</th>
					 <th>Quantity</th>
					 <th>Final Price</th>					
					 <th>Remove</th>
				  </tr>
			   
			   <tbody>
			   <?php 
			  
			   $all_total_price = 0;
			   $get_cart_query = "SELECT * FROM cart_items where user_id ='$sess_id' and cart_status='0'";
			   $get_cart_res = mysqli_query($con, $get_cart_query);
			   $count_cart_item = 0;
				while($cart_data = mysqli_fetch_array($get_cart_res)){
					 $cart_id = $cart_data['sno'];					 
					 $cart_product_id = $cart_data['product_id'];
					 $quantity = $cart_data['quantity']; 	
					 $size = $cart_data['size']; 	
					 
					 $pro_query = "SELECT * FROM products where id ='$cart_product_id'";
					 $pro_res = mysqli_query($con, $pro_query);
					 $pro_data_wow = mysqli_fetch_array($pro_res);
					 $pro_id = $pro_data_wow['id'];
					 $pro_name = $pro_data_wow['product_title'];
					 $total_price = $pro_data_wow['product_price2'];
					 $product_image = $pro_data_wow['product_img1'];					  
					 $total_price_all = $total_price*$quantity;					 	
					 $all_total_price += $total_price_all;
					 $count_cart_item++;
					?>
					<tr class="rem1">
					<td><?php echo $count_cart_item; ?></td>
					<td>
						<img src="../uploads/products/<?php echo $product_image; ?>" alt=" " width="70" class="img-fluid">
					</td>
					<td><?php echo $pro_name; ?></td>
					<td>Rs <?php echo number_format((float)$total_price, 2, '.', ''); ?></td>
					<td><?php echo $size; ?></td>
					<td>
						<input type='text' name='quantity' cartid="<?php echo $cart_id; ?>" value='<?php echo $quantity; ?>' class='qty' />
					</td>
					<td>Rs <?php echo number_format((float)$total_price_all, 2, '.', ''); ?></td>
					<td style="text-align:center;">
						<a href="../checkout?action=remove&code=<?php echo $cart_id; ?>" class="btnRemoveAction">
							<img src="icon-delete.png" alt="Remove Item" />
						</a>
					</td>
				  </tr>
				  <?php } ?>
			   
				 <tr class="rem1">
					<td colspan="6"><b>Total:</b></td> 
					<td style="white-space:nowrap;" rowspan="2">RS <?php echo number_format((float)$all_total_price, 2, '.', ''); ?>
					</td>
					<td class="invert" rowspan="2">
						<a href="../address" class="place_order btn btn-dark stndrd_product">Place Order</a>
					</td>
				</tr>
			   			   
			   </tbody>
			</table>
			</div>
      </div>
    </div>
</section>		
<?php
include("../footer.php");
} else {
	header("location:../login");
}
?>