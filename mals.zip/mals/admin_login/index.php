<?php 
ob_start();
session_start();
include("../db.php");

if(isset($_SESSION['sno'])){
    header("Location:../dashboard");
    exit(); 
}
?>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">
  <title>Mals - Login</title>

  <!-- Custom fonts for this template-->
  <link href="../backend/vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
  <!-- Custom styles for this template-->
  <link href="../backend/css/sb-admin.css" rel="stylesheet">
</head>

<body class="bg-dark">

  <div class="container">
    <div class="card card-login mx-auto mt-5">
      <div class="card-header"><center><b>Login to continue !</b></center> </div>
	<div id="mail-status" style="color:red;"></div>
      <div class="card-body">
        <!--form-->
          <div class="form-group">
            <div class="form-label-group">			  
				<label for="inputEmail">Username: </label>
				<input type="text" class="form-control demoInputBox" id="emailForm" placeholder="Enter Username" name="elemail">
				<span id="userEmail-info" class="info"></span>
            </div>
          </div>
          <div class="form-group">
            <div class="form-label-group">
				<label for="inputPassword">Password</label>	
				<input type="password" class="form-control demoInputBox" id="pwdform" placeholder="Enter password " name="password">
				<span id="userPass-info" class="info"></span>		  
            </div>
          </div>          
		  <input type="submit" class="btn btn-primary btn-block btnlogin" value="Login">
        <!--/form-->
        <div class="text-center">
          <a class="d-block small mt-3" href="#">Register an Account</a>
          <a class="d-block small" href="#">Forgot Password?</a>
        </div>
      </div>
    </div>
  </div>

  <!-- Bootstrap core JavaScript-->
  <script src="../backend/vendor/jquery/jquery.min.js"></script>
  <script src="../backend/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Core plugin JavaScript-->
  <script src="../backend/vendor/jquery-easing/jquery.easing.min.js"></script>
  
<script type="text/javascript">
$('.btnlogin').on('click',function () {	
	var pass = encodeURIComponent($("#pwdform").val());
	var emailid = $("#emailForm").val();
	var valid;	
	valid = validateContact();
	if(valid) {
		jQuery.ajax({
		url: "loginquery.php",
		data:'emailForm='+emailid+'&pwdform='+pass,
		type: "POST",
		success:function(data){		
		if(data == "sadmin"){
			window.location.href = "http://localhost/mals/dashboard/";
		} else { 
			$("#mail-status").html(data);
		}		
		},
		error:function (){}
		});
	}
});	


function validateContact() {
	var valid = true;	
	$(".demoInputBox").css('background-color','');
	$(".info").html('');
		
	if($("#emailForm").val() == ""){
		$("#userEmail-info").html("Username is required");
		$("#userEmail-info").css('color','red');
		$("#emailForm").css('border','1px solid red');
		valid = false;
	}else{
		$("#userEmail-info").html("");
		$("#emailForm").css('border','1px solid #ccc');		
	}
	if($("#pwdform").val() == "") {
		$("#userPass-info").html("password is required");
		$("#userPass-info").css('color','red');
		$("#pwdform").css('border','1px solid red');
		valid = false;
	}else{
		$("#userPass-info").html("");
		$("#pwdform").css('border','1px solid #ccc');		
	}
	
	return valid;
}
</script>	

</body>
</html>