<?php
session_start();
include("../db.php");
	
if(isset($_POST["emailForm"])){	
	$emailForm = $_POST['emailForm'];
	$pwdform = $_POST['pwdform'];
	$login = mysqli_query($con,"SELECT * FROM users WHERE (username = '" . $emailForm . "') and (password = '" . md5(sha1($pwdform)) . "') and type='Super_admin' and status='1'");
    if (mysqli_num_rows($login) == 1) {
        while ($row = mysqli_fetch_array($login)) {            
            $_SESSION['sno'] = $row['sno'];
			$type = $row['type'];			
			if($type == 'Super_admin'){
				echo "sadmin";
			}
		}			
    } else {
		print "<p class='Error'>Your Username and Password is wrong.</p>";
	}
} 
?>