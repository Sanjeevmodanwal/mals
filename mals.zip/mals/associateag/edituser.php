<?php
ob_start();
include("../db.php");
include("../header2.php");

if(!isset($_SESSION['sno'])){
    header("Location: ../login");
    exit(); 
}

if(isset($_SESSION['sno']) && !empty($_SESSION['sno'])){
$sessionid = $_SESSION['sno'];
$result1 = "SELECT sno,type FROM users WHERE sno = '$sessionid'";
$getusers = mysqli_query($con, $result1);
$rowusers = mysqli_fetch_assoc($getusers);
	$loggedid = mysqli_real_escape_string($con, $rowusers['sno']);
	$adminrole = mysqli_real_escape_string($con, $rowusers['type']);
}else{
	$loggedid = '';
	$adminrole = '';
}

if(!empty($_GET['snoid'])){
	$getid = base64_decode($_GET['snoid']);	
	$result = mysqli_query($con,"SELECT * FROM users WHERE sno = '$getid'");
	$row = mysqli_fetch_assoc($result);
	$insertedId = mysqli_real_escape_string($con, $row['sno']);
	$parent_id = mysqli_real_escape_string($con, $row['parent_id']);
	$associate_name = mysqli_real_escape_string($con, $row['associate_name']);
	$username = mysqli_real_escape_string($con, $row['username']);
	$mobile = mysqli_real_escape_string($con, $row['mobile']);
	$email_address = mysqli_real_escape_string($con, $row['email_address']);
	$orgpass = mysqli_real_escape_string($con, $row['orgpass']);
	$gstin_no = mysqli_real_escape_string($con, $row['gstin_no']);
	$associate_address = mysqli_real_escape_string($con, $row['associate_address']);
	$country = mysqli_real_escape_string($con, $row['country']);
	$state = mysqli_real_escape_string($con, $row['state']);
	$city = mysqli_real_escape_string($con, $row['city']);
	$pin_code = mysqli_real_escape_string($con, $row['pin_code']);
	$dob = mysqli_real_escape_string($con, $row['dob']);
	$size = mysqli_real_escape_string($con, $row['size']);
	$lenght = mysqli_real_escape_string($con, $row['lenght']);
	$nominee_name = mysqli_real_escape_string($con, $row['nominee_name']);
	$nominee_age = mysqli_real_escape_string($con, $row['nominee_age']);
	$nominee_relation = mysqli_real_escape_string($con, $row['nominee_relation']);
	$account_no = mysqli_real_escape_string($con, $row['account_no']);
	$account_holder_name = mysqli_real_escape_string($con, $row['account_holder_name']);
	$bank_name = mysqli_real_escape_string($con, $row['bank_name']);
	$branch_name = mysqli_real_escape_string($con, $row['branch_name']);
	$ifsc = mysqli_real_escape_string($con, $row['ifsc']);
	$pan_card_no = mysqli_real_escape_string($con, $row['pan_card_no']);
	$adhar_no = mysqli_real_escape_string($con, $row['adhar_no']);
	$occupation = mysqli_real_escape_string($con, $row['occupation']);
	$policy_no = mysqli_real_escape_string($con, $row['policy_no']);
	$upload_pan = mysqli_real_escape_string($con, $row['upload_pan']);
	$upload_aadhar_front = mysqli_real_escape_string($con, $row['upload_aadhar_front']);
	$upload_aadhar_back = mysqli_real_escape_string($con, $row['upload_aadhar_back']);
	$associate_image = mysqli_real_escape_string($con, $row['associate_image']);
	$associate_sign = mysqli_real_escape_string($con, $row['associate_sign']);
}else{
	$insertedId = '';
	$parent_id = '';
	$associate_name = '';
	$username = '';
	$mobile = '';
	$email_address = '';
	$orgpass = '';
	$gstin_no = '';
	$associate_address = '';
	$country = '';
	$state = '';
	$city = '';
	$pin_code = '';
	$dob = '';
	$size = '';
	$lenght = '';
	$nominee_name = '';
	$nominee_age = '';
	$nominee_relation = '';
	$account_no = '';
	$account_holder_name = '';
	$bank_name = '';
	$branch_name = '';
	$ifsc = '';
	$pan_card_no = '';
	$adhar_no = '';
	$occupation = '';
	$policy_no = '';
	$upload_pan = '';
	$upload_aadhar_front = '';
	$upload_aadhar_back = '';
	$associate_image = '';
	$associate_sign = '';
}

if($adminrole == 'Admin'){
?>
<div id="wrapper">
    <?php include("../sidebar2.php"); ?>
	
    <div id="content-wrapper">
      <div class="container-fluid">
        <!-- Breadcrumbs-->
        <ol class="breadcrumb">
          <li class="breadcrumb-item">
            <a href="../dashboardag">Dashboard</a>
          </li>
          <li class="breadcrumb-item"><a href="../associateag">Associate List</a></li>
          <li class="breadcrumb-item active">Edit Associate</li>
        </ol>

        <!-- Icon Cards-->
        <div class="row">
			<div class="col-lg-12">
			<div class="panel panel-default">
	<form action="../mysqlaction.php" method="post" autocomplete="off" enctype="multipart/form-data">
		<div class="panel-body">		
		
			<div class="form-group">
				<div class="row">
					<div class="col-sm-2">
						<label>Associate Name <span class="required">*</span></label>
					</div>
					<div class="col-sm-4">
						<input name="associate_name" type="text" class="form-control" value="<?php echo $associate_name; ?>" required />
					</div>
					<div class="col-sm-2">
						<label>Associate Id <span class="required">*</span></label>
					</div>
					<div class="col-sm-4">
					<span class="form-control"><?php echo $username; ?></span>
					</div>
				</div>
			</div>
			
			<input name="parent_id" type="hidden" value="<?php echo $loggedid;?>">

			<div class="form-group">
				<div class="row">
					<div class="col-sm-2">
						<label>Mobile No <span class="required">*</span></label>
					</div>
					<div class="col-sm-4">
						<input name="mobile" type="number" class="form-control" value="<?php echo $mobile; ?>" required />
					</div>

					<div class="col-sm-2">
						<label for="exampleInputEmail1">Email Id <span class="required">*</span></label>
					</div>
					<div class="col-sm-4">
						<input name="email_address" type="email" class="form-control" value="<?php echo $email_address; ?>" required />
					</div>
				</div>
			</div>
			<div class="form-group">
				<div class="row">					
					<div class="col-sm-2">
						<label>GSTIN No.</label>
					</div>
					<div class="col-sm-4">
						<input name="gstin_no" type="text" class="form-control" value="<?php echo $gstin_no; ?>" />
					</div>
				</div>
			</div>
				<div class="form-group">
				<div class="row">
					<div class="col-sm-2">
						<label>Associate address</label>
					</div>
					<div class="col-sm-4">
						<input name="associate_address" type="text" class="form-control" value="<?php echo $associate_address; ?>" />
					</div>
					<div class="col-sm-2">
						<label>Country</label>
					</div>
					<div class="col-sm-4">
						<select name="country" class="form-control countrydiv">
							<option value="">Select Country</option>
							<?php $cntList = mysqli_query($con, "Select country_name from country_state_city group by country_name");
							while ($rowcountry = mysqli_fetch_array($cntList)){ 
								$countryname = $rowcountry['country_name'];
							?>
							<option value="<?php echo $countryname; ?>" <?php if($countryname == "$country") { echo 'selected="selected"'; } ?>><?php echo $countryname; ?></option> 
							<?php } ?>  
						</select>
					</div>
				</div>
				</div>
				<div class="form-group">
				<div class="row">
					<div class="col-sm-2">
						<label for="exampleInputEmail1">Select State</label>
					</div>
					<div class="col-sm-4">
						<select name="state" class="form-control statediv" dataval="">							
							<?php if($state !== '') { 
								echo '<option value='.$state.'>'.$state.'</option>';
							}else{
								echo '<option value="">Select State</option>';
							}
							?>
						</select>
					</div>
					<div class="col-sm-2">
						<label for="exampleInputEmail1">Select City</label>
					</div>
					<div class="col-sm-4">
						<select name="city" class="form-control citydiv">							
							<?php if($city !== '') { 
								echo '<option value='.$city.'>'.$city.'</option>';
							}else{
								echo '<option value="">Select City</option>';
							}
							?>
						</select>
					</div>
				</div>
				</div>
				<div class="form-group">
				<div class="row">
					<div class="col-sm-2">
						<label for="exampleInputEmail1">Pin Code </label>
					</div>
					<div class="col-sm-4">
						<input name="pin_code" type="text" class="form-control" value="<?php echo $pin_code; ?>" />
						
					</div>
					<div class="col-sm-2">
						<label for="exampleInputEmail1">Date OF Birth</label>
					</div>
					<div class="col-sm-4">
						<input name="dob" type="text" class="form-control datepicker123" value="<?php echo $dob; ?>" />						
					</div>
				</div>
				</div>
				
				<div class="form-group">
				<div class="row">
					<div class="col-sm-2">
						<label>Lenght</label>
					</div>
					<div class="col-sm-4">
						<select name="lenght" class="form-control">
							<option value="">Select Option</option>
							<option value="30"<?php if($lenght == "30") { echo 'selected="selected"'; } ?>>30</option>
							<option value="31"<?php if($lenght == "31") { echo 'selected="selected"'; } ?>>31</option>
							<option value="32"<?php if($lenght == "32") { echo 'selected="selected"'; } ?>>32</option>
							<option value="33"<?php if($lenght == "33") { echo 'selected="selected"'; } ?>>33</option>
							<option value="34"<?php if($lenght == "34") { echo 'selected="selected"'; } ?>>34</option>
							<option value="35"<?php if($lenght == "35") { echo 'selected="selected"'; } ?>>35</option>
							<option value="36"<?php if($lenght == "36") { echo 'selected="selected"'; } ?>>36</option>
							<option value="37"<?php if($lenght == "37") { echo 'selected="selected"'; } ?>>37</option>
							<option value="38"<?php if($lenght == "38") { echo 'selected="selected"'; } ?>>38</option>
							<option value="39"<?php if($lenght == "39") { echo 'selected="selected"'; } ?>>39</option>
							<option value="40"<?php if($lenght == "40") { echo 'selected="selected"'; } ?>>40</option>
							<option value="41"<?php if($lenght == "41") { echo 'selected="selected"'; } ?>>41</option>
							<option value="42"<?php if($lenght == "42") { echo 'selected="selected"'; } ?>>42</option>
							<option value="43"<?php if($lenght == "43") { echo 'selected="selected"'; } ?>>43</option>
							<option value="44"<?php if($lenght == "44") { echo 'selected="selected"'; } ?>>44</option>
							<option value="45"<?php if($lenght == "45") { echo 'selected="selected"'; } ?>>45</option>
						</select>
					</div>

					<div class="col-sm-2">
						<label for="exampleInputEmail1">Size</label>
					</div>
					<div class="col-sm-4">
						<select name="size" class="form-control" required>
							<option value="">Select Option</option>
							<option value="XS"<?php if($size == "XS") { echo 'selected="selected"'; } ?>>XS</option>
							<option value="Small"<?php if($size == "Small") { echo 'selected="selected"'; } ?>>Small</option>
							<option value="Medium"<?php if($size == "Medium") { echo 'selected="selected"'; } ?>>Medium</option>
							<option value="Large"<?php if($size == "Large") { echo 'selected="selected"'; } ?>>Large</option>
							<option value="X-Large"<?php if($size == "X-Large") { echo 'selected="selected"'; } ?>>X-Large</option>
							<option value="XX-Large"<?php if($size == "XX-Large") { echo 'selected="selected"'; } ?>>XX-Large</option>
						</select>
					</div>
				</div>
				</div>

				<div class="form-group">
				<div class="row">
					<div class="col-md-2">
						<label>Nominee Name</label>
					</div>
					<div class="col-md-4">
						<input name="nominee_name" type="text" class="form-control" value="<?php echo $nominee_name; ?>" />
					</div>
					<div class="col-md-2">
						<label>Nominee Age</label>
					</div>
					<div class="col-md-4">
						<input name="nominee_age" type="text" class="form-control" value="<?php echo $nominee_age; ?>" />
						
					</div>
				</div>
				</div>
				<div class="form-group">
				<div class="row">
					<div class="col-md-2">
						<label>Nominee Relation</label>
					</div>
					<div class="col-md-4">
						<input name="nominee_relation" type="text" class="form-control"  value="<?php echo $nominee_relation; ?>" />
					</div>
				</div>
				</div>

				<div class="form-group">
				<div class="row">
					<div class="col-sm-2">
						<label for="exampleInputEmail1">Account No </label>
					</div>
					<div class="col-sm-4">
						<input name="account_no" type="text" class="form-control"  value="<?php echo $account_no; ?>" />
					</div>

					<div class="col-sm-2">
						<label for="exampleInputEmail1">Account Holder Name</label>
					</div>
					<div class="col-sm-4">
						<input name="account_holder_name" type="text" class="form-control"  value="<?php echo $account_holder_name; ?>" />
					</div>
				</div>
				</div>
				<div class="form-group">
				<div class="row">
					<div class="col-sm-2">
						<label for="exampleInputEmail1">Bank Name </label>
					</div>
					<div class="col-sm-4">
						<select name="bank_name" class="form-control">
							<option value="">Select Bank</option>
							<option value="ALLAHABAD BANK" <?php if($country == "ALLAHABAD BANK") { echo 'selected="selected"'; } ?>>ALLAHABAD BANK</option>
							<option value="ALLAHABAD UP GRAMIN BANK"<?php if($country == "ALLAHABAD UP GRAMIN BANK") { echo 'selected="selected"'; } ?>>ALLAHABAD UP GRAMIN BANK</option>
							<option value="ANDHRA BANK" <?php if($country == "ANDHRA BANK") { echo 'selected="selected"'; } ?>>ANDHRA BANK</option>
							<option value="AXIS BANK" <?php if($country == "AXIS BANK") { echo 'selected="selected"'; } ?>>AXIS BANK</option>
							<!--option value="29">BANDHAN BANK</option>
							<option value="43">BANGIYA GURAMIN VIKAS BANK</option>
							<option value="7">BANK OF BARODA</option>
							<option value="26">BANK OF INDIA</option>
							<option value="21">BANK OF MAHARASHTRA</option>
							<option value="34">BARODA  UTTAR PRADESH GARMIN  BANK</option>
							<option value="24">BHART CO BANK</option>
							<option value="41">BIHAR GRAMIN  BANK</option>
							<option value="40">BIHAR GRAMIN BANK</option>
							<option value="9">CANARA BANK</option>
							<option value="35">CAPITAL SMALL FINANCE BANK</option>
							<option value="32">CENTRAL BANK OF INDIA</option>
							<option value="23">CORPORATION BANK</option>
							<option value="17">DENA BANK</option>
							<option value="38">DOMBIVLI NAGRI SAHAKARI BANK LTD</option>
							<option value="39">FEDERAL BANK</option>
							<option value="1">HDFC</option>
							<option value="2">ICICI BANK</option>
							<option value="3">IDBI BANK LIMITED</option>
							<option value="30">IDFC BANK</option>
							<option value="27">INDIAN BANK</option>
							<option value="13">INDIAN OVERSEAS BANK</option>
							<option value="22">INDUSIND BANK</option>
							<option value="19">KARNATKA BANK LTD.</option>
							<option value="18">KOTAK MAHINDRA BANK</option>
							<option value="44">MALDA  CENTRAL CO - OPERATIVE BANK</option>
							<option selected="selected" value="4">ORIENTAL BANK OF COMMERCE</option>
							<option value="6">PNB</option>
							<option value="36">PRATHAMA BANK</option>
							<option value="12">PUNJAB AND SIND BANK</option>
							<option value="37">RBL BANK</option>
							<option value="25">SARSWAT BANK</option>
							<option value="5">SBI</option>
							<option value="28">SYNDICATE BANK</option>
							<option value="20">UCO BANK</option>
							<option value="14">UNION BANK</option>
							<option value="15">UNION BANK BANK OF INDIA</option>
							<option value="31">UNITED BANK OF INDIA</option>
							<option value="42">VANACHAL GRAMIN BANK</option>
							<option value="33">VIJAY BANK</option>
							<option value="16">YES BANK</option-->
						</select>
					</div>

					<div class="col-sm-2">
						<label for="exampleInputEmail1">Branch Name</label>
					</div>
					<div class="col-sm-4">
						<input name="branch_name" type="text" class="form-control" value="<?php echo $branch_name; ?>" />
					</div>
				</div>
				</div>
				<div class="form-group">
				<div class="row">
					<div class="col-sm-2">
						<label for="exampleInputEmail1">IFSC </label>
					</div>
					<div class="col-sm-4">
						<input name="ifsc" type="text" class="form-control" value="<?php echo $ifsc; ?>" />
					</div>
					<div class="col-sm-2">
						<label for="exampleInputEmail1">Pan Card No  </label>
					</div>
					<div class="col-sm-4">
						<input name="pan_card_no" type="text" class="form-control" value="<?php echo $pan_card_no; ?>" />
					</div>
				</div>
				</div>

				<div class="form-group">
				<div class="row">
					<div class="col-sm-2">
						<label>Aadhar No </label>
					</div>
					<div class="col-sm-4">
						<input name="adhar_no" type="text" class="form-control" value="<?php echo $adhar_no; ?>" />
					</div>
					<div class="col-sm-2">
						<label>Occupation </label>
					</div>
					<div class="col-sm-4">
						<input name="occupation" type="text" class="form-control" value="<?php echo $occupation; ?>" />
					</div>
				</div>
				</div>

				<div class="form-group">
				<div class="row">
					<div class="col-sm-2">
						<label>Policy No </label>
					</div>
					<div class="col-sm-4">
						<input name="policy_no" type="text" class="form-control" value="<?php echo $policy_no; ?>" />
					</div>
				</div>
				</div>

				<div class="form-group">
				<div class="row">
					<div class="col-sm-2">
						<label for="exampleInputEmail1">Upload Pan </label>
					</div>
					<div class="col-sm-4">
						<input type="file" name="upload_pan" />
					</div>
					<div class="col-sm-2">
						<label for="exampleInputEmail1">Upload Aadhar Front </label>
					</div>
					<div class="col-sm-4">
						<input type="file" name="upload_aadhar_front" />
					</div>
				</div>
				</div>
				
				<div class="form-group">
				<div class="row">
					<div class="col-sm-2">
					</div>
					<div class="col-sm-4">
					<?php if(!empty($upload_pan)){ ?>
						<a href="../uploads/<?php echo $upload_pan;?>" download>Download Pan Card</a>
					<?php } ?>
					</div>
					<div class="col-sm-2">
					</div>
					<div class="col-sm-4">
						<?php if(!empty($upload_aadhar_front)){ ?>
						<a href="../uploads/<?php echo $upload_aadhar_front;?>" download>Download Aadhar Front</a>
					<?php } ?>
					</div>
				</div>
				</div>
				
				

				<div class="form-group">
				<div class="row">
					<div class="col-sm-2">
						<label>Upload Aadhar Back </label>
					</div>
					<div class="col-sm-4">
						<input type="file" name="upload_aadhar_back" />
					</div>
				</div>
				</div>
				
				<div class="form-group">
				<div class="row">
					<div class="col-sm-2">
					</div>
					<div class="col-sm-4">
					<?php if(!empty($upload_aadhar_back)){ ?>
						<a href="../uploads/<?php echo $upload_aadhar_back;?>" download>Download Aadhar Back</a>
					<?php } ?>
					</div>
				</div>
				</div>
				

				<div class="form-group">
				<div class="row">
					<div class="col-sm-2">
						<label for="exampleInputEmail1">Associate Image </label>
					</div>
					<div class="col-sm-4">
						<input type="file" name="associate_image" />
					</div>
					<div class="col-sm-2">
						<label for="exampleInputEmail1">Associate Sign </label>
					</div>
					<div class="col-sm-4">
						<input type="file" name="associate_sign" />
					</div>
				</div>
				</div>
				
				<div class="form-group">
				<div class="row">
					<div class="col-sm-2">
					</div>
					<div class="col-sm-4">
					<?php if(!empty($associate_image)){ ?>
						<a href="../uploads/<?php echo $associate_image;?>" download>Download Associate Image</a>
					<?php } ?>
					</div>
					<div class="col-sm-2">
					</div>
					<div class="col-sm-4">
						<?php if(!empty($associate_sign)){ ?>
						<a href="../uploads/<?php echo $associate_sign;?>" download>Download Associate Sign</a>
					<?php } ?>
					</div>
				</div>
				</div>

			
			<div class="row">
				<div class="col-md-3">
					<input type="hidden" name="snoEdit" value="<?php echo $insertedId; ?>">					
					<input type="submit" name="editsbmtbtn_agent" value="Update" class="btn btn-warning">					
				</div>
			</div>

        </div>
		</form>
        </div>
        </div>
        </div>

        <!-- DataTables Example -->
        <div class="card mb-3">
          
        </div>
   </div>
   
   
   
<script>
$(document).on('change', '.countrydiv', function(){
	var vl = $(this).val();
	$('.statediv').attr('dataval', vl);
	$.post("../response.php?tag=countrytostate",{"country":vl},function(d){
		$(".statediv").html(" ");
		$(".statediv").html("<option value=''>Select Option</option>");
		for (i in d) {
			$('<option value="' + d[i].state_name + '">'+ d[i].state_name +'</option>').appendTo(".statediv");
		}	
	});	
});
</script>

<script>
$(document).on('change', '.statediv', function(){
	var vl = $(this).val();
	var vl2 = $(this).attr('dataval');
	$.post("../response.php?tag=statetocity",{"country":vl2,"state":vl},function(d){
	$(".citydiv").html(" ");
	$(".citydiv").html("<option value=''>Select Option</option>");
	for (i in d) {
		$('<option value="' + d[i].city_name + '">'+ d[i].city_name +'</option>').appendTo(".citydiv");
	}
	});
});
</script>

<?php include("../footer2.php"); 
}else{
	header("Location: ../logout.php");
}
?>
