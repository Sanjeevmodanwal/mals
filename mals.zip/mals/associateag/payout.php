<?php
ob_start();
include("../db.php");
include("../header2.php");

if(!isset($_SESSION['sno'])){
    header("Location: ../login");
    exit(); 
}

if(isset($_SESSION['sno']) && !empty($_SESSION['sno'])){
$sessionid = $_SESSION['sno'];
$result1 = "SELECT sno,type,username,account_no,account_holder_name FROM users WHERE sno = '$sessionid'";
$getusers = mysqli_query($con, $result1);
$rowusers = mysqli_fetch_assoc($getusers);
	$loggedid = mysqli_real_escape_string($con, $rowusers['sno']);
	$adminrole = mysqli_real_escape_string($con, $rowusers['type']);
	$username = mysqli_real_escape_string($con, $rowusers['username']);
	$account_no = mysqli_real_escape_string($con, $rowusers['account_no']);
	$account_holder_name = mysqli_real_escape_string($con, $rowusers['account_holder_name']);
}else{
	$loggedid = '';
	$adminrole = '';
	$username = '';
	$account_no = '';
	$account_holder_name = '';
}

if($adminrole == 'Admin'){
?>
<div id="wrapper">
    <?php include("../sidebar2.php"); ?>
	
    <div id="content-wrapper">
      <div class="container-fluid">
	  
		<div class="card mb-3">
          <div class="card-header">
            <i class="fas fa-table"></i>
            Payout(Passbook)
		  </div>
			
          <div class="card-body">
			<div class="searchResult">
			<div class="col-sm-12">
				<div class="col-sm-6">
					<p><b>User Id : </b><?php echo $username; ?></p>
					<p><b>A/C No. : </b><?php echo $account_no; ?></p>
					<p><b>Name : </b><?php echo $account_holder_name; ?></p>
				</div>
	<?php 
		$result_payout_Direct = "SELECT amount FROM payout_passbook_list WHERE income_name='Direct Income' AND user_id='$loggedid'";
		$get_payout_Direct = mysqli_query($con, $result_payout_Direct);
		$Direct_amount = 0;
		while ($row_payout_Direct = mysqli_fetch_assoc($get_payout_Direct)) {
			$Direct_amount += mysqli_real_escape_string($con, $row_payout_Direct['amount']);
		}

		$result_payout_Level = "SELECT amount FROM payout_passbook_list WHERE income_name='Level Income' AND user_id='$loggedid'";
		$get_payout_Level = mysqli_query($con, $result_payout_Level);
		$Level_amount = 0;
		while ($row_payout_Level = mysqli_fetch_assoc($get_payout_Level)) {
			$Level_amount += mysqli_real_escape_string($con, $row_payout_Level['amount']);
		}

		$result_payout_Other = "SELECT amount FROM payout_passbook_list WHERE income_name='Other Income' AND user_id='$loggedid'";
		$get_payout_Other = mysqli_query($con, $result_payout_Other);
		$Other_amount = 0;
		while ($row_payout_Other = mysqli_fetch_assoc($get_payout_Other)) {
			$Other_amount += mysqli_real_escape_string($con, $row_payout_Other['amount']);
		}
	?>
				<div class="col-sm-6">
					<p><b>Total Direct Income : </b><i class="fas fa-rupee-sign"></i><?php echo $Direct_amount; ?></p>
					<p><b>Total Level Income : </b><i class="fas fa-rupee-sign"></i><?php echo $Level_amount; ?></p>
					<p><b>Total Other Income : </b><i class="fas fa-rupee-sign"></i><?php echo $Other_amount; ?></p>
				</div>
			</div>
			</div>
            
			<div class="table-responsive">
              <table class="table table-bordered" id="" width="100%" cellspacing="0">
                <thead>
                  <tr>
					<th>Level</th>
                    <th>Income</th>
                    <th>Amount</th>
                    <th>Created</th>
				  </tr>
				</thead>
				
				<tbody class="paytable">
				<?php 
				$result_payout = "SELECT * FROM payout_passbook_list WHERE user_id='$loggedid'";
				$get_payout = mysqli_query($con, $result_payout);
				$amount_qty = 0;
				while ($row_payout = mysqli_fetch_assoc($get_payout)) {
					$level = mysqli_real_escape_string($con, $row_payout['level']);
					$income_name = mysqli_real_escape_string($con, $row_payout['income_name']);
					$amount = mysqli_real_escape_string($con, $row_payout['amount']);
					$amount_qty += mysqli_real_escape_string($con, $row_payout['amount']);
					$datetime_1 = mysqli_real_escape_string($con, $row_payout['datetime']);
					$datetime = date('d F Y, h:i A', strtotime($datetime_1));
				?>
				<tr>
					<td><?php echo $level; ?></td>
					<td><?php echo $income_name; ?></td>
					<td><?php echo $amount; ?></td>
					<td><?php echo $datetime; ?></td>
				</tr>
				<?php } ?>
				<tr>
					<td colspan='2' class="text-right pr-5"><b>Total</b></td>
					<td><i class="fas fa-rupee-sign"></i><?php echo $amount_qty; ?></td>
					<td></td>
				</tr>
				</tbody>
				</table>
			</div>
			
          </div>
        </div>
<?php include("../footer2.php"); 
}else{
	header("Location: ../logout.php");
}
?>