<?php
ob_start();
include("../db.php");
include("../header2.php");

if(!isset($_SESSION['sno'])){
    header("Location: ../login");
    exit(); 
}

$sessionid = $_SESSION['sno'];

$result = mysqli_query($con,"SELECT * FROM users WHERE parent_id = '$sessionid'");
while($row=$result->fetch_assoc()){
	  $data[]=$row;
}

foreach($data as $d) {
	   $user[]=$d['username'];
}

if(!empty($user[0])){
	$a=$user[0];
}else{
	$a = 'N/A';
}
if(!empty($user[1])){
	$a1=$user[1];
}else{
	$a1 = 'N/A';
}
if(!empty($user[2])){
	$a2=$user[2];
}else{
	$a2 = 'N/A';
}
if(!empty($user[3])){
	$a3=$user[3];
}else{
	$a3 = 'N/A';
}
if(!empty($user[4])){
	$a4=$user[4];
}else{
	$a4 = 'N/A';
}
if(!empty($user[5])){
	$a5=$user[5];
}else{
	$a5 = 'N/A';
}
if(!empty($user[6])){
	$a6=$user[6];
}else{
	$a6 = 'N/A';
}
if(!empty($user[7])){
	$a7=$user[7];
}else{
	$a7 = 'N/A';
}
if(!empty($user[8])){ $a8=$user[8]; }else{ $a8 = 'N/A'; }
if(!empty($user[9])){ $a9=$user[9]; }else{ $a9 = 'N/A'; }
if(!empty($user[10])){ $a10=$user[10]; }else{ $a10 = 'N/A'; }
if(!empty($user[11])){ $a11=$user[11]; }else{ $a11 = 'N/A'; }
if(!empty($user[12])){ $a12=$user[12]; }else{ $a12 = 'N/A'; }
if(!empty($user[13])){ $a13=$user[13]; }else{ $a13 = 'N/A'; }
if(!empty($user[14])){ $a14=$user[14]; }else{ $a14 = 'N/A'; }
if(!empty($user[15])){ $a15=$user[15]; }else{ $a15 = 'N/A'; }
if(!empty($user[16])){ $a16=$user[16]; }else{ $a16 = 'N/A'; }
if(!empty($user[17])){ $a17=$user[17]; }else{ $a17 = 'N/A'; }
if(!empty($user[18])){ $a18=$user[18]; }else{ $a18 = 'N/A'; }
if(!empty($user[19])){ $a19=$user[19]; }else{ $a19 = 'N/A'; }
if(!empty($user[20])){ $a20=$user[20]; }else{ $a20 = 'N/A'; }
if(!empty($user[21])){ $a21=$user[21]; }else{ $a21 = 'N/A'; }
if(!empty($user[22])){ $a22=$user[22]; }else{ $a22 = 'N/A'; }
if(!empty($user[23])){ $a23=$user[23]; }else{ $a23 = 'N/A'; }
if(!empty($user[24])){ $a24=$user[24]; }else{ $a24 = 'N/A'; }
if(!empty($user[25])){ $a25=$user[25]; }else{ $a25 = 'N/A'; }
if(!empty($user[26])){ $a26=$user[26]; }else{ $a26 = 'N/A'; }
if(!empty($user[27])){ $a27=$user[27]; }else{ $a27 = 'N/A'; }
if(!empty($user[28])){ $a28=$user[28]; }else{ $a28 = 'N/A'; }
if(!empty($user[29])){ $a29=$user[29]; }else{ $a29 = 'N/A'; }

if(isset($_SESSION['sno']) && !empty($_SESSION['sno'])){
$sessionid = $_SESSION['sno'];
$result1 = "SELECT sno,type,username FROM users WHERE sno = '$sessionid'";
$getusers = mysqli_query($con, $result1);
$rowusers = mysqli_fetch_assoc($getusers);
	$loggedid = mysqli_real_escape_string($con, $rowusers['sno']);
	$username = mysqli_real_escape_string($con, $rowusers['username']);
	$adminrole = mysqli_real_escape_string($con, $rowusers['type']);
}else{
	$loggedid = '';
	$username = '';
	$adminrole = '';
}

if($adminrole == 'Admin'){
?>
<div id="wrapper">
    <?php include("../sidebar2.php"); ?>
	
    <div id="content-wrapper">
      <div class="container-fluid">
	  <div class="card mb-3">
          <div class="card-header"><i class="fas fa-table"></i> Assosiate Structure Chart</div>
		<div class="row">
				<div style="clear: both;"></div>
				<div class="col-12 pt-2">
					<div class="col-12">
						<center>
							<img src="../images/admin.png" class="img-fluid" width="50"><br>
							<span class="line" style="color: green"><?php echo $username; ?></span>
						</center>
						<hr style="width: 54%; color: black; border-top: 2px solid black;">
					</div>
					<div class="row">
						<div class="col-12">
							<div class="row">
								<div class="col-6 text-center"> <img src="../images/subadmin.png" class="img-fluid" width="50"><br>
									<span class="line1" style="color: green"><?php echo $a; ?></span>
									<hr style="width: 58%; color: black; border-top: 2px solid black;">
								</div>
								<div class="col-6" style="text-align: center;"> <img src="../images/subadmin.png" class="img-fluid" width="50"><br>
									<span class="line1" style="color: red"><?php echo $a1; ?></span>
									<hr style="width:58%; color: black; border-top: 2px solid black;">
								</div>
							</div>
						</div>
					</div>
					
					<!-- level 1 -->
					<div class="row">
						<div class="col-6">
							<div class="row">
								<div class="col-6" style="text-align: center;"> <img src="../images/subadmin.png" class="img-fluid" width="50"> <br>
									<span class="line1" style="color: green"><?php echo $a2; ?></span>
									<hr style="width: 66%; color: black; border-top: 2px solid black;">
								</div>
								<div class="col-6" style="text-align: center;"> <img src="../images/subadmin.png" class="img-fluid" width="50"><br>
									<span class="line1" style="color: green"><?php echo $a3; ?></span>
									<hr style="width: 66%; color: black; border-top: 2px solid black;">
								</div>
							</div>
						</div>
						<div class="col-6">
							<div class="row">
								<div class="col-6" style="text-align: center;"> <img src="../images/subadmin.png" class="img-fluid" width="50"> <br>
									<span class="line1" style="color: red"><?php echo $a4; ?></span>
									<hr style="width: 66%; color: black; border-top: 2px solid black;">
								</div>
								<div class="col-6" style="text-align: center;"> <img src="../images/subadmin.png" class="img-fluid" width="50"><br>
									<span class="line1" style="color: red"><?php echo $a5; ?></span>
									<hr style="width: 66%; color: black; border-top: 2px solid black;">
								</div>
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-3">
							<div class="row mt-0">
								<div class="col-5 p-1" style="text-align: center;"> <img src="../images/subadmin.png" class="img-fluid" width="50"> <br>
									<span class="line1" style="color: red"><?php echo $a6; ?></span>
									<hr style="width: 66%; color: black; border-top: 2px solid black;"> </div>
								<div class="col-5 offset-2 p-1" style="text-align: center;"> <img src="../images/subadmin.png" class="img-fluid" width="50"><br>
									<span class="line1" style="color: red"><?php echo $a7; ?></span>
									<hr style="width: 66%; color: black; border-top: 2px solid black;"> </div>
							</div>
						</div>
						<div class="col-3"><div class="row">
							<div class="col-5 p-1" style="text-align: center;"> <img src="../images/subadmin.png" class="img-fluid" width="50"> <br>
								<span class="line1" style="color: red"><?php echo $a8; ?></span>
								<hr style="width: 66%; color: black; border-top: 2px solid black;"> 
							</div>
							<div class="col-5 offset-2  p-1" style="text-align: center;"><img src="../images/subadmin.png" class="img-fluid" width="50"><br>
							<span class="line1" style="color: red"><?php echo $a9; ?></span>
								<hr style="width: 66%; color: black; border-top: 2px solid black;"> 
							</div>
						</div>
						</div>
						<div class="col-3"><div class="row">
							<div class="col-5 p-1" style="text-align: center;"> <img src="../images/subadmin.png" class="img-fluid" width="50"> <br>
								<span class="line1" style="color: red"><?php echo $a10; ?></span>
								<hr style="width: 66%; color: black; border-top: 2px solid black;"> 
							</div>
							<div class="col-5 offset-2  p-1" style="text-align: center;"> <img src="../images/subadmin.png" class="img-fluid" width="50"><br>
									<span class="line1" style="color: red"><?php echo $a11; ?></span>
									<hr style="width: 66%; color: black; border-top: 2px solid black;"> 
								</div>
						</div></div>
					<div class="col-3"><div class="row">
							<div class="col-5 p-1" style="text-align: center;"> <img src="../images/subadmin.png" class="img-fluid" width="50"> <br>
							<span class="line1" style="color: red"><?php echo $a12; ?></span>
									<hr style="width: 66%; color: black; border-top: 2px solid black;"> 
							</div>
							<div class="col-5 offset-2  p-1" style="text-align: center;"> <img src="../images/subadmin.png" class="img-fluid" width="50"><br>
							<span class="line1" style="color: red"><?php echo $a13; ?></span>
									<hr style="width: 66%; color: black; border-top: 2px solid black;">
							</div>
						</div></div>
					
				</div>
				<div class="row">
						<div class="col-2">
							<div class="row mt-0">
								<div class="col-4 p-1" style="text-align: center;"> <img src="../images/subadmin.png" class="img-fluid" width="40"> <br>
									<span style="color: green"><?php echo $a14; ?></span> </div>
								<div class="col-4  p-1" style="text-align: center;"> <img src="../images/subadmin.png" class="img-fluid" width="40"><br>
									<span style="color: green"><?php echo $a15; ?></span> </div>
							</div>
						</div>
						<div class="col-1">
							<div class="row mt-0">
								<div class="col-5 p-1" style="text-align: left;"> <img src="../images/subadmin.png" class="img-fluid" width="40"> <br>
									<span style="color: green"><?php echo $a16; ?></span> </div>
								<div class="col-5  p-1" style="text-align: center;"> <img src="../images/subadmin.png" class="img-fluid" width="40"><br>
									<span style="color: green"><?php echo $a17; ?></span> </div>
							</div>
						</div>
						<div class="col-2">
							<div class="row mt-0">
								<div class="col-4 p-1" style="text-align: center;"> <img src="../images/subadmin.png" class="img-fluid" width="40"> <br>
									<span style="color: green"><?php echo $a18; ?></span> </div>
								<div class="col-4  p-1" style="text-align: center;"> <img src="../images/subadmin.png" class="img-fluid" width="40"><br>
									<span style="color: green"><?php echo $a19; ?> </span> </div>
							</div>
						</div>
					<div class="col-1">
							<div class="row mt-0">
								<div class="col-5 p-1" style="text-align: center;"> <img src="../images/subadmin.png" class="img-fluid" width="40"> <br>
									<span style="color: green"><?php echo $a20; ?></span> </div>
								<div class="col-5  p-1" style="text-align: center;"> <img src="../images/subadmin.png" class="img-fluid" width="40"><br>
									<span style="color: green"><?php echo $a21; ?></span> </div>
							</div>
						</div>
						<div class="col-2">
							<div class="row mt-0">
								<div class="col-4 p-1" style="text-align: center;"> <img src="../images/subadmin.png" class="img-fluid" width="40"> <br>
									<span style="color: green"><?php echo $a22; ?></span> </div>
								<div class="col-4  p-1" style="text-align: center;"> <img src="../images/subadmin.png" class="img-fluid" width="40"><br>
									<span style="color: green"><?php echo $a23; ?></span> </div>
							</div>
						</div><div class="col-1">
							<div class="row mt-0">
								<div class="col-5 p-1" style="text-align: center;"> <img src="../images/subadmin.png" class="img-fluid" width="40"> <br>
									<span style="color: green"><?php echo $a24; ?></span> </div>
								<div class="col-5  p-1" style="text-align: center;"> <img src="../images/subadmin.png" class="img-fluid" width="40"><br>
									<span style="color: green"><?php echo $a25; ?></span> </div>
							</div>
						</div>
						<div class="col-2">
							<div class="row mt-0">
								<div class="col-4 p-1" style="text-align: center;"> <img src="../images/subadmin.png" class="img-fluid" width="40"> <br>
									<span style="color: green"><?php echo $a26; ?></span> </div>
								<div class="col-4  p-1" style="text-align: center;"> <img src="../images/subadmin.png" class="img-fluid" width="40"><br>
									<span style="color: green"><?php echo $a27; ?></span> </div>
							</div>
						</div>
						<div class="col-1">
							<div class="row mt-0">
								<div class="col-5 p-1" style="text-align: center;"> <img src="../images/subadmin.png" class="img-fluid" width="40"> <br>
									<span style="color: green"><?php echo $a28; ?> </span> </div>
								<div class="col-5  p-1" style="text-align: center;"> <img src="../images/subadmin.png" class="img-fluid" width="40"><br>
									<span style="color: green"><?php echo $a29; ?></span> </div>
							</div>
						</div>
					
				</div>
			</div>
		</div>	
			
</div>



<style>
hr {position:relative;}
.img-fluid {position:relative;border-radius:50%; border:1px solid #333;}
hr:before, hr:after, .line1:before, .line:before {height:18px; width:2px; background:#000; position:absolute; content:"";}
hr:before {  left:0px;}
hr:after {  right:0px;}
.line1:before {top:66%;left:50%;}
.line:before {top:82%;left:50%;}
</style>


<?php include("../footer2.php"); 
}else{
	header("Location: ../logout.php");
}
?>

<script>
$('.clk').on("click",function(){
	var id=$(this).data().id;
	$.post("api.php?tag=find",{"id":id},function(d){
		console.log(d);
	});
});
</script>
