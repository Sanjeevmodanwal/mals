<?php
ob_start();
include("../db.php");
include("../header2.php");

//SMSM//

if(!isset($_SESSION['sno'])){
    header("Location: ../login");
    exit(); 
}

if(isset($_SESSION['sno']) && !empty($_SESSION['sno'])){
$sessionid = $_SESSION['sno'];
$result1 = "SELECT sno,type,associate_name,username FROM users WHERE sno = '$sessionid'";
$getusers = mysqli_query($con, $result1);
$rowusers = mysqli_fetch_assoc($getusers);
	$loggedid = mysqli_real_escape_string($con, $rowusers['sno']);
	$associate_name = mysqli_real_escape_string($con, $rowusers['associate_name']);
	$adminrole = mysqli_real_escape_string($con, $rowusers['type']);
	$username = mysqli_real_escape_string($con, $rowusers['username']);
}else{
	$loggedid = '';
	$associate_name = '';
	$adminrole = '';
	$username = '';
}
$msgsave = base64_encode(rand());

if($adminrole == 'Admin'){
?>
<div id="wrapper">
    <?php include("../sidebar2.php"); ?>
	
    <div id="content-wrapper">
      <div class="container-fluid">
	  <div class="card mb-3">
          <div class="card-header"><i class="fas fa-table"></i> Assosiate Structure Chart</div>
		<div class="row">
				<div style="clear: both;"></div>
				<div class="col-12 pt-2">
					<div class="col-12">
					<?php
					if(!empty($_GET['nameid'])){
						$nameid = $_GET['nameid'];
					}else{
						$nameid = $sessionid;
					}
					$firstrslt = "SELECT sno,associate_name,username FROM users WHERE sno = '$nameid'";
						$rsltfst = mysqli_query($con, $firstrslt);
						$rowusers1 = mysqli_fetch_assoc($rsltfst);
						$snoFirst = mysqli_real_escape_string($con, $rowusers1['sno']);
						$associate_nameFirst = mysqli_real_escape_string($con, $rowusers1['associate_name']);
						$usernameFirst = mysqli_real_escape_string($con, $rowusers1['username']);
					?>
						<center>
						<a href="tree.php?nameid=<?php echo $snoFirst.'&'.$msgsave;?>">
							<img src="../images/admin.png" class="img-fluid" width="50"><br>
							<span class="line" style="color: green"><?php echo $usernameFirst.'<br>('.$associate_nameFirst.')'; ?></span>
						</a>
						</center>
						<hr style="width: 54%; color: black; border-top: 2px solid black;">
					</div>
					<div class="row">
						<div class="col-12">
							<div class="row">
							<?php 
							$query1 = "SELECT sno,associate_name,username,position FROM users WHERE type='Admin' AND parent_id = '$snoFirst' limit 2";
							$getrslt1 = mysqli_query($con, $query1);
							if(mysqli_num_rows($getrslt1)){
								while($rowTree = mysqli_fetch_array($getrslt1)){
									$data[]=$rowTree;
								}
							/////
								if(isset($data[0]['position']) == 'left'){
									$uname1 = $data[0]['username'];
									$sno1 = $data[0]['sno']; 
									$url1 = "tree.php?nameid=$sno1&$msgsave";
									$associate_name1 = '('.$data[0]['associate_name'].')';
								}else{
										$uname1 = 'N/A';
										$sno1 = '';
										$url1 = 'javascript:void(0)';
										$associate_name1 = '';
								}
							/////
								if(isset($data[1]['position']) == 'right'){
									$uname2 = $data[1]['username'];
									$sno2 = $data[1]['sno'];
									$url2 = "tree.php?nameid=$sno2&$msgsave";
									$associate_name2 = '('.$data[1]['associate_name'].')';
								}else{
										$uname2 = 'N/A';
										$sno2 = '';
										$url2 = 'javascript:void(0)';
										$associate_name2 = '';
								}
							/////
							}else{
								$uname1 = 'N/A';
								$sno1 = '';
								$uname2 = 'N/A';
								$url1 = 'javascript:void(0)';
								$sno2 = '';
								$url2 = 'javascript:void(0)';
								$associate_name1 = '';
								$associate_name2 = '';
							}
							?>
								<div class="col-6" style="text-align: center;">
								<a href="<?php echo $url1;?>">
									<img src="../images/subadmin.png" class="img-fluid" width="50"><br>
									<span class="line1" style="color: green"><?php echo $uname1.''.$associate_name1; ?></span>
								</a>
									<hr style="width: 58%; color: black; border-top: 2px solid black;">
								</div>
								<div class="col-6" style="text-align: center;">
								<a href="<?php echo $url2;?>">
									<img src="../images/subadmin.png" class="img-fluid" width="50"><br>
									<span class="line1" style="color: green"><?php echo $uname2.''.$associate_name2; ?></span>
								</a>
									<hr style="width:58%; color: black; border-top: 2px solid black;">
								</div>
							</div>
						</div>
					</div>
					
					<!-- level 1 -->
					<div class="row">
						<div class="col-6">
							<div class="row">
							<?php 
							$query_2 = "SELECT sno,associate_name,username,position FROM users WHERE type='Admin' AND parent_id = '$sno1' limit 2";
							$getrslt_2 = mysqli_query($con, $query_2);
							if(mysqli_num_rows($getrslt_2)){							
								while($rowTree_2 = mysqli_fetch_array($getrslt_2)){
									$data_2[]=$rowTree_2;
								}								
							/////	
								if(isset($data_2[0]['position']) == 'left'){
									$uname1_2 = $data_2[0]['username'];
									$sno1_2 = $data_2[0]['sno'];
									$url1_2 = "tree.php?nameid=$sno1_2&$msgsave";
									$associate_name1_2 = '('.$data_2[0]['associate_name'].')';
								}else{
									$uname1_2 = 'N/A';
									$sno1_2 = '';
									$url1_2 = 'javascript:void(0)';
									$associate_name1_2 = '';
								}
							/////
								if(isset($data_2[1]['position']) == 'right'){
									$uname2_2 = $data_2[1]['username'];
									$sno2_2 = $data_2[1]['sno'];
									$url2_2 = "tree.php?nameid=$sno2_2&$msgsave";
									$associate_name2_2 = '('.$data_2[1]['associate_name'].')';
								}else{									
									$uname2_2 = 'N/A';
									$sno2_2 = '';
									$url2_2 = 'javascript:void(0)';
									$associate_name2_2 = '';
								}
							/////
								}else{
									$uname1_2 = 'N/A';
									$sno1_2 = '';
									$associate_name1_2 = '';
									$url1_2 = 'javascript:void(0)';
									$uname2_2 = 'N/A';
									$sno2_2 = '';
									$associate_name2_2 = '';
									$url2_2 = 'javascript:void(0)';
								}
							?>
								<div class="col-6" style="text-align: center;">
								<a href="<?php echo $url1_2;?>">
								<img src="../images/subadmin.png" class="img-fluid" width="50"> <br>
								<span class="" style="color: green"><?php echo $uname1_2.''.$associate_name1_2; ?></span>
								</a>
									<!--hr style="width: 66%; color: black; border-top: 2px solid black;"-->
								</div>
								<div class="col-6" style="text-align: center;">
								<a href="<?php echo $url2_2;?>">
								<img src="../images/subadmin.png" class="img-fluid" width="50"><br>
								<span class="" style="color: green"><?php echo $uname2_2.''.$associate_name2_2; ?></span>
								</a>
									<!--hr style="width: 66%; color: black; border-top: 2px solid black;"-->
								</div>
							</div>
						</div>
						<div class="col-6">
							<div class="row">
							<?php 
							$query_3 = "SELECT sno,associate_name,username,position FROM users WHERE type='Admin' AND parent_id = '$sno2' limit 2";
							$getrslt_3 = mysqli_query($con, $query_3);							
							if(mysqli_num_rows($getrslt_3)){
								while($rowTree_3 = mysqli_fetch_array($getrslt_3)){
									$data_3[]=$rowTree_3;
								}								
							/////	
								if(isset($data_3[0]['position']) == 'left'){
									$uname1_3 = $data_3[0]['username'];
									$sno1_3 = $data_3[0]['sno'];
									$url1_3 = "tree.php?nameid=$sno1_3&$msgsave";
									$associate_name1_3 = '('.$data_3[0]['associate_name'].')';
								}else{
										$uname1_3 = 'N/A';
										$sno1_3 = '#';
										$url1_3 = 'javascript:void(0)';
										$associate_name1_3 = '';
								}
							/////
								if(isset($data_3[1]['position']) == 'right'){
									$uname2_3 = $data_3[1]['username'];
									$sno2_3 = $data_3[1]['sno'];
									$url2_3 = "tree.php?nameid=$sno2_3&$msgsave";
									$associate_name2_3 = '('.$data_3[1]['associate_name'].')';
								}else{
									$uname2_3 = 'N/A';
									$sno2_3 = '';
									$url2_3 = 'javascript:void(0)';
									$associate_name2_3 = '';
								}
							////
								}else{
									$uname1_3 = 'N/A';
									$sno1_3 = '';
									$url1_3 = 'javascript:void(0)';
									$associate_name1_3 = '';
									$uname2_3 = 'N/A';
									$sno2_3 = '';
									$url2_3 = 'javascript:void(0)';
									$associate_name2_3 = '';
								}
							?>
							
							
								<div class="col-6" style="text-align: center;">
								<a href="<?php echo $url1_3;?>">
								<img src="../images/subadmin.png" class="img-fluid" width="50"> <br>
								<span class="" style="color: green"><?php echo $uname1_3.''.$associate_name1_3; ?></span>
								</a>
									<!--hr style="width: 66%; color: black; border-top: 2px solid black;"-->
								</div>
								<div class="col-6" style="text-align: center;"> 
								<a href="<?php echo $url2_3;?>">
								<img src="../images/subadmin.png" class="img-fluid" width="50"><br>
								<span class="" style="color: green"><?php echo $uname2_3.''.$associate_name2_3; ?></span>
								</a>									
									<!--hr style="width: 66%; color: black; border-top: 2px solid black;"-->
								</div>
							</div>
						</div>
					</div>
					<!--div class="row">
						<div class="col-3">
							<div class="row mt-0">							
								<div class="col-5 p-1" style="text-align: center;"> 
								<img src="../images/subadmin.png" class="img-fluid" width="50"> <br>
									<span style="color: red"><?php //echo $a6; ?></span>
								</div>
								<div class="col-5 offset-2 p-1" style="text-align: center;"> 
								<img src="../images/subadmin.png" class="img-fluid" width="50"><br>
									<span style="color: red"><?php //echo $a7; ?></span>
								</div>
							</div>
						</div>
						<div class="col-3">
						<div class="row">
							<div class="col-5 p-1" style="text-align: center;"> <img src="../images/subadmin.png" class="img-fluid" width="50"> <br>
								<span style="color: red"><?php //echo $a8; ?></span>
							</div>
							<div class="col-5 offset-2  p-1" style="text-align: center;"><img src="../images/subadmin.png" class="img-fluid" width="50"><br>
							<span style="color: red"><?php //echo $a9; ?></span>
							</div>
						</div>
						</div>
						<div class="col-3"><div class="row">
							<div class="col-5 p-1" style="text-align: center;"> <img src="../images/subadmin.png" class="img-fluid" width="50"> <br>
								<span style="color: red"><?php //echo $a10; ?></span>
							</div>
							<div class="col-5 offset-2  p-1" style="text-align: center;"> <img src="../images/subadmin.png" class="img-fluid" width="50"><br>
									<span style="color: red"><?php //echo $a11; ?></span>
								</div>
						</div></div>
					<div class="col-3"><div class="row">
							<div class="col-5 p-1" style="text-align: center;"> <img src="../images/subadmin.png" class="img-fluid" width="50"> <br>
							<span style="color: red"><?php //echo $a12; ?></span>
							</div>
							<div class="col-5 offset-2  p-1" style="text-align: center;"> <img src="../images/subadmin.png" class="img-fluid" width="50"><br>
							<span style="color: red"><?php //echo $a13; ?></span>
									
							</div>
						</div></div>
					
				</div-->
				
			</div>
		</div>	
			
</div>



<style>
hr {position:relative;}
.img-fluid {position:relative;border-radius:50%; border:1px solid #333;}
hr:before, hr:after, .line1:before, .line:before {height:18px; width:2px; background:#000; position:absolute; content:"";}
hr:before {  left:0px;}
hr:after {  right:0px;}
.line1:before {top:66%;left:50%;}
.line:before {top:82%;left:50%;}
</style>


<?php include("../footer2.php"); 
}else{
	header("Location: ../logout.php");
}
?>

<script>
$('.clk').on("click",function(){
	var id=$(this).data().id;
	$.post("api.php?tag=find",{"id":id},function(d){
		console.log(d);
	});
});
</script>
