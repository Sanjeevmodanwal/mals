<?php
session_start();
include("../db.php");
	
header("Content-Type: application/vnd.ms-excel");

if(isset($_SESSION['sno']) && !empty($_SESSION['sno'])){
$sessionid = $_SESSION['sno'];
$result1 = "SELECT sno,type FROM users WHERE sno = '$sessionid'";
$getusers = mysqli_query($con, $result1);
$rowusers = mysqli_fetch_assoc($getusers);
	$loggedid = mysqli_real_escape_string($con, $rowusers['sno']);
}else{
	$loggedid = '';
}

echo 'Sno.' . "\t" . 'Username'. "\t" . 'Associate Name'.  "\t" . 'Parent Name'.  "\t" . 'Introduser Id'. "\t" .  'Position'. "\t" . 'Shirt No.'. "\t" . 'Size'. "\t" . 'created' .  "\n";

$ccc = "SELECT sno,associate_name,username,parent_id,sponser_id,position,size,lenght,created FROM users WHERE type='Admin' AND parent_id='$loggedid'";
// die;
$getccc = mysqli_query($con, $ccc);
while ($row_asso1 = mysqli_fetch_assoc($getccc)) {
	$ssno = mysqli_real_escape_string($con, $row_asso1['sno']);
	$associate_name1 = mysqli_real_escape_string($con, $row_asso1['associate_name']);
	$sponser_id1 = mysqli_real_escape_string($con, $row_asso1['sponser_id']);
	$parent_id1 = mysqli_real_escape_string($con, $row_asso1['parent_id']);
	$username1 = mysqli_real_escape_string($con, $row_asso1['username']);
	$position1 = mysqli_real_escape_string($con, $row_asso1['position']);
	$size1 = mysqli_real_escape_string($con, $row_asso1['size']);
	$lenght1 = mysqli_real_escape_string($con, $row_asso1['lenght']);
	$created1 = mysqli_real_escape_string($con, $row_asso1['created']);
	
	 $prnt_qry = mysqli_query($con,"SELECT username FROM users where sno='$sponser_id1'");
		 while ($row_prnt_qry = mysqli_fetch_assoc($prnt_qry)) {
		 $sponser_id_name1 = mysqli_real_escape_string($con, $row_prnt_qry['username']);
	}
	$prnt_qry1 = mysqli_query($con,"SELECT username FROM users where sno='$parent_id1'");
		 while ($row_prnt_qry1 = mysqli_fetch_assoc($prnt_qry1)) {
		 $parent_id_name1 = mysqli_real_escape_string($con, $row_prnt_qry1['username']);
	}
							
	
echo $ssno . "\t" . $username1 . "\t" . $associate_name1. "\t"  . $parent_id_name1 . "\t"  . $sponser_id_name1 . "\t"  . $position1 . "\t"  . $lenght1 . "\t"  . $size1 . "\t" . $created1.  "\n";

$cccz = "SELECT sno,associate_name,username,parent_id,sponser_id,position,size,lenght,created FROM users WHERE type='Admin' AND parent_id='$ssno'";
					
$getccca = mysqli_query($con, $cccz);
while ($row_asso = mysqli_fetch_assoc($getccca)) {
$snoid = mysqli_real_escape_string($con, $row_asso['sno']);
$associate_name = mysqli_real_escape_string($con, $row_asso['associate_name']);
$sponser_id = mysqli_real_escape_string($con, $row_asso['sponser_id']);
$parent_id = mysqli_real_escape_string($con, $row_asso['parent_id']);
$username = mysqli_real_escape_string($con, $row_asso['username']);
$position = mysqli_real_escape_string($con, $row_asso['position']);
$size = mysqli_real_escape_string($con, $row_asso['size']);
$lenght = mysqli_real_escape_string($con, $row_asso['lenght']);
$created = mysqli_real_escape_string($con, $row_asso['created']);

$prnt_qry = mysqli_query($con,"SELECT username FROM users where sno='$sponser_id'");
	 while ($row_prnt_qry = mysqli_fetch_assoc($prnt_qry)) {
	 $sponser_id_name = mysqli_real_escape_string($con, $row_prnt_qry['username']);
}
$prnt_qry1 = mysqli_query($con,"SELECT username FROM users where sno='$parent_id'");
	 while ($row_prnt_qry1 = mysqli_fetch_assoc($prnt_qry1)) {
	 $parent_id_name = mysqli_real_escape_string($con, $row_prnt_qry1['username']);
}


echo $snoid . "\t" . $username . "\t" . $associate_name. "\t"  . $parent_id_name . "\t"  . $sponser_id_name . "\t"  . $position . "\t"  . $lenght . "\t"  . $size . "\t" . $created.  "\n";

//// Step3 ////

$cccz_3 = "SELECT sno,associate_name,username,parent_id,sponser_id,position,size,lenght,created FROM users WHERE type='Admin' AND parent_id='$snoid'";
					
$getccca_3 = mysqli_query($con, $cccz_3);
while ($row_asso_3 = mysqli_fetch_assoc($getccca_3)) {
$snoid_3 = mysqli_real_escape_string($con, $row_asso_3['sno']);
$associate_name_3 = mysqli_real_escape_string($con, $row_asso_3['associate_name']);
$sponser_id_3 = mysqli_real_escape_string($con, $row_asso_3['sponser_id']);
$parent_id_3 = mysqli_real_escape_string($con, $row_asso_3['parent_id']);
$username_3 = mysqli_real_escape_string($con, $row_asso_3['username']);
$position_3 = mysqli_real_escape_string($con, $row_asso_3['position']);
$size_3 = mysqli_real_escape_string($con, $row_asso_3['size']);
$lenght_3 = mysqli_real_escape_string($con, $row_asso_3['lenght']);
$created_3 = mysqli_real_escape_string($con, $row_asso_3['created']);

$prnt_qry_3 = mysqli_query($con,"SELECT username FROM users where sno='$sponser_id_3'");
	 while ($row_prnt_qry_3 = mysqli_fetch_assoc($prnt_qry_3)) {
	 $sponser_id_name_3 = mysqli_real_escape_string($con, $row_prnt_qry_3['username']);
}
$prnt_qry_3 = mysqli_query($con,"SELECT username FROM users where sno='$parent_id_3'");
	 while ($row_prnt_qry_3 = mysqli_fetch_assoc($prnt_qry_3)) {
	 $parent_id_name_3 = mysqli_real_escape_string($con, $row_prnt_qry_3['username']);
}


echo $snoid_3 . "\t" . $username_3 . "\t" . $associate_name_3. "\t"  . $parent_id_name_3 . "\t"  . $sponser_id_name_3 . "\t"  . $position_3 . "\t"  . $lenght_3 . "\t"  . $size_3 . "\t" . $created_3.  "\n";

//// Step4 ////

$cccz_4 = "SELECT sno,associate_name,username,parent_id,sponser_id,position,size,lenght,created FROM users WHERE type='Admin' AND parent_id='$snoid_3'";
					
$getccca_4 = mysqli_query($con, $cccz_4);
while ($row_asso_4 = mysqli_fetch_assoc($getccca_4)) {
$snoid_4 = mysqli_real_escape_string($con, $row_asso_4['sno']);
$associate_name_4 = mysqli_real_escape_string($con, $row_asso_4['associate_name']);
$sponser_id_4 = mysqli_real_escape_string($con, $row_asso_4['sponser_id']);
$parent_id_4 = mysqli_real_escape_string($con, $row_asso_4['parent_id']);
$username_4 = mysqli_real_escape_string($con, $row_asso_4['username']);
$position_4 = mysqli_real_escape_string($con, $row_asso_4['position']);
$size_4 = mysqli_real_escape_string($con, $row_asso_4['size']);
$lenght_4 = mysqli_real_escape_string($con, $row_asso_4['lenght']);
$created_4 = mysqli_real_escape_string($con, $row_asso_4['created']);

$prnt_qry_4 = mysqli_query($con,"SELECT username FROM users where sno='$sponser_id_4'");
	 while ($row_prnt_qry_4 = mysqli_fetch_assoc($prnt_qry_4)) {
	 $sponser_id_name_4 = mysqli_real_escape_string($con, $row_prnt_qry_4['username']);
}
$prnt_qry_4 = mysqli_query($con,"SELECT username FROM users where sno='$parent_id_4'");
	 while ($row_prnt_qry_4 = mysqli_fetch_assoc($prnt_qry_4)) {
	 $parent_id_name_4 = mysqli_real_escape_string($con, $row_prnt_qry_4['username']);
}


echo $snoid_4 . "\t" . $username_4 . "\t" . $associate_name_4. "\t"  . $parent_id_name_4 . "\t"  . $sponser_id_name_4 . "\t"  . $position_4 . "\t"  . $lenght_4 . "\t"  . $size_4 . "\t" . $created_4.  "\n";

//// Step5 ////

$cccz_5 = "SELECT sno,associate_name,username,parent_id,sponser_id,position,size,lenght,created FROM users WHERE type='Admin' AND parent_id='$snoid_4'";
					
$getccca_5 = mysqli_query($con, $cccz_5);
while ($row_asso_5 = mysqli_fetch_assoc($getccca_5)) {
$snoid_5 = mysqli_real_escape_string($con, $row_asso_5['sno']);
$associate_name_5 = mysqli_real_escape_string($con, $row_asso_5['associate_name']);
$sponser_id_5 = mysqli_real_escape_string($con, $row_asso_5['sponser_id']);
$parent_id_5 = mysqli_real_escape_string($con, $row_asso_5['parent_id']);
$username_5 = mysqli_real_escape_string($con, $row_asso_5['username']);
$position_5 = mysqli_real_escape_string($con, $row_asso_5['position']);
$size_5 = mysqli_real_escape_string($con, $row_asso_5['size']);
$lenght_5 = mysqli_real_escape_string($con, $row_asso_5['lenght']);
$created_5 = mysqli_real_escape_string($con, $row_asso_5['created']);

$prnt_qry_5 = mysqli_query($con,"SELECT username FROM users where sno='$sponser_id_5'");
	 while ($row_prnt_qry_5 = mysqli_fetch_assoc($prnt_qry_5)) {
	 $sponser_id_name_5 = mysqli_real_escape_string($con, $row_prnt_qry_5['username']);
}
$prnt_qry_5 = mysqli_query($con,"SELECT username FROM users where sno='$parent_id_5'");
	 while ($row_prnt_qry_5 = mysqli_fetch_assoc($prnt_qry_5)) {
	 $parent_id_name_5 = mysqli_real_escape_string($con, $row_prnt_qry_5['username']);
}


echo $snoid_5 . "\t" . $username_5 . "\t" . $associate_name_5. "\t"  . $parent_id_name_5 . "\t"  . $sponser_id_name_5 . "\t"  . $position_5 . "\t"  . $lenght_5 . "\t"  . $size_5 . "\t" . $created_5.  "\n";

//// Step6 ////

$cccz_6 = "SELECT sno,associate_name,username,parent_id,sponser_id,position,size,lenght,created FROM users WHERE type='Admin' AND parent_id='$snoid_5'";
					
$getccca_6 = mysqli_query($con, $cccz_6);
while ($row_asso_6 = mysqli_fetch_assoc($getccca_6)) {
$snoid_6 = mysqli_real_escape_string($con, $row_asso_6['sno']);
$associate_name_6 = mysqli_real_escape_string($con, $row_asso_6['associate_name']);
$sponser_id_6 = mysqli_real_escape_string($con, $row_asso_6['sponser_id']);
$parent_id_6 = mysqli_real_escape_string($con, $row_asso_6['parent_id']);
$username_6 = mysqli_real_escape_string($con, $row_asso_6['username']);
$position_6 = mysqli_real_escape_string($con, $row_asso_6['position']);
$size_6 = mysqli_real_escape_string($con, $row_asso_6['size']);
$lenght_6 = mysqli_real_escape_string($con, $row_asso_6['lenght']);
$created_6 = mysqli_real_escape_string($con, $row_asso_6['created']);

$prnt_qry_6 = mysqli_query($con,"SELECT username FROM users where sno='$sponser_id_6'");
	 while ($row_prnt_qry_6 = mysqli_fetch_assoc($prnt_qry_6)) {
	 $sponser_id_name_6 = mysqli_real_escape_string($con, $row_prnt_qry_6['username']);
}
$prnt_qry_6 = mysqli_query($con,"SELECT username FROM users where sno='$parent_id_6'");
	 while ($row_prnt_qry_6 = mysqli_fetch_assoc($prnt_qry_6)) {
	 $parent_id_name_6 = mysqli_real_escape_string($con, $row_prnt_qry_6['username']);
}


echo $snoid_6 . "\t" . $username_6 . "\t" . $associate_name_6. "\t"  . $parent_id_name_6 . "\t"  . $sponser_id_name_6 . "\t"  . $position_6 . "\t"  . $lenght_6 . "\t"  . $size_6 . "\t" . $created_6.  "\n";

//// Step7 ////

$cccz_7 = "SELECT sno,associate_name,username,parent_id,sponser_id,position,size,lenght,created FROM users WHERE type='Admin' AND parent_id='$snoid_6'";
					
$getccca_7 = mysqli_query($con, $cccz_7);
while ($row_asso_7 = mysqli_fetch_assoc($getccca_7)) {
$snoid_7 = mysqli_real_escape_string($con, $row_asso_7['sno']);
$associate_name_7 = mysqli_real_escape_string($con, $row_asso_7['associate_name']);
$sponser_id_7 = mysqli_real_escape_string($con, $row_asso_7['sponser_id']);
$parent_id_7 = mysqli_real_escape_string($con, $row_asso_7['parent_id']);
$username_7 = mysqli_real_escape_string($con, $row_asso_7['username']);
$position_7 = mysqli_real_escape_string($con, $row_asso_7['position']);
$size_7 = mysqli_real_escape_string($con, $row_asso_7['size']);
$lenght_7 = mysqli_real_escape_string($con, $row_asso_7['lenght']);
$created_7 = mysqli_real_escape_string($con, $row_asso_7['created']);

$prnt_qry_7 = mysqli_query($con,"SELECT username FROM users where sno='$sponser_id_7'");
	 while ($row_prnt_qry_7 = mysqli_fetch_assoc($prnt_qry_7)) {
	 $sponser_id_name_7 = mysqli_real_escape_string($con, $row_prnt_qry_7['username']);
}
$prnt_qry_7 = mysqli_query($con,"SELECT username FROM users where sno='$parent_id_7'");
	 while ($row_prnt_qry_7 = mysqli_fetch_assoc($prnt_qry_7)) {
	 $parent_id_name_7 = mysqli_real_escape_string($con, $row_prnt_qry_7['username']);
}


echo $snoid_7 . "\t" . $username_7 . "\t" . $associate_name_7. "\t"  . $parent_id_name_7 . "\t"  . $sponser_id_name_7 . "\t"  . $position_7 . "\t"  . $lenght_7 . "\t"  . $size_7 . "\t" . $created_7.  "\n";

//// Step8 ////

$cccz_8 = "SELECT sno,associate_name,username,parent_id,sponser_id,position,size,lenght,created FROM users WHERE type='Admin' AND parent_id='$snoid_7'";
					
$getccca_8 = mysqli_query($con, $cccz_8);
while ($row_asso_8 = mysqli_fetch_assoc($getccca_8)) {
$snoid_8 = mysqli_real_escape_string($con, $row_asso_8['sno']);
$associate_name_8 = mysqli_real_escape_string($con, $row_asso_8['associate_name']);
$sponser_id_8 = mysqli_real_escape_string($con, $row_asso_8['sponser_id']);
$parent_id_8 = mysqli_real_escape_string($con, $row_asso_8['parent_id']);
$username_8 = mysqli_real_escape_string($con, $row_asso_8['username']);
$position_8 = mysqli_real_escape_string($con, $row_asso_8['position']);
$size_8 = mysqli_real_escape_string($con, $row_asso_8['size']);
$lenght_8 = mysqli_real_escape_string($con, $row_asso_8['lenght']);
$created_8 = mysqli_real_escape_string($con, $row_asso_8['created']);

$prnt_qry_8 = mysqli_query($con,"SELECT username FROM users where sno='$sponser_id_8'");
	 while ($row_prnt_qry_8 = mysqli_fetch_assoc($prnt_qry_8)) {
	 $sponser_id_name_8 = mysqli_real_escape_string($con, $row_prnt_qry_8['username']);
}
$prnt_qry_8 = mysqli_query($con,"SELECT username FROM users where sno='$parent_id_8'");
	 while ($row_prnt_qry_8 = mysqli_fetch_assoc($prnt_qry_8)) {
	 $parent_id_name_8 = mysqli_real_escape_string($con, $row_prnt_qry_8['username']);
}


echo $snoid_8 . "\t" . $username_8 . "\t" . $associate_name_8. "\t"  . $parent_id_name_8 . "\t"  . $sponser_id_name_8 . "\t"  . $position_8 . "\t"  . $lenght_8 . "\t"  . $size_8 . "\t" . $created_8.  "\n";

//// Step9 ////

$cccz_9 = "SELECT sno,associate_name,username,parent_id,sponser_id,position,size,lenght,created FROM users WHERE type='Admin' AND parent_id='$snoid_8'";
					
$getccca_9 = mysqli_query($con, $cccz_9);
while ($row_asso_9 = mysqli_fetch_assoc($getccca_9)) {
$snoid_9 = mysqli_real_escape_string($con, $row_asso_9['sno']);
$associate_name_9 = mysqli_real_escape_string($con, $row_asso_9['associate_name']);
$sponser_id_9 = mysqli_real_escape_string($con, $row_asso_9['sponser_id']);
$parent_id_9 = mysqli_real_escape_string($con, $row_asso_9['parent_id']);
$username_9 = mysqli_real_escape_string($con, $row_asso_9['username']);
$position_9 = mysqli_real_escape_string($con, $row_asso_9['position']);
$size_9 = mysqli_real_escape_string($con, $row_asso_9['size']);
$lenght_9 = mysqli_real_escape_string($con, $row_asso_9['lenght']);
$created_9 = mysqli_real_escape_string($con, $row_asso_9['created']);

$prnt_qry_9 = mysqli_query($con,"SELECT username FROM users where sno='$sponser_id_9'");
	 while ($row_prnt_qry_9 = mysqli_fetch_assoc($prnt_qry_9)) {
	 $sponser_id_name_9 = mysqli_real_escape_string($con, $row_prnt_qry_9['username']);
}
$prnt_qry_9 = mysqli_query($con,"SELECT username FROM users where sno='$parent_id_9'");
	 while ($row_prnt_qry_9 = mysqli_fetch_assoc($prnt_qry_9)) {
	 $parent_id_name_9 = mysqli_real_escape_string($con, $row_prnt_qry_9['username']);
}


echo $snoid_9 . "\t" . $username_9 . "\t" . $associate_name_9. "\t"  . $parent_id_name_9 . "\t"  . $sponser_id_name_9 . "\t"  . $position_9 . "\t"  . $lenght_9 . "\t"  . $size_9 . "\t" . $created_9.  "\n";


//9
}
//8
}
//7
}
//6
}
//5
}
//4
}
//3
}
//2
}
//1
}

header("Content-disposition: attachment; filename=All_details_download.xls");
?>