<?php
ob_start();
include("../db.php");
include("../header2.php");

if(!isset($_SESSION['sno'])){
    header("Location: ../login");
    exit(); 
}

if(isset($_SESSION['sno']) && !empty($_SESSION['sno'])){
$sessionid = $_SESSION['sno'];
$result1 = "SELECT sno,type FROM users WHERE sno = '$sessionid'";
$getusers = mysqli_query($con, $result1);
$rowusers = mysqli_fetch_assoc($getusers);
	$loggedid = mysqli_real_escape_string($con, $rowusers['sno']);
	$adminrole = mysqli_real_escape_string($con, $rowusers['type']);
}else{
	$loggedid = '';
	$adminrole = '';
}

if($adminrole == 'Admin'){
?>
<div id="wrapper">
    <?php include("../sidebar2.php"); ?>
	
    <div id="content-wrapper">
      <div class="container-fluid">
		<div class="card mb-3">
          <div class="card-header">
            <i class="fas fa-table"></i>
            Total Joining</div>
			
          <div class="card-body">
            <div class="table-responsive">
              <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                  <tr>
					<th>Sno.</th>
					<th>Joining Date</th>
					<th>User Id</th>
                  </tr>
                </thead>
                <tbody>
				<?php 
				 $count = 1;
				$resultAssociate = mysqli_query($con,"SELECT username,created FROM users WHERE type!='Super_admin'");
				while ($row_asso = mysqli_fetch_assoc($resultAssociate)) {
					$username = mysqli_real_escape_string($con, $row_asso['username']);
					$created = mysqli_real_escape_string($con, $row_asso['created']);
					$array_cre  = explode(' ', $created);
					$getdob = date("d/m/Y",strtotime($array_cre[0]));
				?>
                  <tr>
                    <td><?php echo $count++; ?></td>
                    <td><?php echo $getdob; ?></td>
                    <td><?php echo $username; ?></td>
                  </tr>
                <?php } ?>
                </tbody>
              </table>
            </div>
          </div>
        </div>	

<?php include("../footer2.php"); 
}else{
	header("Location: ../logout.php");
}
?>
