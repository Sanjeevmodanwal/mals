<?php
ob_start();
include("../db.php");
include("../header2.php");

if(!isset($_SESSION['sno'])){
    header("Location: ../login");
    exit(); 
}

if(isset($_SESSION['sno']) && !empty($_SESSION['sno'])){
$sessionid = $_SESSION['sno'];
$result1 = "SELECT sno,type FROM users WHERE sno = '$sessionid'";
$getusers = mysqli_query($con, $result1);
$rowusers = mysqli_fetch_assoc($getusers);
	$loggedid = mysqli_real_escape_string($con, $rowusers['sno']);
	$adminrole = mysqli_real_escape_string($con, $rowusers['type']);
}else{
	$loggedid = '';
	$adminrole = '';
}

$num_str = sprintf("%04d", mt_rand(1, 9999));

if($adminrole == 'Admin'){
?>
<div id="wrapper">
    <?php include("../sidebar2.php"); ?>
	
    <div id="content-wrapper">
      <div class="container-fluid">
	   
<?php if(isset($_GET['msg'])){
	if(isset($_GET['msg']) == 'successfully'){ 
?>
	<div class='alertdiv'>
		<div class='alert alert-danger' style="text-align:center;">
			<?php echo 'Do not Saved,Please try again!!!'; ?>
		</div>
    </div>     
<?php } } ?>
	  
        <!-- Breadcrumbs-->
        <ol class="breadcrumb">
          <li class="breadcrumb-item">
            <a href="../dashboardag">Dashboard</a>
          </li>
          <li class="breadcrumb-item active">New Add</li>
        </ol>

        <!-- Icon Cards-->
        <div class="row">
			<div class="col-lg-12">
			<div class="panel panel-default">
	<form action="../mysqlaction.php" method="post" autocomplete="off" enctype="multipart/form-data">
		<div class="panel-body">
			<div class="form-group">
				<div class="row">
					<div class="col-sm-2">
						<label>Associate Name <span class="required">*</span></label>
					</div>
					<div class="col-sm-4">
						<input name="associate_name" type="text" class="form-control" required />
					</div>
					<div class="col-sm-2">
						<label>Associate Id <span class="required">*</span></label>
					</div>
					<div class="col-sm-4">
						<input name="username" type="text" value="<?php echo 'MALS'.$num_str; ?>" class="form-control" readonly />
					</div>
				</div>
			</div>
			
			<input name="parent_id" type="hidden" value="<?php echo $loggedid;?>">

			<div class="form-group">
				<div class="row">
					<div class="col-sm-2">
						<label>Mobile No <span class="required">*</span></label>
					</div>
					<div class="col-sm-4">
						<input name="mobile" type="number" class="form-control" required />
					</div>

					<div class="col-sm-2">
						<label for="exampleInputEmail1">Email Id <span class="required">*</span></label>
					</div>
					<div class="col-sm-4">
						<input name="email_address" type="email" class="form-control" required />
					</div>
				</div>
			</div>
			<div class="form-group">
				<div class="row">					
					<div class="col-sm-2">
						<label>GSTIN No.</label>
					</div>
					<div class="col-sm-4">
						<input name="gstin_no" type="text" class="form-control" />
					</div>
					<div class="col-sm-2">
						<label for="exampleInputEmail1">Password <span class="required">*</span></label>
					</div>
					<div class="col-sm-4">
						<input name="password" type="password" class="form-control" required />
					</div>
				</div>
			</div>
				<div class="form-group">
				<div class="row">
					<div class="col-sm-2">
						<label>Associate address</label>
					</div>
					<div class="col-sm-4">
						<input name="associate_address" type="text" class="form-control" />
					</div>
					<div class="col-sm-2">
						<label>Country</label>
					</div>
					<div class="col-sm-4">
						<select name="country" class="form-control countrydiv">
							<option value="">Select Country</option>
							<?php $cntList = mysqli_query($con, "Select country_name from country_state_city group by country_name");
							while ($rowcountry = mysqli_fetch_array($cntList)){ 
								$countryname = $rowcountry['country_name'];
							?>
							<option value="<?php echo $countryname; ?>"><?php echo $countryname; ?></option> 
							<?php } ?>  
						</select>						
					</div>
				</div>
				</div>
				<div class="form-group">
				<div class="row">
					<div class="col-sm-2">
						<label for="exampleInputEmail1">Select State</label>
					</div>
					<div class="col-sm-4">
						<select name="state" class="form-control statediv" dataval="">
							<option value="">Select State</option>
						</select>
					</div>
					<div class="col-sm-2">
						<label for="exampleInputEmail1">Select City</label>
					</div>
					<div class="col-sm-4">
						<select name="city" class="form-control citydiv">
							<option value="">Select City</option>
						</select>
					</div>
				</div>
				</div>
				<div class="form-group">
				<div class="row">
					<div class="col-sm-2">
						<label for="exampleInputEmail1">Pin Code </label>
					</div>
					<div class="col-sm-4">
						<input name="pin_code" type="text" class="form-control" />
						
					</div>
					<div class="col-sm-2">
						<label for="exampleInputEmail1">Date OF Birth</label>
					</div>
					<div class="col-sm-4">
						<input name="dob" type="text" class="form-control datepicker123" />						
					</div>
				</div>
				</div>
				
				<div class="form-group">
				<div class="row">
					<div class="col-sm-2">
						<label>Lenght</label>
					</div>
					<div class="col-sm-4">
						<select name="lenght" class="form-control">
							<option value="">Select Option</option>
							<option value="30">30</option>
							<option value="31">31</option>
							<option value="32">32</option>
							<option value="33">33</option>
							<option value="34">34</option>
							<option value="35">35</option>
							<option value="36">36</option>
							<option value="37">37</option>
							<option value="38">38</option>
							<option value="39">39</option>
							<option value="40">40</option>
							<option value="41">41</option>
							<option value="42">42</option>
							<option value="43">43</option>
							<option value="44">44</option>
							<option value="45">45</option>
						</select>
					</div>

					<div class="col-sm-2">
						<label for="exampleInputEmail1">Size</label>
					</div>
					<div class="col-sm-4">
						<select name="size" class="form-control" required>
							<option value="">Select Option</option>
							<option value="XS">XS</option>
							<option value="Small">Small</option>
							<option value="Medium">Medium</option>
							<option value="Large">Large</option>
							<option value="X-Large">X-Large</option>
							<option value="XX-Large">XX-Large</option>
						</select>
					</div>
				</div>
				</div>

				<div class="form-group">
				<div class="row">
					<div class="col-md-2">
						<label>Nominee Name</label>
					</div>
					<div class="col-md-4">
						<input name="nominee_name" type="text" class="form-control" />
					</div>
					<div class="col-md-2">
						<label>Nominee Age</label>
					</div>
					<div class="col-md-4">
						<input name="nominee_age" type="text" class="form-control" />
						
					</div>
				</div>
				</div>
				<div class="form-group">
				<div class="row">
					<div class="col-md-2">
						<label>Nominee Relation</label>
					</div>
					<div class="col-md-4">
						<input name="nominee_relation" type="text" class="form-control" />
					</div>
				</div>
				</div>

				<div class="form-group">
				<div class="row">
					<div class="col-sm-2">
						<label for="exampleInputEmail1">Account No </label>
					</div>
					<div class="col-sm-4">
						<input name="account_no" type="text" class="form-control" />
					</div>

					<div class="col-sm-2">
						<label for="exampleInputEmail1">Account Holder Name</label>
					</div>
					<div class="col-sm-4">
						<input name="account_holder_name" type="text" class="form-control" />
					</div>
				</div>
				</div>
				<div class="form-group">
				<div class="row">
					<div class="col-sm-2">
						<label for="exampleInputEmail1">Bank Name </label>
					</div>
					<div class="col-sm-4">
						<select name="bank_name" class="form-control">
							<option value="">Select Bank</option>
							<option value="ALLAHABAD BANK">ALLAHABAD BANK</option>
							<option value="ALLAHABAD UP GRAMIN BANK">ALLAHABAD UP GRAMIN BANK</option>
							<option value="ANDHRA BANK">ANDHRA BANK</option>
							<option value="AXIS BANK">AXIS BANK</option>
							<option value="BANDHAN BANK">BANDHAN BANK</option>
							<option value="BANGIYA GURAMIN VIKAS BANK">BANGIYA GURAMIN VIKAS BANK</option>
							<option value="BANK OF BARODA">BANK OF BARODA</option>
							<option value="BANK OF INDIA">BANK OF INDIA</option>
							<option value="BANK OF MAHARASHTRA">BANK OF MAHARASHTRA</option>
							<option value="BARODA  UTTAR PRADESH GARMIN  BANK">BARODA  UTTAR PRADESH GARMIN  BANK</option>
							<option value="BHART CO BANK">BHART CO BANK</option>
							<option value="BIHAR GRAMIN  BANK">BIHAR GRAMIN  BANK</option>
							<option value="BIHAR GRAMIN BANK">BIHAR GRAMIN BANK</option>
							<option value="CANARA BANK">CANARA BANK</option>
							<option value="CAPITAL SMALL FINANCE BANK">CAPITAL SMALL FINANCE BANK</option>
							<option value="CENTRAL BANK OF INDIA">CENTRAL BANK OF INDIA</option>
							<option value="CORPORATION BANK">CORPORATION BANK</option>
							<option value="DENA BANK">DENA BANK</option>
							<option value="DOMBIVLI NAGRI SAHAKARI BANK LTD">DOMBIVLI NAGRI SAHAKARI BANK LTD</option>
							<option value="FEDERAL BANK">FEDERAL BANK</option>
							<option value="HDFC">HDFC</option>
							<option value="ICICI BANK">ICICI BANK</option>
							<option value="IDBI BANK LIMITED">IDBI BANK LIMITED</option>
							<option value="IDFC BANK">IDFC BANK</option>
							<option value="INDIAN BANK">INDIAN BANK</option>
							<option value="INDIAN OVERSEAS BANK">INDIAN OVERSEAS BANK</option>
							<option value="INDUSIND BANK">INDUSIND BANK</option>
							<option value="KARNATKA BANK LTD.">KARNATKA BANK LTD.</option>
							<option value="KOTAK MAHINDRA BANK">KOTAK MAHINDRA BANK</option>
							<option value="MALDA  CENTRAL CO - OPERATIVE BANK">MALDA  CENTRAL CO - OPERATIVE BANK</option>
							<option value="ORIENTAL BANK OF COMMERCE">ORIENTAL BANK OF COMMERCE</option>
							<option value="PNB">PNB</option>
							<option value="PRATHAMA BANK">PRATHAMA BANK</option>
							<option value="PUNJAB AND SIND BANK">PUNJAB AND SIND BANK</option>
							<option value="RBL BANK">RBL BANK</option>
							<option value="SARSWAT BANK">SARSWAT BANK</option>
							<option value="SBI">SBI</option>
							<option value="SYNDICATE BANK">SYNDICATE BANK</option>
							<option value="UCO BANK">UCO BANK</option>
							<option value="UNION BANK">UNION BANK</option>
							<option value="UNION BANK BANK OF INDIA">UNION BANK BANK OF INDIA</option>
							<option value="UNITED BANK OF INDIA">UNITED BANK OF INDIA</option>
							<option value="VANACHAL GRAMIN BANK">VANACHAL GRAMIN BANK</option>
							<option value="VIJAY BANK">VIJAY BANK</option>
							<option value="YES BANK">YES BANK</option>
						</select>
					</div>

					<div class="col-sm-2">
						<label for="exampleInputEmail1">Branch Name</label>
					</div>
					<div class="col-sm-4">
						<input name="branch_name" type="text" class="form-control" />
					</div>
				</div>
				</div>
				<div class="form-group">
				<div class="row">
					<div class="col-sm-2">
						<label for="exampleInputEmail1">IFSC </label>
					</div>
					<div class="col-sm-4">
						<input name="ifsc" type="text" class="form-control" />
					</div>
					<div class="col-sm-2">
						<label for="exampleInputEmail1">Pan Card No  </label>
					</div>
					<div class="col-sm-4">
						<input name="pan_card_no" type="text" class="form-control" />
					</div>
				</div>
				</div>

				<div class="form-group">
				<div class="row">
					<div class="col-sm-2">
						<label>Aadhar No </label>
					</div>
					<div class="col-sm-4">
						<input name="adhar_no" type="text" class="form-control" />
					</div>
					<div class="col-sm-2">
						<label>Occupation </label>
					</div>
					<div class="col-sm-4">
						<input name="occupation" type="text" class="form-control" />
					</div>
				</div>
				</div>

				<div class="form-group">
				<div class="row">
					<div class="col-sm-2">
						<label>Policy No </label>
					</div>
					<div class="col-sm-4">
						<input name="policy_no" type="text" class="form-control" />
					</div>
				</div>
				</div>

				<div class="form-group">
				<div class="row">
					<div class="col-sm-2">
						<label for="exampleInputEmail1">Upload Pan </label>
					</div>
					<div class="col-sm-4">
						<input type="file" name="upload_pan" />
					</div>
					<div class="col-sm-2">
						<label for="exampleInputEmail1">Upload Aadhar Front </label>
					</div>
					<div class="col-sm-4">
						<input type="file" name="upload_aadhar_front" />
					</div>
				</div>
				</div>

				<div class="form-group">
				<div class="row">
					<div class="col-sm-2">
						<label>Upload Aadhar Back </label>
					</div>
					<div class="col-sm-4">
						<input type="file" name="upload_aadhar_back" />
					</div>
				</div>
				</div>

				<div class="form-group">
				<div class="row">
					<div class="col-sm-2">
						<label for="exampleInputEmail1">Associate Image </label>
					</div>
					<div class="col-sm-4">
						<input type="file" name="associate_image" />
					</div>
					<div class="col-sm-2">
						<label for="exampleInputEmail1">Associate Sign </label>
					</div>
					<div class="col-sm-4">
						<input type="file" name="associate_sign" />
					</div>
				</div>
				</div>

			
			<div class="row">
				<div class="col-md-3">
					<input type="submit" name="addsbmtbtn_agent" value="Submit" class="btn btn-primary">
					
				</div>
			</div>

        </div>
		</form>
        </div>
        </div>
        </div>

        <!-- DataTables Example -->
        <div class="card mb-3">
          
        </div>
   </div>
<script>
$(document).on('change', '.countrydiv', function(){
	var vl = $(this).val();
	$('.statediv').attr('dataval', vl);
	$.post("../response.php?tag=countrytostate",{"country":vl},function(d){
		$(".statediv").html(" ");
		$(".statediv").html("<option value=''>Select Option</option>");
		for (i in d) {
			$('<option value="' + d[i].state_name + '">'+ d[i].state_name +'</option>').appendTo(".statediv");
		}	
	});	
});
</script>

<script>
$(document).on('change', '.statediv', function(){
	var vl = $(this).val();
	var vl2 = $(this).attr('dataval');
	$.post("../response.php?tag=statetocity",{"country":vl2,"state":vl},function(d){
	$(".citydiv").html(" ");
	$(".citydiv").html("<option value=''>Select Option</option>");
	for (i in d) {
		$('<option value="' + d[i].city_name + '">'+ d[i].city_name +'</option>').appendTo(".citydiv");
	}
	});
});
</script>

<?php include("../footer2.php"); 
}else{
	header("Location: ../logout.php");
}
?>
