<?php
ob_start();
include("../db.php");
include("../header2.php");
if(!isset($_SESSION['sno'])){
    header("Location: ../login");
    exit(); 
}
if(isset($_SESSION['sno']) && !empty($_SESSION['sno'])){
$sessionid = $_SESSION['sno'];
$result1 = "SELECT sno,type FROM users WHERE sno = '$sessionid'";
$getusers = mysqli_query($con, $result1);
$rowusers = mysqli_fetch_assoc($getusers);
	$loggedid = mysqli_real_escape_string($con, $rowusers['sno']);
	$adminrole = mysqli_real_escape_string($con, $rowusers['type']);
}else{
	$loggedid = '';
	$adminrole = '';
}

if(!empty($_GET['snoid'])){
	$getid = base64_decode($_GET['snoid']);	
	$result = mysqli_query($con,"SELECT * FROM users WHERE sno = '$getid'");
	$row = mysqli_fetch_assoc($result);
	$insertedId = mysqli_real_escape_string($con, $row['sno']);
	$parent_id = mysqli_real_escape_string($con, $row['parent_id']);
	$sponser_id = mysqli_real_escape_string($con, $row['sponser_id']);
	$position = mysqli_real_escape_string($con, $row['position']);
	$associate_name = mysqli_real_escape_string($con, $row['associate_name']);
	$username = mysqli_real_escape_string($con, $row['username']);
	$mobile = mysqli_real_escape_string($con, $row['mobile']);	$email_address = mysqli_real_escape_string($con, $row['email_address']);
	$orgpass = mysqli_real_escape_string($con, $row['orgpass']);
	$gstin_no = mysqli_real_escape_string($con, $row['gstin_no']);	$associate_address = mysqli_real_escape_string($con, $row['associate_address']);
	$country = mysqli_real_escape_string($con, $row['country']);
	$state = mysqli_real_escape_string($con, $row['state']);
	$city = mysqli_real_escape_string($con, $row['city']);
	$pin_code = mysqli_real_escape_string($con, $row['pin_code']);
	$dob = mysqli_real_escape_string($con, $row['dob']);
	$size = mysqli_real_escape_string($con, $row['size']);
	$lenght = mysqli_real_escape_string($con, $row['lenght']);
	$nominee_name = mysqli_real_escape_string($con, $row['nominee_name']);
	$nominee_age = mysqli_real_escape_string($con, $row['nominee_age']);
	$nominee_relation = mysqli_real_escape_string($con, $row['nominee_relation']);
	$account_no = mysqli_real_escape_string($con, $row['account_no']);
	$account_holder_name = mysqli_real_escape_string($con, $row['account_holder_name']);
	$bank_name = mysqli_real_escape_string($con, $row['bank_name']);
	$branch_name = mysqli_real_escape_string($con, $row['branch_name']);
	$ifsc = mysqli_real_escape_string($con, $row['ifsc']);
	$pan_card_no = mysqli_real_escape_string($con, $row['pan_card_no']);
	$adhar_no = mysqli_real_escape_string($con, $row['adhar_no']);
	// $occupation = mysqli_real_escape_string($con, $row['occupation']);
	// $policy_no = mysqli_real_escape_string($con, $row['policy_no']);
	$upload_pan = mysqli_real_escape_string($con, $row['upload_pan']);
	$upload_aadhar_front = mysqli_real_escape_string($con, $row['upload_aadhar_front']);
	$upload_aadhar_back = mysqli_real_escape_string($con, $row['upload_aadhar_back']);
	$associate_image = mysqli_real_escape_string($con, $row['associate_image']);
	// $associate_sign = mysqli_real_escape_string($con, $row['associate_sign']);
	
	$shirt_delivered_date = mysqli_real_escape_string($con, $row['shirt_delivered_date']);
	$courier_type = mysqli_real_escape_string($con, $row['courier_type']);
	$courier_company = mysqli_real_escape_string($con, $row['courier_company']);
	$courier_mobile = mysqli_real_escape_string($con, $row['courier_mobile']);		$prnt_qry = mysqli_query($con,"SELECT username FROM users where sno='$sponser_id'");		while ($row_prnt_qry = mysqli_fetch_assoc($prnt_qry)) {		$sponser_id_name = mysqli_real_escape_string($con, $row_prnt_qry['username']);	}		if(!empty($parent_id)){	$prnt_qry1 = mysqli_query($con,"SELECT username FROM users where sno='$parent_id'");		while ($row_prnt_qry1 = mysqli_fetch_assoc($prnt_qry1)) {		$parent_id_name = mysqli_real_escape_string($con, $row_prnt_qry1['username']);	}	}else{		$parent_id_name = '';	}
}else{
	$insertedId = '';
	$parent_id = '';
	$sponser_id = '';
	$position = '';
	$associate_name = '';
	$username = '';
	$mobile = '';
	$email_address = '';
	$orgpass = '';
	$gstin_no = '';
	$associate_address = '';
	$country = '';
	$state = '';
	$city = '';
	$pin_code = '';
	$dob = '';
	$size = '';
	$lenght = '';
	$nominee_name = '';
	$nominee_age = '';
	$nominee_relation = '';
	$account_no = '';
	$account_holder_name = '';
	$bank_name = '';
	$branch_name = '';
	$ifsc = '';
	$pan_card_no = '';
	$adhar_no = '';
	// $occupation = '';
	// $policy_no = '';
	$upload_pan = '';
	$upload_aadhar_front = '';
	$upload_aadhar_back = '';
	$associate_image = '';
	// $associate_sign = '';
	$shirt_delivered_date = '';
	$courier_type = '';
	$courier_company = '';
	$courier_mobile = '';	$sponser_id_name = '';	$parent_id_name = '';
}

if($adminrole == 'Admin'){
?>
<div id="wrapper">
    <?php include("../sidebar2.php"); ?>
	
    <div id="content-wrapper">
      <div class="container-fluid">
	<?php if(isset($_GET['msg'])){ ?>  
		<div class="alert alert-success alert-dismissible">
		  <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
		  <strong>Success!</strong> Profile has been updated successfully!!!
		</div>
	<?php } ?>
        <!-- Breadcrumbs-->
        <ol class="breadcrumb">
          <li class="breadcrumb-item">
            <a href="../dashboardag">Dashboard</a>
          </li>
          <li class="breadcrumb-item active">Profile</li>
        </ol>

        <!-- Icon Cards-->
<div class="row">
<div class="col-lg-12">
<div class="panel panel-default">
	<form action="../mysqlaction.php" method="post" autocomplete="off" enctype="multipart/form-data">
	<fieldset>
		<div class="panel-body">
			<div class="form-group">
				<div class="row">
				
					<div class="col-sm-2">
						<label>Associate Name <span class="required">*</span></label>
					</div>
					<div class="col-sm-4">
						<input name="associate_name" type="hidden" value="<?php echo $associate_name; ?>">						<span class="form-control" style="background:#f3eded;"><?php echo $associate_name; ?></span>
					</div>
					<div class="col-sm-2">
						<label>Associate Id <span class="required">*</span></label>
					</div>
					<div class="col-sm-4">
					<span class="form-control" style="background:#f3eded;"><?php echo $username; ?></span>
					</div>
				</div>
			</div>			
			<div class="form-group">
				<div class="row">
					<div class="col-sm-2">
						<label>Sponser Id <span class="required">*</span></label>
					</div>
					<div class="col-sm-4">
						<input name="sponser_id" type="hidden" class="introduser_id" value="<?php echo $sponser_id_name; ?>">
						<span class="form-control" style="background:#f3eded;"><?php echo $sponser_id_name; ?></span>
					</div>										<div class="col-sm-2">						<label>Parent Id <span class="required">*</span></label>					</div>					<div class="col-sm-4">						<input name="parent_id" type="text" class="form-control"  value="<?php echo $parent_id_name; ?>" required />					</div>									</div>				</div>				<div class="form-group">				<div class="row">				
					<div class="col-sm-2">
						<label>Position<span class="required">*</span></label>
					</div>
					<div class="col-sm-4">
						<select name="position" class="form-control" required>
							<option value="">Select Option</option>
							<option value="left"<?php if($position == "left") { echo 'selected="selected"'; } ?>>Left</option>
							<option value="right"<?php if($position == "right") { echo 'selected="selected"'; } ?>>Right</option>
						</select>
					</div>
				</div>
			</div>

			<div class="form-group">
				<div class="row">
					<div class="col-sm-2">
						<label>Mobile No <span class="required">*</span></label>
					</div>
					<div class="col-sm-4">
						<input name="mobile" type="hidden" value="<?php echo $mobile; ?>">						<span class="form-control" style="background:#f3eded;"><?php echo $mobile; ?></span>
					</div>
					<div class="col-sm-2">
						<label for="exampleInputEmail1">Email Id <span class="required">*</span></label>
					</div>
					<div class="col-sm-4">
						<input name="email_address" type="hidden" value="<?php echo $email_address; ?>">
						<span class="form-control" style="background:#f3eded;"><?php echo $email_address; ?></span>
					</div>
				</div>
			</div>
			<div class="form-group">
				<div class="row">					
					<div class="col-sm-2">
						<label>GSTIN No.</label>
					</div>
					<div class="col-sm-4">
						<input name="gstin_no" type="text" class="form-control" value="<?php echo $gstin_no; ?>" />
					</div>
					<div class="col-sm-2">
						<label for="exampleInputEmail1">Password <span class="required">*</span></label>
					</div>
					<div class="col-sm-4">
						<?php echo $orgpass;?>
					</div>
				</div>
			</div>
				<div class="form-group">
				<div class="row">
					<div class="col-sm-2">
						<label>Associate address</label>
					</div>
					<div class="col-sm-4">
						<input name="associate_address" type="hidden" value="<?php echo $associate_address; ?>">						<span class="form-control" style="background:#f3eded;"><?php echo $associate_address; ?></span>
					</div>
					<div class="col-sm-2">
						<label>Country</label>
					</div>
					<div class="col-sm-4">
						<select name="country" class="form-control countrydiv">
							<option value="">Select Country</option>
							<?php $cntList = mysqli_query($con, "Select country_name from country_state_city group by country_name");
							while ($rowcountry = mysqli_fetch_array($cntList)){ 
								$countryname = $rowcountry['country_name'];
							?>
							<option value="<?php echo $countryname; ?>" <?php if($countryname == "$country") { echo 'selected="selected"'; } ?>><?php echo $countryname; ?></option> 
							<?php } ?>  
						</select>
					</div>
				</div>
				</div>
				<div class="form-group">
				<div class="row">
					<div class="col-sm-2">
						<label for="exampleInputEmail1">State</label>
					</div>
					<div class="col-sm-4">
						<input name="state" type="hidden" value="<?php echo $state; ?>">
						<span class="form-control"><?php echo $state; ?></span>
					</div>
					<div class="col-sm-2">
						<label for="exampleInputEmail1">City</label>
					</div>
					<div class="col-sm-4">
						<input name="city" type="text" class="form-control" value="<?php echo $city; ?>" />
					</div>
				</div>
				</div>
				<div class="form-group">
				<div class="row">
					<div class="col-sm-2">
						<label for="exampleInputEmail1">Pin Code </label>
					</div>
					<div class="col-sm-4">
						<input name="pin_code" type="text" class="form-control" value="<?php echo $pin_code; ?>" />
						
					</div>
					<div class="col-sm-2">
						<label for="exampleInputEmail1">Date OF Birth</label>
					</div>
					<div class="col-sm-4">
						<input name="dob" type="text" class="form-control datepicker123" value="<?php echo $dob; ?>" />						
					</div>
				</div>
				</div>
				
				<div class="form-group">
				<div class="row">
					<div class="col-sm-2">
						<label>Shirt Number</label>
					</div>
					<div class="col-sm-4">
						<select name="lenght" class="form-control">
							<option value="">Select Option</option>
							<option value="30"<?php if($lenght == "30") { echo 'selected="selected"'; } ?>>30</option>
							<option value="31"<?php if($lenght == "31") { echo 'selected="selected"'; } ?>>31</option>
							<option value="32"<?php if($lenght == "32") { echo 'selected="selected"'; } ?>>32</option>
							<option value="33"<?php if($lenght == "33") { echo 'selected="selected"'; } ?>>33</option>
							<option value="34"<?php if($lenght == "34") { echo 'selected="selected"'; } ?>>34</option>
							<option value="35"<?php if($lenght == "35") { echo 'selected="selected"'; } ?>>35</option>
							<option value="36"<?php if($lenght == "36") { echo 'selected="selected"'; } ?>>36</option>
							<option value="37"<?php if($lenght == "37") { echo 'selected="selected"'; } ?>>37</option>
							<option value="38"<?php if($lenght == "38") { echo 'selected="selected"'; } ?>>38</option>
							<option value="39"<?php if($lenght == "39") { echo 'selected="selected"'; } ?>>39</option>
							<option value="40"<?php if($lenght == "40") { echo 'selected="selected"'; } ?>>40</option>
							<option value="41"<?php if($lenght == "41") { echo 'selected="selected"'; } ?>>41</option>
							<option value="42"<?php if($lenght == "42") { echo 'selected="selected"'; } ?>>42</option>
							<option value="43"<?php if($lenght == "43") { echo 'selected="selected"'; } ?>>43</option>
							<option value="44"<?php if($lenght == "44") { echo 'selected="selected"'; } ?>>44</option>
							<option value="45"<?php if($lenght == "45") { echo 'selected="selected"'; } ?>>45</option>
						</select>
					</div>

					<div class="col-sm-2">
						<label for="exampleInputEmail1">Size</label>
					</div>
					<div class="col-sm-4">
						<select name="size" class="form-control" required>
							<option value="">Select Option</option>
							<option value="XS"<?php if($size == "XS") { echo 'selected="selected"'; } ?>>XS</option>
							<option value="Small"<?php if($size == "Small") { echo 'selected="selected"'; } ?>>Small</option>
							<option value="Medium"<?php if($size == "Medium") { echo 'selected="selected"'; } ?>>Medium</option>
							<option value="Large"<?php if($size == "Large") { echo 'selected="selected"'; } ?>>Large</option>
							<option value="X-Large"<?php if($size == "X-Large") { echo 'selected="selected"'; } ?>>X-Large</option>
							<option value="XX-Large"<?php if($size == "XX-Large") { echo 'selected="selected"'; } ?>>XX-Large</option>
						</select>
					</div>
				</div>
				</div>

				<div class="form-group">
				<div class="row">
					<div class="col-md-2">
						<label>Nominee Name</label>
					</div>
					<div class="col-md-4">
						<input name="nominee_name" type="text" class="form-control" value="<?php echo $nominee_name; ?>" />
					</div>
					<div class="col-md-2">
						<label>Nominee Age</label>
					</div>
					<div class="col-md-4">
						<input name="nominee_age" type="text" class="form-control" value="<?php echo $nominee_age; ?>" />
						
					</div>
				</div>
				</div>
				<div class="form-group">
				<div class="row">
					<div class="col-md-2">
						<label>Nominee Relation</label>
					</div>
					<div class="col-md-4">
						<input name="nominee_relation" type="text" class="form-control"  value="<?php echo $nominee_relation; ?>" />
					</div>
				</div>
				</div>

				<div class="form-group">
				<div class="row">
					<div class="col-sm-2">
						<label for="exampleInputEmail1">Account No </label>
					</div>
					<div class="col-sm-4">
						<input name="account_no" type="text" class="form-control"  value="<?php echo $account_no; ?>" />
					</div>

					<div class="col-sm-2">
						<label for="exampleInputEmail1">Account Holder Name</label>
					</div>
					<div class="col-sm-4">
						<input name="account_holder_name" type="text" class="form-control"  value="<?php echo $account_holder_name; ?>" />
					</div>
				</div>
				</div>
				<div class="form-group">
				<div class="row">
					<div class="col-sm-2">
						<label for="exampleInputEmail1">Bank Name </label>
					</div>
					<div class="col-sm-4">
						<select name="bank_name" class="form-control">
							<option value="">Select Bank</option>
							<option value="ALLAHABAD BANK" <?php if($bank_name == "ALLAHABAD BANK") { echo 'selected="selected"'; } ?>>ALLAHABAD BANK</option>
							<option value="ALLAHABAD UP GRAMIN BANK"<?php if($bank_name == "ALLAHABAD UP GRAMIN BANK") { echo 'selected="selected"'; } ?>>ALLAHABAD UP GRAMIN BANK</option>
							<option value="ANDHRA BANK" <?php if($bank_name == "ANDHRA BANK") { echo 'selected="selected"'; } ?>>ANDHRA BANK</option>
							<option value="AXIS BANK" <?php if($bank_name == "AXIS BANK") { echo 'selected="selected"'; } ?>>AXIS BANK</option>
							<!--option value="29">BANDHAN BANK</option>
							<option value="43">BANGIYA GURAMIN VIKAS BANK</option>
							<option value="7">BANK OF BARODA</option>
							<option value="26">BANK OF INDIA</option>
							<option value="21">BANK OF MAHARASHTRA</option>
							<option value="34">BARODA  UTTAR PRADESH GARMIN  BANK</option>
							<option value="24">BHART CO BANK</option>
							<option value="41">BIHAR GRAMIN  BANK</option>
							<option value="40">BIHAR GRAMIN BANK</option>
							<option value="9">CANARA BANK</option>
							<option value="35">CAPITAL SMALL FINANCE BANK</option>
							<option value="32">CENTRAL BANK OF INDIA</option>
							<option value="23">CORPORATION BANK</option>
							<option value="17">DENA BANK</option>
							<option value="38">DOMBIVLI NAGRI SAHAKARI BANK LTD</option>
							<option value="39">FEDERAL BANK</option>
							<option value="1">HDFC</option>
							<option value="2">ICICI BANK</option>
							<option value="3">IDBI BANK LIMITED</option>
							<option value="30">IDFC BANK</option>
							<option value="27">INDIAN BANK</option>
							<option value="13">INDIAN OVERSEAS BANK</option>
							<option value="22">INDUSIND BANK</option>
							<option value="19">KARNATKA BANK LTD.</option>
							<option value="18">KOTAK MAHINDRA BANK</option>
							<option value="44">MALDA  CENTRAL CO - OPERATIVE BANK</option>
							<option selected="selected" value="4">ORIENTAL BANK OF COMMERCE</option>
							<option value="6">PNB</option>
							<option value="36">PRATHAMA BANK</option>
							<option value="12">PUNJAB AND SIND BANK</option>
							<option value="37">RBL BANK</option>
							<option value="25">SARSWAT BANK</option>
							<option value="5">SBI</option>
							<option value="28">SYNDICATE BANK</option>
							<option value="20">UCO BANK</option>
							<option value="14">UNION BANK</option>
							<option value="15">UNION BANK BANK OF INDIA</option>
							<option value="31">UNITED BANK OF INDIA</option>
							<option value="42">VANACHAL GRAMIN BANK</option>
							<option value="33">VIJAY BANK</option>
							<option value="16">YES BANK</option-->
						</select>
					</div>

					<div class="col-sm-2">
						<label for="exampleInputEmail1">Branch Name</label>
					</div>
					<div class="col-sm-4">
						<input name="branch_name" type="text" class="form-control" value="<?php echo $branch_name; ?>" />
					</div>
				</div>
				</div>
				<div class="form-group">
				<div class="row">
					<div class="col-sm-2">
						<label for="exampleInputEmail1">IFSC </label>
					</div>
					<div class="col-sm-4">
						<input name="ifsc" type="text" class="form-control" value="<?php echo $ifsc; ?>" />
					</div>
					<div class="col-sm-2">
						<label for="exampleInputEmail1">Pan Card No  </label>
					</div>
					<div class="col-sm-4">
						<input name="pan_card_no" type="text" class="form-control" value="<?php echo $pan_card_no; ?>" />
					</div>
				</div>
				</div>

				<div class="form-group">
				<div class="row">
					<div class="col-sm-2">
						<label>Aadhar No </label>
					</div>
					<div class="col-sm-4">
						<input name="adhar_no" type="text" class="form-control" value="<?php echo $adhar_no; ?>" />
					</div>
				</div>
				</div>

				<div class="form-group">
				<div class="row">
					<div class="col-sm-2">
						<label for="exampleInputEmail1">Upload Pan </label>
					</div>
					<div class="col-sm-4">
						<input type="file" name="upload_pan" />
					</div>
					<div class="col-sm-2">
						<label for="exampleInputEmail1">Upload Aadhar Front </label>
					</div>
					<div class="col-sm-4">
						<input type="file" name="upload_aadhar_front" />
					</div>
				</div>
				</div>
				
				<div class="form-group">
				<div class="row">
					<div class="col-sm-2">
					</div>
					<div class="col-sm-4">
					<?php if(!empty($upload_pan)){ ?>
						<a href="../uploads/<?php echo $upload_pan;?>" download>Download Pan Card</a>
					<?php } ?>
					</div>
					<div class="col-sm-2">
					</div>
					<div class="col-sm-4">
						<?php if(!empty($upload_aadhar_front)){ ?>
						<a href="../uploads/<?php echo $upload_aadhar_front;?>" download>Download Aadhar Front</a>
					<?php } ?>
					</div>
				</div>
				</div>
				
				

				<div class="form-group">
				<div class="row">
					<div class="col-sm-2">
						<label>Upload Aadhar Back </label>
					</div>
					<div class="col-sm-4">
						<input type="file" name="upload_aadhar_back" />
					</div>
				</div>
				</div>
				
				<div class="form-group">
				<div class="row">
					<div class="col-sm-2">
					</div>
					<div class="col-sm-4">
					<?php if(!empty($upload_aadhar_back)){ ?>
						<a href="../uploads/<?php echo $upload_aadhar_back;?>" download>Download Aadhar Back</a>
					<?php } ?>
					</div>
				</div>
				</div>
				

				<div class="form-group">
				<div class="row">
					<div class="col-sm-2">
						<label for="exampleInputEmail1">Associate Image </label>
					</div>
					<div class="col-sm-4">
						<input type="file" name="associate_image" />
					</div>
				</div>
				</div>
				
				<div class="form-group">
				<div class="row">
					<div class="col-sm-2">
					</div>
					<div class="col-sm-4">
					<?php if(!empty($associate_image)){ ?>
						<a href="../uploads/<?php echo $associate_image;?>" download>Download Associate Image</a>
					<?php } ?>
					</div>
				</div>
				</div>
			<div class="row">
				<div class="col-md-12">
					<input type="hidden" name="snoEdit" value="<?php echo $insertedId; ?>">
					<input type="hidden" name="btnname" value="profileEdit">			<?php			$cvcxzZXC = "SELECT * FROM users WHERE sno = '$getid' AND type='Admin' AND parent_id!=''";			$zczx = mysqli_query($con, $cvcxzZXC);			if(mysqli_num_rows($zczx)){			?>
				<input value="Update" class="btn btn-warning" style="float: right;margin-bottom: 13px;margin-right: 20px;" disabled>			<?php }else{ ?>
				<input type="submit" name="editsbmtbtn" value="Update" class="btn btn-warning" style="float: right;margin-bottom: 13px;margin-right: 20px;">			<?php } ?>
				</div>
			</div>

        </div>
		</fieldset>
		</form>
        </div>
        </div>
        </div>
		
		<!-- Breadcrumbs-->
        <ol class="breadcrumb">
          <li class="breadcrumb-item active">Courier Details</li>
        </ol>

        <!-- Icon Cards-->
        <div class="row">
			<div class="col-lg-12">
			<div class="panel panel-default">
	<fieldset disabled>
		<div class="panel-body">
			<?php if(!empty($courier_type)){ ?>
			<div class="form-group">
				<div class="row">
					<div class="col-sm-2">
						<label>Company Name <span class="required">*</span></label>
					</div>
					<div class="col-sm-4">
						<input name="courier_company" type="text" class="form-control" value="<?php echo $courier_company; ?>" required />
					</div>
					<div class="col-sm-2">
						<label>Contact Number <span class="required">*</span></label>
					</div>
					<div class="col-sm-4">
					<span class="form-control"><?php echo $courier_mobile; ?></span>
					</div>
				</div>
			</div>
			<div class="form-group">
				<div class="row">
					<div class="col-sm-2">
						<label>Date <span class="required">*</span></label>
					</div>
					<div class="col-sm-4">
						<input name="shirt_delivered_date" type="text" class="form-control" value="<?php echo $shirt_delivered_date; ?>" required />
					</div>
					<div class="col-sm-2">
						<label>Courier Type <span class="required">*</span></label>
					</div>
					<div class="col-sm-4">
					<span class="form-control"><?php echo $courier_type; ?></span>
					</div>
				</div>
			</div>
			<?php }else{
				echo '<div class="form-group">
				<div class="row">
					<div class="col-sm-2">
						<label><b>Status</b></label>
					</div>
					<div class="col-sm-9">
					<span class="form-control"><span style="color:red;">N/F</span></span>
					</div></div></div>';
			}?>
			</div>
		</fieldset>
		</div>
		</div>
		</div>
		
		
        </div>

        <!-- DataTables Example -->
        <div class="card mb-3">
          
        </div>
   </div>
   
   
   
<script>
$(document).on('change', '.countrydiv', function(){
	var vl = $(this).val();
	$('.statediv').attr('dataval', vl);
	$.post("../response.php?tag=countrytostate",{"country":vl},function(d){
		$(".statediv").html(" ");
		$(".statediv").html("<option value=''>Select Option</option>");
		for (i in d) {
			$('<option value="' + d[i].state_name + '">'+ d[i].state_name +'</option>').appendTo(".statediv");
		}	
	});	
});
</script>

<script>
$(document).on('change', '.statediv', function(){
	var vl = $(this).val();
	var vl2 = $(this).attr('dataval');
	$.post("../response.php?tag=statetocity",{"country":vl2,"state":vl},function(d){
	$(".citydiv").html(" ");
	$(".citydiv").html("<option value=''>Select Option</option>");
	for (i in d) {
		$('<option value="' + d[i].city_name + '">'+ d[i].city_name +'</option>').appendTo(".citydiv");
	}
	});
});
</script>

<?php include("../footer2.php"); 
}else{
	header("Location: ../logout.php");
}
?>
