<?php
ob_start();
include("../db.php");
include("../header2.php");
if(!isset($_SESSION['sno'])){
    header("Location: ../login");
    exit(); 
}
if(isset($_SESSION['sno']) && !empty($_SESSION['sno'])){
$sessionid = $_SESSION['sno'];
$result1 = "SELECT sno,type FROM users WHERE sno = '$sessionid'";
$getusers = mysqli_query($con, $result1);
$rowusers = mysqli_fetch_assoc($getusers);
	$loggedid = mysqli_real_escape_string($con, $rowusers['sno']);
	$adminrole = mysqli_real_escape_string($con, $rowusers['type']);
}else{
	$loggedid = '';
	$adminrole = '';
}
if($adminrole == 'Admin'){
?>
<div id="wrapper">
    <?php include("../sidebar2.php"); ?>	
    <div id="content-wrapper">
      <div class="container-fluid">	  
<?php if(isset($_GET['msg'])){
	if(isset($_GET['msg']) == 'successfully'){
?>
	<div class='alertdiv'>
		<div class='alert alert-success' style="text-align:center;">
			<?php echo 'Successfully Saved'; ?>
		</div>
    </div>
<?php } } ?>	  
		<div class="card mb-3">
          <div class="card-header">
            <i class="fas fa-table"></i> Your Orders
            </div>
          <div class="card-body">           
			<?php
				$ccc = "SELECT * FROM cart_items WHERE user_id='$loggedid' AND cart_status='1'";
				$getccc = mysqli_query($con, $ccc);
				while ($row_asso1 = mysqli_fetch_assoc($getccc)) {
					$ssno = mysqli_real_escape_string($con, $row_asso1['sno']);								$product_id = mysqli_real_escape_string($con, $row_asso1['product_id']);				$ccc2 = "SELECT * FROM products WHERE id='$product_id' AND status='1'";				$getccc2 = mysqli_query($con, $ccc2);				$row_asso2 = mysqli_fetch_array($getccc2);				$product_title2 = mysqli_real_escape_string($con, $row_asso2['product_title']);				$product_sub_ttile2 = mysqli_real_escape_string($con, $row_asso2['product_sub_ttile']);				$product_img1 = mysqli_real_escape_string($con, $row_asso2['product_img1']);								$ccc2 = "SELECT * FROM products WHERE id='$product_id' AND status='1'";				$getccc2 = mysqli_query($con, $ccc2);				$row_asso2 = mysqli_fetch_array($getccc2);				$product_title2 = mysqli_real_escape_string($con, $row_asso2['product_title']);				$product_sub_ttile2 = mysqli_real_escape_string($con, $row_asso2['product_sub_ttile']);				$product_img1 = mysqli_real_escape_string($con, $row_asso2['product_img1']);								?>
						<?php } ?>
          </div>
        </div>
<?php include("../footer2.php"); 
}else{
	header("Location: ../logout.php");
}
?>
