<?php
ob_start();
include("../db.php");
include("../header2.php");

if(!isset($_SESSION['sno'])){
    header("Location: ../login");
    exit(); 
}

if(isset($_SESSION['sno']) && !empty($_SESSION['sno'])){
$sessionid = $_SESSION['sno'];
$result1 = "SELECT sno,type FROM users WHERE sno = '$sessionid'";
$getusers = mysqli_query($con, $result1);
$rowusers = mysqli_fetch_assoc($getusers);
	$loggedid = mysqli_real_escape_string($con, $rowusers['sno']);
	$adminrole = mysqli_real_escape_string($con, $rowusers['type']);
}else{
	$loggedid = '';
	$adminrole = '';
}

if($adminrole == 'Admin'){
?>
<div id="wrapper">
    <?php include("../sidebar2.php"); ?>
	
    <div id="content-wrapper">
      <div class="container-fluid">
	  
	 <?php if(isset($_GET['msg'])){
	if(isset($_GET['msg']) == 'successfully'){ 
?>
	<div class='alertdiv'>
		<div class='alert alert-success' style="text-align:center;">
			<?php echo 'Successfully Saved'; ?>
		</div>
    </div>     
<?php } } ?>

	<div class="col-sm-12">
		<form method="post" action="download_Export.php">
			<button name="alldownload" type="submit" class="btn btn-sm btn-success text-right mb-4">Download Excel Sheet</button>
		</form>
		</div>
	  
		<div class="card mb-3">
          <div class="card-header">
            <i class="fas fa-table"></i>
            Users Table</div>
          <div class="card-body">
            <div class="table-responsive">
              <table class="table table-bordered" id="dataTable11" width="100%" cellspacing="0">
                <thead>
                  <tr>
					<th>Username</th>
                    <th>Associate Name</th>
					<th>Parent Name</th>
                    <th>Introduser Id</th>
                    <th>Position</th>
                    <th>Shirt No.</th>
                    <th>Size</th>
                    <th>Created</th>
                    <!--th>Action</th-->
                  </tr>
                </thead>
                <tbody>
				<?php 					
				$ccc = "SELECT sno,associate_name,username,parent_id,sponser_id,position,size,lenght,created FROM users WHERE type='Admin' AND parent_id='$loggedid'";
				$getccc = mysqli_query($con, $ccc);
				while ($row_asso1 = mysqli_fetch_assoc($getccc)) {
					$ssno = mysqli_real_escape_string($con, $row_asso1['sno']);
					$associate_name1 = mysqli_real_escape_string($con, $row_asso1['associate_name']);
					$sponser_id1 = mysqli_real_escape_string($con, $row_asso1['sponser_id']);
					$parent_id1 = mysqli_real_escape_string($con, $row_asso1['parent_id']);
					$username1 = mysqli_real_escape_string($con, $row_asso1['username']);
					$position1 = mysqli_real_escape_string($con, $row_asso1['position']);
					$size1 = mysqli_real_escape_string($con, $row_asso1['size']);
					$lenght1 = mysqli_real_escape_string($con, $row_asso1['lenght']);
					$created1 = mysqli_real_escape_string($con, $row_asso1['created']);
					
					 $prnt_qry = mysqli_query($con,"SELECT username FROM users where sno='$sponser_id1'");
						 while ($row_prnt_qry = mysqli_fetch_assoc($prnt_qry)) {
						 $sponser_id_name1 = mysqli_real_escape_string($con, $row_prnt_qry['username']);
					}
					$prnt_qry1 = mysqli_query($con,"SELECT username FROM users where sno='$parent_id1'");
						 while ($row_prnt_qry1 = mysqli_fetch_assoc($prnt_qry1)) {
						 $parent_id_name1 = mysqli_real_escape_string($con, $row_prnt_qry1['username']);
					}
					?>
					<tr>
                    <td><?php echo $username1 ?></td>
                    <td><?php echo $associate_name1; ?></td>
                    <td><?php echo $parent_id_name1; ?></td>
                    <td><?php echo $sponser_id_name1; ?></td>
                    <td><?php echo $position1; ?></td>
                    <td><?php echo $lenght1; ?></td>
                    <td><?php echo $size1; ?></td>
                    <td><?php echo $created1; ?></td>
                    <!--td><a href="../associateag/edituser.php?snoid=<?php //echo base64_encode($snoid); ?>">Edit</a></td-->
                  </tr>
					<?php $cccz = "SELECT sno,associate_name,username,parent_id,sponser_id,position,size,lenght,created FROM users WHERE type='Admin' AND parent_id='$ssno'";
					// echo $cccz;
					$getccca = mysqli_query($con, $cccz);
					if(mysqli_num_rows($getccca)){
					while ($row_asso = mysqli_fetch_assoc($getccca)) {
					$snoid = mysqli_real_escape_string($con, $row_asso['sno']);
					$associate_name = mysqli_real_escape_string($con, $row_asso['associate_name']);
					$sponser_id = mysqli_real_escape_string($con, $row_asso['sponser_id']);
					$parent_id = mysqli_real_escape_string($con, $row_asso['parent_id']);
					$username = mysqli_real_escape_string($con, $row_asso['username']);
					$position = mysqli_real_escape_string($con, $row_asso['position']);
					$size = mysqli_real_escape_string($con, $row_asso['size']);
					$lenght = mysqli_real_escape_string($con, $row_asso['lenght']);
					$created = mysqli_real_escape_string($con, $row_asso['created']);
					
					$prnt_qry = mysqli_query($con,"SELECT username FROM users where sno='$sponser_id'");
						 while ($row_prnt_qry = mysqli_fetch_assoc($prnt_qry)) {
						 $sponser_id_name = mysqli_real_escape_string($con, $row_prnt_qry['username']);
					}
					$prnt_qry1 = mysqli_query($con,"SELECT username FROM users where sno='$parent_id'");
						 while ($row_prnt_qry1 = mysqli_fetch_assoc($prnt_qry1)) {
						 $parent_id_name = mysqli_real_escape_string($con, $row_prnt_qry1['username']);
					}
				
				?>
                  <tr>
                    <td><?php echo $username; ?></td>
                    <td><?php echo $associate_name; ?></td>
                    <td><?php echo $parent_id_name; ?></td>
                    <td><?php echo $sponser_id_name; ?></td>
                    <td><?php echo $position; ?></td>
                    <td><?php echo $lenght; ?></td>
                    <td><?php echo $size; ?></td>
                    <td><?php echo $created; ?></td>
                    <!--td><a href="../associateag/edituser.php?snoid=<?php //echo base64_encode($snoid); ?>">Edit</a></td-->
                  </tr>
			
				<?php
		// Step 3
				$cccz_3 = "SELECT sno,associate_name,username,parent_id,sponser_id,position,size,lenght,created FROM users WHERE type='Admin' AND parent_id='$snoid'";
					
				$getccca_3 = mysqli_query($con, $cccz_3);
				if(mysqli_num_rows($getccca_3)){
				while ($row_asso_3 = mysqli_fetch_assoc($getccca_3)) {
				$snoid_3 = mysqli_real_escape_string($con, $row_asso_3['sno']);
				$associate_name_3 = mysqli_real_escape_string($con, $row_asso_3['associate_name']);
				$sponser_id_3 = mysqli_real_escape_string($con, $row_asso_3['sponser_id']);
				$parent_id_3 = mysqli_real_escape_string($con, $row_asso_3['parent_id']);
				$username_3 = mysqli_real_escape_string($con, $row_asso_3['username']);
				$position_3 = mysqli_real_escape_string($con, $row_asso_3['position']);
				$size_3 = mysqli_real_escape_string($con, $row_asso_3['size']);
				$lenght_3 = mysqli_real_escape_string($con, $row_asso_3['lenght']);
				$created_3 = mysqli_real_escape_string($con, $row_asso_3['created']);

				$prnt_qry_3 = mysqli_query($con,"SELECT username FROM users where sno='$sponser_id_3'");
					 while ($row_prnt_qry_3 = mysqli_fetch_assoc($prnt_qry_3)) {
					 $sponser_id_name_3 = mysqli_real_escape_string($con, $row_prnt_qry_3['username']);
				}
				$prnt_qry_3 = mysqli_query($con,"SELECT username FROM users where sno='$parent_id_3'");
					 while ($row_prnt_qry_3 = mysqli_fetch_assoc($prnt_qry_3)) {
					 $parent_id_name_3 = mysqli_real_escape_string($con, $row_prnt_qry_3['username']);
				}
				?>
				
				<tr>
                    <td><?php echo $username_3; ?></td>
                    <td><?php echo $associate_name_3; ?></td>
                    <td><?php echo $parent_id_name_3; ?></td>
                    <td><?php echo $sponser_id_name_3; ?></td>
                    <td><?php echo $position_3; ?></td>
                    <td><?php echo $lenght_3; ?></td>
                    <td><?php echo $size_3; ?></td>
                    <td><?php echo $created_3; ?></td>
                    <!--td><a href="../associateag/edituser.php?snoid=<?php //echo base64_encode($snoid); ?>">Edit</a></td-->
                </tr>
				
				<?php
				//// Step4 ////

				$cccz_4 = "SELECT sno,associate_name,username,parent_id,sponser_id,position,size,lenght,created FROM users WHERE type='Admin' AND parent_id='$snoid_3'";
									
				$getccca_4 = mysqli_query($con, $cccz_4);
				if(mysqli_num_rows($getccca_4)){
				while ($row_asso_4 = mysqli_fetch_assoc($getccca_4)) {
				$snoid_4 = mysqli_real_escape_string($con, $row_asso_4['sno']);
				$associate_name_4 = mysqli_real_escape_string($con, $row_asso_4['associate_name']);
				$sponser_id_4 = mysqli_real_escape_string($con, $row_asso_4['sponser_id']);
				$parent_id_4 = mysqli_real_escape_string($con, $row_asso_4['parent_id']);
				$username_4 = mysqli_real_escape_string($con, $row_asso_4['username']);
				$position_4 = mysqli_real_escape_string($con, $row_asso_4['position']);
				$size_4 = mysqli_real_escape_string($con, $row_asso_4['size']);
				$lenght_4 = mysqli_real_escape_string($con, $row_asso_4['lenght']);
				$created_4 = mysqli_real_escape_string($con, $row_asso_4['created']);

				$prnt_qry_4 = mysqli_query($con,"SELECT username FROM users where sno='$sponser_id_4'");
					 while ($row_prnt_qry_4 = mysqli_fetch_assoc($prnt_qry_4)) {
					 $sponser_id_name_4 = mysqli_real_escape_string($con, $row_prnt_qry_4['username']);
				}
				$prnt_qry_4 = mysqli_query($con,"SELECT username FROM users where sno='$parent_id_4'");
					 while ($row_prnt_qry_4 = mysqli_fetch_assoc($prnt_qry_4)) {
					 $parent_id_name_4 = mysqli_real_escape_string($con, $row_prnt_qry_4['username']);
				}
				?>
				<tr>
                    <td><?php echo $username_4; ?></td>
                    <td><?php echo $associate_name_4; ?></td>
                    <td><?php echo $parent_id_name_4; ?></td>
                    <td><?php echo $sponser_id_name_4; ?></td>
                    <td><?php echo $position_4; ?></td>
                    <td><?php echo $lenght_4; ?></td>
                    <td><?php echo $size_4; ?></td>
                    <td><?php echo $created_4; ?></td>
                    <!--td><a href="../associateag/edituser.php?snoid=<?php //echo base64_encode($snoid); ?>">Edit</a></td-->
                </tr>
				
				<?php 
				$cccz_5 = "SELECT sno,associate_name,username,parent_id,sponser_id,position,size,lenght,created FROM users WHERE type='Admin' AND parent_id='$snoid_4'";
					
				$getccca_5 = mysqli_query($con, $cccz_5);
				if(mysqli_num_rows($getccca_5)){
				while ($row_asso_5 = mysqli_fetch_assoc($getccca_5)) {
				$snoid_5 = mysqli_real_escape_string($con, $row_asso_5['sno']);
				$associate_name_5 = mysqli_real_escape_string($con, $row_asso_5['associate_name']);
				$sponser_id_5 = mysqli_real_escape_string($con, $row_asso_5['sponser_id']);
				$parent_id_5 = mysqli_real_escape_string($con, $row_asso_5['parent_id']);
				$username_5 = mysqli_real_escape_string($con, $row_asso_5['username']);
				$position_5 = mysqli_real_escape_string($con, $row_asso_5['position']);
				$size_5 = mysqli_real_escape_string($con, $row_asso_5['size']);
				$lenght_5 = mysqli_real_escape_string($con, $row_asso_5['lenght']);
				$created_5 = mysqli_real_escape_string($con, $row_asso_5['created']);

				$prnt_qry_5 = mysqli_query($con,"SELECT username FROM users where sno='$sponser_id_5'");
					 while ($row_prnt_qry_5 = mysqli_fetch_assoc($prnt_qry_5)) {
					 $sponser_id_name_5 = mysqli_real_escape_string($con, $row_prnt_qry_5['username']);
				}
				$prnt_qry_5 = mysqli_query($con,"SELECT username FROM users where sno='$parent_id_5'");
					 while ($row_prnt_qry_5 = mysqli_fetch_assoc($prnt_qry_5)) {
					 $parent_id_name_5 = mysqli_real_escape_string($con, $row_prnt_qry_5['username']);
				}
				?>
				<tr>
                    <td><?php echo $username_5; ?></td>
                    <td><?php echo $associate_name_5; ?></td>
                    <td><?php echo $parent_id_name_5; ?></td>
                    <td><?php echo $sponser_id_name_5; ?></td>
                    <td><?php echo $position_5; ?></td>
                    <td><?php echo $lenght_5; ?></td>
                    <td><?php echo $size_5; ?></td>
                    <td><?php echo $created_5; ?></td>
                    <!--td><a href="../associateag/edituser.php?snoid=<?php //echo base64_encode($snoid); ?>">Edit</a></td-->
                </tr>
				
				<?php
				$cccz_6 = "SELECT sno,associate_name,username,parent_id,sponser_id,position,size,lenght,created FROM users WHERE type='Admin' AND parent_id='$snoid_5'";
					
				$getccca_6 = mysqli_query($con, $cccz_6);
				if(mysqli_num_rows($getccca_6)){
				while ($row_asso_6 = mysqli_fetch_assoc($getccca_6)) {
				$snoid_6 = mysqli_real_escape_string($con, $row_asso_6['sno']);
				$associate_name_6 = mysqli_real_escape_string($con, $row_asso_6['associate_name']);
				$sponser_id_6 = mysqli_real_escape_string($con, $row_asso_6['sponser_id']);
				$parent_id_6 = mysqli_real_escape_string($con, $row_asso_6['parent_id']);
				$username_6 = mysqli_real_escape_string($con, $row_asso_6['username']);
				$position_6 = mysqli_real_escape_string($con, $row_asso_6['position']);
				$size_6 = mysqli_real_escape_string($con, $row_asso_6['size']);
				$lenght_6 = mysqli_real_escape_string($con, $row_asso_6['lenght']);
				$created_6 = mysqli_real_escape_string($con, $row_asso_6['created']);

				$prnt_qry_6 = mysqli_query($con,"SELECT username FROM users where sno='$sponser_id_6'");
					 while ($row_prnt_qry_6 = mysqli_fetch_assoc($prnt_qry_6)) {
					 $sponser_id_name_6 = mysqli_real_escape_string($con, $row_prnt_qry_6['username']);
				}
				$prnt_qry_6 = mysqli_query($con,"SELECT username FROM users where sno='$parent_id_6'");
					 while ($row_prnt_qry_6 = mysqli_fetch_assoc($prnt_qry_6)) {
					 $parent_id_name_6 = mysqli_real_escape_string($con, $row_prnt_qry_6['username']);
				}
				?>
				<tr>
                    <td><?php echo $username_6; ?></td>
                    <td><?php echo $associate_name_6; ?></td>
                    <td><?php echo $parent_id_name_6; ?></td>
                    <td><?php echo $sponser_id_name_6; ?></td>
                    <td><?php echo $position_6; ?></td>
                    <td><?php echo $lenght_6; ?></td>
                    <td><?php echo $size_6; ?></td>
                    <td><?php echo $created_6; ?></td>
                    <!--td><a href="../associateag/edituser.php?snoid=<?php //echo base64_encode($snoid); ?>">Edit</a></td-->
                </tr>
				
			<?php 
			//// Step7 ////

			$cccz_7 = "SELECT sno,associate_name,username,parent_id,sponser_id,position,size,lenght,created FROM users WHERE type='Admin' AND parent_id='$snoid_6'";
								
			$getccca_7 = mysqli_query($con, $cccz_7);
			if(mysqli_num_rows($getccca_7)){
			while ($row_asso_7 = mysqli_fetch_assoc($getccca_7)) {
			$snoid_7 = mysqli_real_escape_string($con, $row_asso_7['sno']);
			$associate_name_7 = mysqli_real_escape_string($con, $row_asso_7['associate_name']);
			$sponser_id_7 = mysqli_real_escape_string($con, $row_asso_7['sponser_id']);
			$parent_id_7 = mysqli_real_escape_string($con, $row_asso_7['parent_id']);
			$username_7 = mysqli_real_escape_string($con, $row_asso_7['username']);
			$position_7 = mysqli_real_escape_string($con, $row_asso_7['position']);
			$size_7 = mysqli_real_escape_string($con, $row_asso_7['size']);
			$lenght_7 = mysqli_real_escape_string($con, $row_asso_7['lenght']);
			$created_7 = mysqli_real_escape_string($con, $row_asso_7['created']);

			$prnt_qry_7 = mysqli_query($con,"SELECT username FROM users where sno='$sponser_id_7'");
				 while ($row_prnt_qry_7 = mysqli_fetch_assoc($prnt_qry_7)) {
				 $sponser_id_name_7 = mysqli_real_escape_string($con, $row_prnt_qry_7['username']);
			}
			$prnt_qry_7 = mysqli_query($con,"SELECT username FROM users where sno='$parent_id_7'");
				 while ($row_prnt_qry_7 = mysqli_fetch_assoc($prnt_qry_7)) {
				 $parent_id_name_7 = mysqli_real_escape_string($con, $row_prnt_qry_7['username']);
			}
			?>
			<tr>
				<td><?php echo $username_7; ?></td>
				<td><?php echo $associate_name_7; ?></td>
				<td><?php echo $parent_id_name_7; ?></td>
				<td><?php echo $sponser_id_name_7; ?></td>
				<td><?php echo $position_7; ?></td>
				<td><?php echo $lenght_7; ?></td>
				<td><?php echo $size_7; ?></td>
				<td><?php echo $created_7; ?></td>
				<!--td><a href="../associateag/edituser.php?snoid=<?php //echo base64_encode($snoid); ?>">Edit</a></td-->
			</tr>
			
			<?php
			//// Step8 ////

			$cccz_8 = "SELECT sno,associate_name,username,parent_id,sponser_id,position,size,lenght,created FROM users WHERE type='Admin' AND parent_id='$snoid_7'";
								
			$getccca_8 = mysqli_query($con, $cccz_8);
			if(mysqli_num_rows($getccca_8)){
			while ($row_asso_8 = mysqli_fetch_assoc($getccca_8)) {
			$snoid_8 = mysqli_real_escape_string($con, $row_asso_8['sno']);
			$associate_name_8 = mysqli_real_escape_string($con, $row_asso_8['associate_name']);
			$sponser_id_8 = mysqli_real_escape_string($con, $row_asso_8['sponser_id']);
			$parent_id_8 = mysqli_real_escape_string($con, $row_asso_8['parent_id']);
			$username_8 = mysqli_real_escape_string($con, $row_asso_8['username']);
			$position_8 = mysqli_real_escape_string($con, $row_asso_8['position']);
			$size_8 = mysqli_real_escape_string($con, $row_asso_8['size']);
			$lenght_8 = mysqli_real_escape_string($con, $row_asso_8['lenght']);
			$created_8 = mysqli_real_escape_string($con, $row_asso_8['created']);

			$prnt_qry_8 = mysqli_query($con,"SELECT username FROM users where sno='$sponser_id_8'");
				 while ($row_prnt_qry_8 = mysqli_fetch_assoc($prnt_qry_8)) {
				 $sponser_id_name_8 = mysqli_real_escape_string($con, $row_prnt_qry_8['username']);
			}
			$prnt_qry_8 = mysqli_query($con,"SELECT username FROM users where sno='$parent_id_8'");
				 while ($row_prnt_qry_8 = mysqli_fetch_assoc($prnt_qry_8)) {
				 $parent_id_name_8 = mysqli_real_escape_string($con, $row_prnt_qry_8['username']);
			}
			?>
			<tr>
				<td><?php echo $username_8; ?></td>
				<td><?php echo $associate_name_8; ?></td>
				<td><?php echo $parent_id_name_8; ?></td>
				<td><?php echo $sponser_id_name_8; ?></td>
				<td><?php echo $position_8; ?></td>
				<td><?php echo $lenght_8; ?></td>
				<td><?php echo $size_8; ?></td>
				<td><?php echo $created_8; ?></td>
				<!--td><a href="../associateag/edituser.php?snoid=<?php //echo base64_encode($snoid); ?>">Edit</a></td-->
			</tr>
			
			<?php
			//// Step9 ////

			$cccz_9 = "SELECT sno,associate_name,username,parent_id,sponser_id,position,size,lenght,created FROM users WHERE type='Admin' AND parent_id='$snoid_8'";
								
			$getccca_9 = mysqli_query($con, $cccz_9);
			if(mysqli_num_rows($getccca_9)){
			while ($row_asso_9 = mysqli_fetch_assoc($getccca_9)) {
			$snoid_9 = mysqli_real_escape_string($con, $row_asso_9['sno']);
			$associate_name_9 = mysqli_real_escape_string($con, $row_asso_9['associate_name']);
			$sponser_id_9 = mysqli_real_escape_string($con, $row_asso_9['sponser_id']);
			$parent_id_9 = mysqli_real_escape_string($con, $row_asso_9['parent_id']);
			$username_9 = mysqli_real_escape_string($con, $row_asso_9['username']);
			$position_9 = mysqli_real_escape_string($con, $row_asso_9['position']);
			$size_9 = mysqli_real_escape_string($con, $row_asso_9['size']);
			$lenght_9 = mysqli_real_escape_string($con, $row_asso_9['lenght']);
			$created_9 = mysqli_real_escape_string($con, $row_asso_9['created']);

			$prnt_qry_9 = mysqli_query($con,"SELECT username FROM users where sno='$sponser_id_9'");
				 while ($row_prnt_qry_9 = mysqli_fetch_assoc($prnt_qry_9)) {
				 $sponser_id_name_9 = mysqli_real_escape_string($con, $row_prnt_qry_9['username']);
			}
			$prnt_qry_9 = mysqli_query($con,"SELECT username FROM users where sno='$parent_id_9'");
				 while ($row_prnt_qry_9 = mysqli_fetch_assoc($prnt_qry_9)) {
				 $parent_id_name_9 = mysqli_real_escape_string($con, $row_prnt_qry_9['username']);
			}
			?>
			<tr>
				<td><?php echo $username_9; ?></td>
				<td><?php echo $associate_name_9; ?></td>
				<td><?php echo $parent_id_name_9; ?></td>
				<td><?php echo $sponser_id_name_9; ?></td>
				<td><?php echo $position_9; ?></td>
				<td><?php echo $lenght_9; ?></td>
				<td><?php echo $size_9; ?></td>
				<td><?php echo $created_9; ?></td>
				<!--td><a href="../associateag/edituser.php?snoid=<?php //echo base64_encode($snoid); ?>">Edit</a></td-->
			</tr>
			
			<?php
			//// Step10 ////

			$cccz_10 = "SELECT sno,associate_name,username,parent_id,sponser_id,position,size,lenght,created FROM users WHERE type='Admin' AND parent_id='$snoid_9'";
								
			$getccca_10 = mysqli_query($con, $cccz_10);
			if(mysqli_num_rows($getccca_10)){
			while ($row_asso_10 = mysqli_fetch_assoc($getccca_10)) {
			$snoid_10 = mysqli_real_escape_string($con, $row_asso_10['sno']);
			$associate_name_10 = mysqli_real_escape_string($con, $row_asso_10['associate_name']);
			$sponser_id_10 = mysqli_real_escape_string($con, $row_asso_10['sponser_id']);
			$parent_id_10 = mysqli_real_escape_string($con, $row_asso_10['parent_id']);
			$username_10 = mysqli_real_escape_string($con, $row_asso_10['username']);
			$position_10 = mysqli_real_escape_string($con, $row_asso_10['position']);
			$size_10 = mysqli_real_escape_string($con, $row_asso_10['size']);
			$lenght_10 = mysqli_real_escape_string($con, $row_asso_10['lenght']);
			$created_10 = mysqli_real_escape_string($con, $row_asso_10['created']);

			$prnt_qry_10 = mysqli_query($con,"SELECT username FROM users where sno='$sponser_id_10'");
				 while ($row_prnt_qry_10 = mysqli_fetch_assoc($prnt_qry_10)) {
				 $sponser_id_name_10 = mysqli_real_escape_string($con, $row_prnt_qry_10['username']);
			}
			$prnt_qry_10 = mysqli_query($con,"SELECT username FROM users where sno='$parent_id_10'");
				 while ($row_prnt_qry_10 = mysqli_fetch_assoc($prnt_qry_10)) {
				 $parent_id_name_10 = mysqli_real_escape_string($con, $row_prnt_qry_10['username']);
			}
			?>
			<tr>
				<td><?php echo $username_10; ?></td>
				<td><?php echo $associate_name_10; ?></td>
				<td><?php echo $parent_id_name_10; ?></td>
				<td><?php echo $sponser_id_name_10; ?></td>
				<td><?php echo $position_10; ?></td>
				<td><?php echo $lenght_10; ?></td>
				<td><?php echo $size_10; ?></td>
				<td><?php echo $created_10; ?></td>
				<!--td><a href="../associateag/edituser.php?snoid=<?php //echo base64_encode($snoid); ?>">Edit</a></td-->
			</tr>
			
		<?php
			//// Step11 ////

			$cccz_11 = "SELECT sno,associate_name,username,parent_id,sponser_id,position,size,lenght,created FROM users WHERE type='Admin' AND parent_id='$snoid_10'";
								
			$getccca_11 = mysqli_query($con, $cccz_11);
			if(mysqli_num_rows($getccca_11)){
			while ($row_asso_11 = mysqli_fetch_assoc($getccca_11)) {
			$snoid_11 = mysqli_real_escape_string($con, $row_asso_11['sno']);
			$associate_name_11 = mysqli_real_escape_string($con, $row_asso_11['associate_name']);
			$sponser_id_11 = mysqli_real_escape_string($con, $row_asso_11['sponser_id']);
			$parent_id_11 = mysqli_real_escape_string($con, $row_asso_11['parent_id']);
			$username_11 = mysqli_real_escape_string($con, $row_asso_11['username']);
			$position_11 = mysqli_real_escape_string($con, $row_asso_11['position']);
			$size_11 = mysqli_real_escape_string($con, $row_asso_11['size']);
			$lenght_11 = mysqli_real_escape_string($con, $row_asso_11['lenght']);
			$created_11 = mysqli_real_escape_string($con, $row_asso_11['created']);

			$prnt_qry_11 = mysqli_query($con,"SELECT username FROM users where sno='$sponser_id_11'");
				 while ($row_prnt_qry_11 = mysqli_fetch_assoc($prnt_qry_11)) {
				 $sponser_id_name_11 = mysqli_real_escape_string($con, $row_prnt_qry_11['username']);
			}
			$prnt_qry_11 = mysqli_query($con,"SELECT username FROM users where sno='$parent_id_11'");
				 while ($row_prnt_qry_11 = mysqli_fetch_assoc($prnt_qry_11)) {
				 $parent_id_name_11 = mysqli_real_escape_string($con, $row_prnt_qry_11['username']);
			}
			?>
			<tr>
				<td><?php echo $username_11; ?></td>
				<td><?php echo $associate_name_11; ?></td>
				<td><?php echo $parent_id_name_11; ?></td>
				<td><?php echo $sponser_id_name_11; ?></td>
				<td><?php echo $position_11; ?></td>
				<td><?php echo $lenght_11; ?></td>
				<td><?php echo $size_11; ?></td>
				<td><?php echo $created_11; ?></td>
				<!--td><a href="../associateag/edituser.php?snoid=<?php //echo base64_encode($snoid); ?>">Edit</a></td-->
			</tr>
			
			<?php
			//// Step11 ////

			$cccz_12 = "SELECT sno,associate_name,username,parent_id,sponser_id,position,size,lenght,created FROM users WHERE type='Admin' AND parent_id='$snoid_11'";
								
			$getccca_12 = mysqli_query($con, $cccz_12);
			if(mysqli_num_rows($getccca_12)){
			while ($row_asso_12 = mysqli_fetch_assoc($getccca_12)) {
			$snoid_12 = mysqli_real_escape_string($con, $row_asso_12['sno']);
			$associate_name_12 = mysqli_real_escape_string($con, $row_asso_12['associate_name']);
			$sponser_id_12 = mysqli_real_escape_string($con, $row_asso_12['sponser_id']);
			$parent_id_12 = mysqli_real_escape_string($con, $row_asso_12['parent_id']);
			$username_12 = mysqli_real_escape_string($con, $row_asso_12['username']);
			$position_12 = mysqli_real_escape_string($con, $row_asso_12['position']);
			$size_12 = mysqli_real_escape_string($con, $row_asso_12['size']);
			$lenght_12 = mysqli_real_escape_string($con, $row_asso_12['lenght']);
			$created_12 = mysqli_real_escape_string($con, $row_asso_12['created']);

			$prnt_qry_12 = mysqli_query($con,"SELECT username FROM users where sno='$sponser_id_12'");
				 while ($row_prnt_qry_12 = mysqli_fetch_assoc($prnt_qry_12)) {
				 $sponser_id_name_12 = mysqli_real_escape_string($con, $row_prnt_qry_12['username']);
			}
			$prnt_qry_12 = mysqli_query($con,"SELECT username FROM users where sno='$parent_id_12'");
				 while ($row_prnt_qry_12 = mysqli_fetch_assoc($prnt_qry_12)) {
				 $parent_id_name_12 = mysqli_real_escape_string($con, $row_prnt_qry_12['username']);
			}
			?>
			<tr>
				<td><?php echo $username_12; ?></td>
				<td><?php echo $associate_name_12; ?></td>
				<td><?php echo $parent_id_name_12; ?></td>
				<td><?php echo $sponser_id_name_12; ?></td>
				<td><?php echo $position_12; ?></td>
				<td><?php echo $lenght_12; ?></td>
				<td><?php echo $size_12; ?></td>
				<td><?php echo $created_12; ?></td>
				<!--td><a href="../associateag/edituser.php?snoid=<?php //echo base64_encode($snoid); ?>">Edit</a></td-->
			</tr>
				  
<?php } } } } } } } } } } } } } } } } } } } } } } }  ?>
                </tbody>
              </table>
            </div>
          </div>
        </div>	

<?php include("../footer2.php"); 
}else{
	header("Location: ../logout.php");
}
?>
