<?php
session_start();
include("../db.php");
date_default_timezone_set("Asia/Kolkata");
$created_datetime = date('Y-m-d H:i:s');
if(isset($_POST["emailForm"])){
	$emailForm = $_POST['emailForm'];
	$pwdform = $_POST['pwdform'];
	$login = mysqli_query($con,"SELECT * FROM users WHERE (username = '" . $emailForm . "') and (password = '" . md5(sha1($pwdform)) . "') and type='Admin'");
    if (mysqli_num_rows($login) == 1) {		
			$row = mysqli_fetch_array($login);
            $_SESSION['sno'] = $row['sno'];            $_SESSION['username'] = $row['username'];
			$otp_post = $row['otp'];
			$status = $row['status'];			
			if(empty($otp_post) && !empty($status)){
			$sno12 = $row['sno'];
			$type = $row['type'];
			$username = $row['username'];
			$associate_name = $row['associate_name'];
			$mobile = $row['mobile'];
			mysqli_query($con, "INSERT INTO `login_time` (`user_id`, `username`, `associate_name`, `mobile`, `created_datetime`) VALUES ('$sno12', '$username', '$associate_name', '$mobile', '$created_datetime')");			if(!empty($_SESSION["cart_item"])) {				foreach($_SESSION["cart_item"] as $k => $v) {					$product_id = $v['pro_id'];					$size = $v['size'];					$quantity = $v['pro_quantity'];											$Chest_Width = $v['pro_cw'];											$Waist = $v['pro_w'];											$Body_Length = $v['pro_bl'];											$Sleeve_Length = $v['pro_sl'];						$created_date = date('Y-m-d');						$add_to_cart ="INSERT INTO `cart_items`(`user_id`, `product_id`, size, `quantity`, pro_cw, pro_w, pro_bl, pro_sl, `created_date`,`cart_status`) VALUES ('$sno12','$product_id', '$size', '$quantity','$Chest_Width', '$Waist', '$Body_Length', '$Sleeve_Length', '$created_date','0')";												$get_pro_res = mysqli_query($con, $add_to_cart);						if($get_pro_res=='true'){							unset($_SESSION["cart_item"]);							   						}				}			}						$check_exit ="Select sno from cart_items where user_id='$sno12'";			 $check_exit_res = mysqli_query($con, $check_exit);			 $check_data=mysqli_num_rows($check_exit_res);			 if($check_data > 0){				 echo "chkout";			 } else {				if($type == 'Admin'){					echo "1234433";				}			 }

			
			}else{
				echo 'checkotp';
			}
			// if($type == 'Admin'){
				// echo "1234433";
			// }
    } else {
		print "<p class='Error'>Your username and password is wrong.</p>";
	}
} 
?>