-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 02, 2019 at 04:43 PM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 5.6.39

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `malsc3a1_makealife_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `cart_items`
--

CREATE TABLE `cart_items` (
  `sno` int(11) NOT NULL,
  `user_id` varchar(11) NOT NULL DEFAULT '',
  `product_id` varchar(11) NOT NULL DEFAULT '',
  `quantity` varchar(15) NOT NULL DEFAULT '',
  `size` varchar(20) NOT NULL DEFAULT '',
  `pro_cw` varchar(50) NOT NULL DEFAULT '',
  `pro_w` varchar(50) NOT NULL DEFAULT '',
  `pro_bl` varchar(50) NOT NULL DEFAULT '',
  `pro_sl` varchar(50) NOT NULL DEFAULT '',
  `created_date` varchar(30) NOT NULL DEFAULT '',
  `cart_status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '0="cart",1="purchase"'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cart_items`
--

INSERT INTO `cart_items` (`sno`, `user_id`, `product_id`, `quantity`, `size`, `pro_cw`, `pro_w`, `pro_bl`, `pro_sl`, `created_date`, `cart_status`) VALUES
(16, '233', '2', '2', '', 'x', 'z', 'x', 'c', '2019-10-28', 1),
(17, '233', '3', '1', '', '1', '1', '1', '1', '2019-10-28', 1),
(18, '233', '2', '3', '', '12', '21', '31', '11', '2019-10-29', 1),
(19, '233', '2', '1', '', '', '', '', '', '2019-10-30', 0),
(20, '238', '1', '1', '', 'x', 'z', 'x', 'c', '2019-10-31', 1),
(21, '238', '7', '2', 'XL', '1', '2', '3', '4', '2019-11-01', 1);

-- --------------------------------------------------------

--
-- Table structure for table `contactus`
--

CREATE TABLE `contactus` (
  `sno` int(11) NOT NULL,
  `your_name` varchar(255) NOT NULL DEFAULT '',
  `your_email` varchar(200) NOT NULL DEFAULT '',
  `your_phone` varchar(80) NOT NULL DEFAULT '',
  `your_message` varchar(500) NOT NULL DEFAULT '',
  `created` varchar(30) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `country_state_city`
--

CREATE TABLE `country_state_city` (
  `sno` int(11) NOT NULL,
  `country_name` varchar(100) NOT NULL DEFAULT '',
  `state_name` varchar(100) NOT NULL DEFAULT '',
  `city_name` varchar(100) NOT NULL DEFAULT '',
  `status` varchar(11) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `country_state_city`
--

INSERT INTO `country_state_city` (`sno`, `country_name`, `state_name`, `city_name`, `status`) VALUES
(1, 'INDIA', 'BIHAR', '', '1'),
(2, 'INDIA', 'CHATISHGAR', '', '1'),
(3, 'INDIA', 'HARIYANA', '', '1'),
(4, 'INDIA', 'JHARKHAND', '', '1'),
(5, 'INDIA', 'M.P.', '', '1'),
(6, 'INDIA', 'MAHARASHTRA', '', '1'),
(7, 'INDIA', 'ORISSA', '', '1'),
(8, 'INDIA', 'U.P', 'CHITRAKOOT DHAM', '1'),
(9, 'INDIA', 'WEST BENGAL', '', '1'),
(10, 'INDIAN', 'BIHAR', '', '1'),
(11, 'INDIAN', 'GUJARAT', '', '1'),
(12, 'INDIAN', 'JHARKHAND', '', '1'),
(13, 'INDIAN', 'KUSHINAGAR', '', '1'),
(14, 'INDIAN', 'MADHYA PRADESH', '', '1'),
(15, 'INDIAN', 'MAHARASHHTRA', '', '1'),
(16, 'INDIAN', 'PUNJAB', '', '1'),
(17, 'INDIAN', 'RAJASTHAN', '', '1'),
(18, 'INDIAN', 'UTTARAKHAND', '', '1'),
(19, 'INDIAN', 'WEST BANGAL', '', '1'),
(21, 'INDIA', 'U.P', 'FATEHPIR', '1'),
(22, 'INDIA', 'U.P', 'JHANSI', '1'),
(23, 'INDIA', 'U.P', 'KANPUR', '1'),
(24, 'INDIA', 'U.P', 'PRAYAGRAJ', '1'),
(25, 'INDIA', 'U.P', 'RAIBAREILY', '1'),
(26, 'INDIAN', 'BIHAR', 'ARARIA', '1'),
(27, 'INDIAN', 'BIHAR', 'BHAGALPUR', '1'),
(28, 'INDIAN', 'BIHAR', 'JAMUI', '1'),
(29, 'INDIAN', 'BIHAR', 'JHAJA', '1'),
(30, 'INDIAN', 'BIHAR', 'PATNA', '1'),
(31, 'INDIAN', 'SIWAN', 'JHAJA', '1'),
(32, 'INDIAN', 'BIHAR', 'VAISHALI', '1');

-- --------------------------------------------------------

--
-- Table structure for table `delivery_details`
--

CREATE TABLE `delivery_details` (
  `sno` int(11) NOT NULL,
  `user_id` varchar(11) NOT NULL DEFAULT '',
  `cart_id` varchar(11) NOT NULL DEFAULT '',
  `quantity` varchar(20) NOT NULL DEFAULT '',
  `total_amount` varchar(40) NOT NULL DEFAULT '',
  `full_name` varchar(100) NOT NULL DEFAULT '',
  `email` varchar(100) NOT NULL DEFAULT '',
  `mobile` varchar(30) NOT NULL DEFAULT '',
  `address` varchar(150) NOT NULL DEFAULT '',
  `pin_code` varchar(20) NOT NULL DEFAULT '',
  `city` varchar(80) NOT NULL DEFAULT '',
  `order_place` varchar(400) NOT NULL DEFAULT '',
  `created_at` varchar(30) NOT NULL DEFAULT '',
  `payment_status` varchar(40) NOT NULL DEFAULT '',
  `payment_request_id` varchar(100) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `delivery_details`
--

INSERT INTO `delivery_details` (`sno`, `user_id`, `cart_id`, `quantity`, `total_amount`, `full_name`, `email`, `mobile`, `address`, `pin_code`, `city`, `order_place`, `created_at`, `payment_status`, `payment_request_id`) VALUES
(5, '233', '16,17,18', '2,1,3', '1', 'sdf', 'sanjiv28890@gmail.com', '9115656334', 'chd', '160101', 'chd', 'Office', '2019-10-30 12:25:13', 'Pending', 'order_DZzaOxBKy34H9r'),
(6, '233', '16,17,18', '2,1,3', '1', 'sdf', 'sanjiv28890@gmail.com', '9115656334', 'chd', '160101', 'chd', 'Office', '2019-10-30 12:25:43', 'Complete', 'order_DZzavsSEn10lkK'),
(7, '238', '20,21', '1,2', '2102', 'sm', 'sanjiv28890@gmail.com', '9115656334', 'chd', '160101', 'chd', 'Commercial', '2019-11-01 07:28:22', 'Pending', 'order_Db68Bnn8rOPYWR'),
(8, '238', '20,21', '1,2', '2102', 'sm', 'sanjiv28890@gmail.com', '9115656334', 'chd', '160101', 'chd', 'Commercial', '2019-11-01 07:29:56', 'Pending', 'order_Db69r9OqdSMaVc'),
(9, '238', '20,21', '1,2', '2102', 'sm', 'sanjiv28890@gmail.com', '9115656334', 'chd', '160101', 'chd', 'Commercial', '2019-11-01 07:31:28', 'Pending', 'order_Db6BTP85hQPu36'),
(10, '238', '20,21', '1,2', '2102', 'sm', 'sanjiv28890@gmail.com', '9115656334', 'chd', '160101', 'chd', 'Commercial', '2019-11-01 07:31:58', 'Complete', 'order_Db6BzJrNoSFYJc');

-- --------------------------------------------------------

--
-- Table structure for table `login_time`
--

CREATE TABLE `login_time` (
  `sno` int(11) NOT NULL,
  `user_id` varchar(11) NOT NULL DEFAULT '',
  `username` varchar(60) NOT NULL DEFAULT '',
  `associate_name` varchar(200) NOT NULL DEFAULT '',
  `mobile` varchar(60) NOT NULL DEFAULT '',
  `created_datetime` varchar(30) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login_time`
--

INSERT INTO `login_time` (`sno`, `user_id`, `username`, `associate_name`, `mobile`, `created_datetime`) VALUES
(1, '233', 'MALS5490', 'G', '08146332291', '2019-10-27 11:49:50'),
(2, '233', 'MALS5490', 'G', '08146332291', '2019-10-27 11:52:44'),
(3, '233', 'MALS5490', 'G', '08146332291', '2019-10-28 11:27:06'),
(4, '233', 'MALS5490', 'G', '08146332291', '2019-10-28 11:29:55'),
(5, '233', 'MALS5490', 'G', '08146332291', '2019-10-28 11:37:37'),
(6, '233', 'MALS5490', 'G', '08146332291', '2019-10-28 11:40:13'),
(7, '233', 'MALS5490', 'G', '08146332291', '2019-10-28 20:39:41'),
(8, '233', 'MALS5490', 'G', '08146332291', '2019-10-29 22:02:40'),
(9, '233', 'MALS5490', 'G', '08146332291', '2019-10-30 19:34:49'),
(10, '233', 'MALS5490', 'G', '08146332291', '2019-10-30 21:41:19'),
(11, '233', 'MALS5490', 'G', '08146332291', '2019-10-30 22:28:21'),
(12, '233', 'MALS5490', 'G', '08146332291', '2019-10-31 00:34:58'),
(13, '233', 'MALS5490', 'G', '08146332291', '2019-10-31 00:35:56'),
(14, '233', 'MALS5490', 'G', '08146332291', '2019-10-31 00:38:47'),
(15, '233', 'MALS5490', 'G', '08146332291', '2019-10-31 00:39:31'),
(16, '233', 'MALS5490', 'G', '08146332291', '2019-10-31 00:39:50'),
(17, '238', 'MALS3961', 'gfdgdf', '4535', '2019-10-31 23:10:12'),
(18, '233', 'MALS5490', 'G', '08146332291', '2019-11-01 00:02:51'),
(19, '238', 'MALS3961', 'gfdgdf', '4535', '2019-11-01 19:07:53');

-- --------------------------------------------------------

--
-- Table structure for table `payment_status`
--

CREATE TABLE `payment_status` (
  `id` int(11) NOT NULL,
  `user_id` varchar(11) NOT NULL DEFAULT '',
  `dd_id` varchar(15) NOT NULL DEFAULT '',
  `pay_email` varchar(100) NOT NULL DEFAULT '',
  `amount` varchar(30) NOT NULL DEFAULT '',
  `pay_mobile` varchar(30) NOT NULL DEFAULT '',
  `pay_status` varchar(30) NOT NULL DEFAULT '',
  `payment_id` varchar(60) NOT NULL DEFAULT '',
  `payment_request_id` varchar(200) NOT NULL DEFAULT '',
  `paymentdate` varchar(80) NOT NULL DEFAULT '',
  `complete` varchar(10) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `payment_status`
--

INSERT INTO `payment_status` (`id`, `user_id`, `dd_id`, `pay_email`, `amount`, `pay_mobile`, `pay_status`, `payment_id`, `payment_request_id`, `paymentdate`, `complete`) VALUES
(5, '233', '5', 'sanjiv28890@gmail.com', '1', '9115656334', 'Pending', '', 'order_DZzaOxBKy34H9r', '2019-10-30 12:25:13', ''),
(6, '233', '6', 'sanjiv28890@gmail.com', '1', '9115656334', 'Complete', 'pay_DZzbDWQmkQcXrq', 'order_DZzavsSEn10lkK', '2019-10-30 12:25:43', '1'),
(7, '238', '7', 'sanjiv28890@gmail.com', '2102', '9115656334', 'Pending', '', 'order_Db68Bnn8rOPYWR', '2019-11-01 07:28:22', ''),
(8, '238', '8', 'sanjiv28890@gmail.com', '2102', '9115656334', 'Pending', '', 'order_Db69r9OqdSMaVc', '2019-11-01 07:29:56', ''),
(9, '238', '9', 'sanjiv28890@gmail.com', '2102', '9115656334', 'Pending', '', 'order_Db6BTP85hQPu36', '2019-11-01 07:31:28', ''),
(10, '238', '10', 'sanjiv28890@gmail.com', '2102', '9115656334', 'Complete', 'pay_Db6DS7rqlp124U', 'order_Db6BzJrNoSFYJc', '2019-11-01 07:31:58', '1');

-- --------------------------------------------------------

--
-- Table structure for table `payout_passbook_list`
--

CREATE TABLE `payout_passbook_list` (
  `sno` int(11) NOT NULL,
  `user_id` varchar(11) NOT NULL DEFAULT '',
  `level` varchar(20) NOT NULL DEFAULT '',
  `income_name` varchar(40) NOT NULL DEFAULT '',
  `amount` varchar(50) NOT NULL DEFAULT '',
  `datetime` varchar(30) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `plan_payout_passbook`
--

CREATE TABLE `plan_payout_passbook` (
  `sno` int(11) NOT NULL,
  `level` varchar(20) NOT NULL DEFAULT '',
  `direct_income` varchar(50) NOT NULL DEFAULT '',
  `level_income` varchar(50) NOT NULL DEFAULT '',
  `other_income` varchar(50) NOT NULL DEFAULT '',
  `status` varchar(11) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `plan_payout_passbook`
--

INSERT INTO `plan_payout_passbook` (`sno`, `level`, `direct_income`, `level_income`, `other_income`, `status`) VALUES
(1, 'H1', '', '', '', '1'),
(2, 'H2', '', '', '', '1'),
(3, 'H3', '', '', '', '1'),
(4, 'H4', '', '', '', '1'),
(5, 'H5', '', '', '', '1'),
(6, 'H6', '', '', '', '1'),
(7, 'H7', '', '', '', '1'),
(8, 'H8', '', '', '', '1'),
(9, 'H9', '', '', '', '1'),
(10, 'H10', '', '', '', '1'),
(11, 'H11', '', '', '', '1'),
(12, 'H12', '', '', '', '1'),
(13, 'H13', '', '', '', '1'),
(14, 'H14', '', '', '', '1');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `type` varchar(40) NOT NULL DEFAULT '',
  `product_title` varchar(200) NOT NULL DEFAULT '',
  `product_sub_ttile` varchar(200) NOT NULL DEFAULT '',
  `product_img1` varchar(60) NOT NULL DEFAULT '',
  `product_img2` varchar(60) NOT NULL DEFAULT '',
  `product_img3` varchar(60) NOT NULL DEFAULT '',
  `product_price1` varchar(30) NOT NULL DEFAULT '',
  `product_price2` varchar(30) NOT NULL DEFAULT '',
  `product_price3` varchar(30) NOT NULL DEFAULT '',
  `description` text NOT NULL,
  `product_graph_img` varchar(60) NOT NULL DEFAULT '',
  `status` varchar(15) NOT NULL DEFAULT '',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `type`, `product_title`, `product_sub_ttile`, `product_img1`, `product_img2`, `product_img3`, `product_price1`, `product_price2`, `product_price3`, `description`, `product_graph_img`, `status`, `created_at`) VALUES
(1, 'shirt', 'Men shirt', 'Men White shirt', '12.jpeg', '11.jpeg', '', '884', '684', '1000', '<li>Fit Type: Regular</li><li>60% cotton and 40% polyester</li><li>Regular fit</li><li>Banded collar</li><li>Half sleeve</li><li>Wash with mild detergent, do not bleach, dry in shade</li>\r\n<li>Made in India</li><li>Plus size available from size XXL onwards</li>', 'graph_product1.jpeg', '1', '2019-10-30 15:16:19'),
(2, 'shirt', 'Men shirt', 'Men White Solid Straight Kurta', '21.jpeg', '', '', '884', '684', '1000', '<li>Fit Type: Regular</li><li>60% cotton and 40% polyester</li><li>Regular fit</li><li>Banded collar</li><li>Half sleeve</li><li>Wash with mild detergent, do not bleach, dry in shade</li>\r\n<li>Made in India</li><li>Plus size available from size XXL onwards</li>', 'graph_product1.jpeg', '1', '2019-10-30 15:20:52'),
(3, 'shirt', 'Men shirt', 'Men Black Solid Straight Kurta', '31.jpeg', '32.jpeg', '', '884', '684', '1000', '<li>Fit Type: Regular</li><li>60% cotton and 40% polyester</li><li>Regular fit</li><li>Banded collar</li><li>Half sleeve</li><li>Wash with mild detergent, do not bleach, dry in shade</li>\r\n<li>Made in India</li><li>Plus size available from size XXL onwards</li>', 'graph_product1.jpeg', '1', '2019-10-30 15:17:50'),
(4, 'shirt', 'Men shirt', 'Men White shirt', '41.jpeg', '42.jpeg', '', '884', '684', '1000', '<li>Fit Type: Regular</li><li>60% cotton and 40% polyester</li><li>Regular fit</li><li>Banded collar</li><li>Half sleeve</li><li>Wash with mild detergent, do not bleach, dry in shade</li>\r\n<li>Made in India</li><li>Plus size available from size XXL onwards</li>', 'graph_product1.jpeg', '1', '2019-10-30 15:16:19'),
(5, 'shirt', 'Men shirt', 'Men White shirt', '51.jpeg', '', '', '884', '684', '1000', '<li>Fit Type: Regular</li><li>60% cotton and 40% polyester</li><li>Regular fit</li><li>Banded collar</li><li>Half sleeve</li><li>Wash with mild detergent, do not bleach, dry in shade</li>\r\n<li>Made in India</li><li>Plus size available from size XXL onwards</li>', 'graph_product1.jpeg', '1', '2019-10-30 15:16:19'),
(6, 'shirt', 'Men shirt', 'Men White shirt', '61.jpeg', '', '', '884', '684', '1000', '<li>Fit Type: Regular</li><li>60% cotton and 40% polyester</li><li>Regular fit</li><li>Banded collar</li><li>Half sleeve</li><li>Wash with mild detergent, do not bleach, dry in shade</li>\r\n<li>Made in India</li><li>Plus size available from size XXL onwards</li>', 'graph_product1.jpeg', '1', '2019-10-30 15:16:19'),
(7, 'shirt', 'Men shirt', 'Men White shirt', '71.jpeg', '', '', '884', '684', '1000', '<li>Fit Type: Regular</li><li>60% cotton and 40% polyester</li><li>Regular fit</li><li>Banded collar</li><li>Half sleeve</li><li>Wash with mild detergent, do not bleach, dry in shade</li>\r\n<li>Made in India</li><li>Plus size available from size XXL onwards</li>', 'graph_product1.jpeg', '1', '2019-10-30 15:16:19'),
(8, 'shirt', 'Men shirt', 'Men White shirt', '81.jpeg', '', '', '884', '684', '1000', '<li>Fit Type: Regular</li><li>60% cotton and 40% polyester</li><li>Regular fit</li><li>Banded collar</li><li>Half sleeve</li><li>Wash with mild detergent, do not bleach, dry in shade</li>\r\n<li>Made in India</li><li>Plus size available from size XXL onwards</li>', 'graph_product1.jpeg', '1', '2019-10-30 15:16:19'),
(9, 'shirt', 'Men shirt', 'Men White shirt', '91.jpeg', '', '', '884', '684', '1000', '<li>Fit Type: Regular</li><li>60% cotton and 40% polyester</li><li>Regular fit</li><li>Banded collar</li><li>Half sleeve</li><li>Wash with mild detergent, do not bleach, dry in shade</li>\r\n<li>Made in India</li><li>Plus size available from size XXL onwards</li>', 'graph_product1.jpeg', '1', '2019-10-30 15:16:19'),
(10, 'shirt', 'Men shirt', 'Men White shirt', '101.jpeg', '', '', '884', '684', '1000', '<li>Fit Type: Regular</li><li>60% cotton and 40% polyester</li><li>Regular fit</li><li>Banded collar</li><li>Half sleeve</li><li>Wash with mild detergent, do not bleach, dry in shade</li>\r\n<li>Made in India</li><li>Plus size available from size XXL onwards</li>', 'graph_product1.jpeg', '1', '2019-10-30 15:16:19'),
(11, 'shirt', 'Men shirt', 'Men White shirt', '110.jpeg', '', '', '884', '684', '1000', '<li>Fit Type: Regular</li><li>60% cotton and 40% polyester</li><li>Regular fit</li><li>Banded collar</li><li>Half sleeve</li><li>Wash with mild detergent, do not bleach, dry in shade</li>\r\n<li>Made in India</li><li>Plus size available from size XXL onwards</li>', 'graph_product1.jpeg', '1', '2019-10-30 15:16:19'),
(12, 'shirt', 'Men shirt', 'Men White shirt', '111.jpeg', '', '', '884', '684', '1000', '<li>Fit Type: Regular</li><li>60% cotton and 40% polyester</li><li>Regular fit</li><li>Banded collar</li><li>Half sleeve</li><li>Wash with mild detergent, do not bleach, dry in shade</li>\r\n<li>Made in India</li><li>Plus size available from size XXL onwards</li>', 'graph_product1.jpeg', '1', '2019-10-30 15:16:19'),
(13, 'shirt', 'Men shirt', 'Men White shirt', '121.jpeg', '', '', '884', '684', '1000', '<li>Fit Type: Regular</li><li>60% cotton and 40% polyester</li><li>Regular fit</li><li>Banded collar</li><li>Half sleeve</li><li>Wash with mild detergent, do not bleach, dry in shade</li>\r\n<li>Made in India</li><li>Plus size available from size XXL onwards</li>', 'graph_product1.jpeg', '1', '2019-10-30 15:16:19'),
(14, 'shirt', 'Men shirt', 'Men White shirt', '131.jpeg', '', '', '884', '684', '1000', '<li>Fit Type: Regular</li><li>60% cotton and 40% polyester</li><li>Regular fit</li><li>Banded collar</li><li>Half sleeve</li><li>Wash with mild detergent, do not bleach, dry in shade</li>\r\n<li>Made in India</li><li>Plus size available from size XXL onwards</li>', 'graph_product1.jpeg', '1', '2019-10-30 15:16:19');

-- --------------------------------------------------------

--
-- Table structure for table `size_cart`
--

CREATE TABLE `size_cart` (
  `id` int(11) NOT NULL,
  `cat` varchar(11) NOT NULL DEFAULT '',
  `size` varchar(40) NOT NULL DEFAULT '',
  `status` tinyint(4) NOT NULL DEFAULT '1' COMMENT '1="available",2="unavailable"'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `size_cart`
--

INSERT INTO `size_cart` (`id`, `cat`, `size`, `status`) VALUES
(1, '', 'XS', 1),
(2, '', 'S', 1),
(3, '', 'M', 1),
(4, '', 'L', 1),
(5, '', 'XL', 1),
(6, '', 'XXL', 1),
(7, '', 'XXXL', 1);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `sno` int(11) NOT NULL,
  `type` varchar(30) NOT NULL DEFAULT '',
  `associate_name` varchar(150) NOT NULL DEFAULT '',
  `parent_id` varchar(30) NOT NULL DEFAULT '',
  `sponser_id` varchar(20) NOT NULL DEFAULT '',
  `position` varchar(30) NOT NULL DEFAULT '',
  `username` varchar(100) NOT NULL DEFAULT '',
  `password` varchar(100) NOT NULL DEFAULT '',
  `orgpass` varchar(100) NOT NULL DEFAULT '',
  `mobile` varchar(30) NOT NULL DEFAULT '',
  `email_address` varchar(150) NOT NULL DEFAULT '',
  `gstin_no` varchar(100) NOT NULL DEFAULT '',
  `associate_address` varchar(255) NOT NULL DEFAULT '',
  `country` varchar(80) NOT NULL DEFAULT '',
  `state` varchar(100) NOT NULL DEFAULT '',
  `city` varchar(100) NOT NULL DEFAULT '',
  `pin_code` varchar(25) NOT NULL DEFAULT '',
  `dob` varchar(50) NOT NULL DEFAULT '',
  `size` varchar(20) NOT NULL DEFAULT '',
  `lenght` varchar(50) NOT NULL DEFAULT '',
  `nominee_name` varchar(150) NOT NULL DEFAULT '',
  `nominee_age` varchar(20) NOT NULL DEFAULT '',
  `nominee_relation` varchar(40) NOT NULL DEFAULT '',
  `account_no` varchar(40) NOT NULL DEFAULT '',
  `account_holder_name` varchar(80) NOT NULL DEFAULT '',
  `bank_name` varchar(200) NOT NULL DEFAULT '',
  `branch_name` varchar(200) NOT NULL DEFAULT '',
  `ifsc` varchar(110) NOT NULL DEFAULT '',
  `pan_card_no` varchar(80) NOT NULL DEFAULT '',
  `adhar_no` varchar(80) NOT NULL DEFAULT '',
  `occupation` varchar(70) NOT NULL DEFAULT '',
  `policy_no` varchar(70) NOT NULL DEFAULT '',
  `upload_pan` varchar(150) NOT NULL DEFAULT '',
  `upload_aadhar_front` varchar(150) NOT NULL DEFAULT '',
  `upload_aadhar_back` varchar(150) NOT NULL DEFAULT '',
  `associate_image` varchar(150) NOT NULL DEFAULT '',
  `associate_sign` varchar(150) NOT NULL DEFAULT '',
  `created` varchar(30) NOT NULL DEFAULT '',
  `status` varchar(11) NOT NULL DEFAULT '',
  `shirt_delivered_date` varchar(30) NOT NULL DEFAULT '',
  `courier_type` varchar(50) NOT NULL DEFAULT '',
  `courier_company` varchar(150) NOT NULL DEFAULT '',
  `courier_mobile` varchar(50) NOT NULL DEFAULT '',
  `courier_datetime` varchar(30) NOT NULL DEFAULT '',
  `id_red_or_green` varchar(15) NOT NULL DEFAULT '',
  `sa_access` varchar(15) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`sno`, `type`, `associate_name`, `parent_id`, `sponser_id`, `position`, `username`, `password`, `orgpass`, `mobile`, `email_address`, `gstin_no`, `associate_address`, `country`, `state`, `city`, `pin_code`, `dob`, `size`, `lenght`, `nominee_name`, `nominee_age`, `nominee_relation`, `account_no`, `account_holder_name`, `bank_name`, `branch_name`, `ifsc`, `pan_card_no`, `adhar_no`, `occupation`, `policy_no`, `upload_pan`, `upload_aadhar_front`, `upload_aadhar_back`, `associate_image`, `associate_sign`, `created`, `status`, `shirt_delivered_date`, `courier_type`, `courier_company`, `courier_mobile`, `courier_datetime`, `id_red_or_green`, `sa_access`) VALUES
(1, 'Super_admin', 'Administrator', '', '', '', 'Gurmukh_Singh', 'f2ac12f87e5f9e36973a0a6973e0eef2', 'Mals@1234', '9115656334', 'sanjiv28890@gmail.com', '23423', 'dsfsd', 'INDIAN', 'JHARKHAND', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '2019-02-05 00:16:06', '1', '', '', '', '', '', '', 'Yes'),
(57, 'Super_admin', 'MALS ADMIN', '', '', '', 'mals_admin', 'd93a5def7511da3d0f2d171d9c344e91', '123456', '9115656334', 'a@mals.com', '', '', '', '', '', '', '', 'Large', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '2019-03-16 14:52:13 14:52:26', '1', '', '', '', '', '', '', ''),
(232, 'Admin', 'MAL', '231', '231', 'left', 'MALS9599', '48a6024cf53bdea674c4ab3fe51056f7', '44', '6', 'gs8146332291@gmail.com', 'Y', 'Y', 'INDIA', 'T', 'Y', 'Y', '1992-09-24', 'Medium', '34', 'Y', 'H', 'H', 'Y', 'U', 'AXIS BANK', 'Y', 'H', 'H', 'H', '', '', '', '', '', '', '', '2019-09-18 23:41:18', '1', '', '', '', '', '', '', ''),
(233, 'Admin', 'G', '232', '232', 'right', 'MALS5490', 'fdcc50b61dc532d15108957e71f5bc9e', 'g', '08146332291', 'gs8146332291@gmail.com', 'F', 'Gh', 'INDIA', 'Punjab', 'Mohali', '140604', '2019-09-12', 'Large', '34', 'V', 'V', 'V', 'H', 'B', 'ANDHRA BANK', 'Hh', 'H', 'B', 'H', '', '', '', '', '', '', '', '2019-09-18 23:47:19', '1', '', '', '', '', '', '', ''),
(237, 'Admin', 'zzc', '', '', 'right', 'MALS4038', 'g', '', '32', '23', '', 'asdad', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '2019-10-31 22:48:44', '', '', '', '', '', '', '', ''),
(238, 'Admin', 'gfdgdf', '', '', 'right', 'MALS3961', 'fdcc50b61dc532d15108957e71f5bc9e', 'g', '4535', '3rgdfg', '', 'vxcvxc', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '2019-10-31 22:51:16', '1', '', '', '', '', '', '', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cart_items`
--
ALTER TABLE `cart_items`
  ADD PRIMARY KEY (`sno`);

--
-- Indexes for table `contactus`
--
ALTER TABLE `contactus`
  ADD PRIMARY KEY (`sno`);

--
-- Indexes for table `country_state_city`
--
ALTER TABLE `country_state_city`
  ADD PRIMARY KEY (`sno`);

--
-- Indexes for table `delivery_details`
--
ALTER TABLE `delivery_details`
  ADD PRIMARY KEY (`sno`);

--
-- Indexes for table `login_time`
--
ALTER TABLE `login_time`
  ADD PRIMARY KEY (`sno`);

--
-- Indexes for table `payment_status`
--
ALTER TABLE `payment_status`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `payout_passbook_list`
--
ALTER TABLE `payout_passbook_list`
  ADD PRIMARY KEY (`sno`);

--
-- Indexes for table `plan_payout_passbook`
--
ALTER TABLE `plan_payout_passbook`
  ADD PRIMARY KEY (`sno`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `size_cart`
--
ALTER TABLE `size_cart`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`sno`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cart_items`
--
ALTER TABLE `cart_items`
  MODIFY `sno` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `contactus`
--
ALTER TABLE `contactus`
  MODIFY `sno` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `country_state_city`
--
ALTER TABLE `country_state_city`
  MODIFY `sno` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `delivery_details`
--
ALTER TABLE `delivery_details`
  MODIFY `sno` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `login_time`
--
ALTER TABLE `login_time`
  MODIFY `sno` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `payment_status`
--
ALTER TABLE `payment_status`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `payout_passbook_list`
--
ALTER TABLE `payout_passbook_list`
  MODIFY `sno` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `plan_payout_passbook`
--
ALTER TABLE `plan_payout_passbook`
  MODIFY `sno` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `size_cart`
--
ALTER TABLE `size_cart`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `sno` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=239;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
