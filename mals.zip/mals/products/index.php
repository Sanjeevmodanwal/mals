<?php
ob_start();
include("../db.php");
include("../header2.php");
if(!isset($_SESSION['sno'])){
    header("Location: ../admin_login");
    exit(); 
}

if(isset($_SESSION['sno']) && !empty($_SESSION['sno'])){
$sessionid = $_SESSION['sno'];
$result1 = "SELECT sno,type,sa_access FROM users WHERE sno = '$sessionid'";
$getusers = mysqli_query($con, $result1);
$rowusers = mysqli_fetch_assoc($getusers);
	$loggedid = mysqli_real_escape_string($con, $rowusers['sno']);
	$adminrole = mysqli_real_escape_string($con, $rowusers['type']);
	$sa_access = mysqli_real_escape_string($con, $rowusers['sa_access']);
}else{
	$loggedid = '';
	$adminrole = '';
	$sa_access = '';
}

if($adminrole == 'Super_admin'){
?>
<div id="wrapper">
    <?php include("../sidebar2.php"); ?>
	
    <div id="content-wrapper">
      <div class="container-fluid">
		<div class="card mb-3">
          <div class="card-header">
            <i class="fas fa-table"></i>
            Products List</div>
			
          <div class="card-body">
            <div class="table-responsive">
              <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                  <tr>
					<th>Type</th>                    <th>Image</th>                    <th>Title</th>
                    <th>Sub Title</th>
                    <th>Created On</th>
                    <th>Action</th>
                  </tr>
                </thead>
                <tbody>
				<?php
				$resultAssociate = mysqli_query($con, "SELECT * FROM products WHERE type!='' AND status='1'");
				while ($row_asso = mysqli_fetch_assoc($resultAssociate)) {
					$snoid = mysqli_real_escape_string($con, $row_asso['id']);					$type = mysqli_real_escape_string($con, $row_asso['type']);					$product_title = mysqli_real_escape_string($con, $row_asso['product_title']);					$product_sub_ttile = mysqli_real_escape_string($con, $row_asso['product_sub_ttile']);					$product_img1 = mysqli_real_escape_string($con, $row_asso['product_img1']);					$created_at = mysqli_real_escape_string($con, $row_asso['created_at']);									?>
                <tr class="pdelsno<?php echo $snoid; ?>">
                    <td><?php echo $type; ?></td>                    <td><img src="../uploads/products/<?php echo $product_img1; ?>" style="width:40px;height:40px;"></td>
                    <td><?php echo $product_title; ?></td>                    <td><?php echo $product_sub_ttile; ?></td>
                    <td><?php echo $created_at; ?></td>
                    <td>					<a href="../products/add_edit.php?snopid=<?php echo base64_encode($snoid); ?>" class="btn btn-sm btn-warning">Edit</a>					<a href="javascript::void(0)" class="btn btn-sm btn-danger pdeldiv" data-id="<?php echo $snoid; ?>">Delete</a>					</td>
                </tr>
                <?php } ?>
                </tbody>
              </table>
            </div>
          </div>
        </div>		
<script>$(document).on('click', '.pdeldiv', function(){	var getid = $(this).attr('data-id');				var checkstr =  confirm('Are you sure you want to delete this product?');	if(checkstr == true){		$.post("../response.php?tag=prod_id",{"getid":getid},function(d){			if(d == '1'){				$('.pdelsno'+getid).hide();			}		});	}else{		return false;	}});

// $(document).on('click', '.idColorDiv', function(){
	// var getid = $(this).attr('data-id');
	// var getval = $(this).attr('data-val');
		
	// var checkstr =  confirm('Are you sure you want to change this?');
	// if(checkstr == true){
		
		// if(getval == 'green'){
			// $('#id_btn_change'+getid).css({"color": "#fff","background-color": "green","border-color": "#bd2130"});
			// $('#id_btn_change'+getid).attr('data-val', 'red');
		// }
		// if(getval == 'red'){
			// $('#id_btn_change'+getid).css({"color": "#fff","background-color": "#c82333","border-color": "#bd2130"});
			// $('#id_btn_change'+getid).attr('data-val', 'green');
		// }
		// $.post("../response.php?tag=getcolorChange",{"getid":getid, "getval":getval},function(d){
			
		// });
	// }else{
		// return false;
	// }
// });
</script>

<?php include("../footer2.php"); 
}else{
	header("Location: ../logout.php");
}
?>
