<?php
ob_start();
include("../db.php");
include("../header2.php");
if(!isset($_SESSION['sno'])){
    header("Location: ../admin_login");
    exit(); 
}
if(isset($_SESSION['sno']) && !empty($_SESSION['sno'])){
$sessionid = $_SESSION['sno'];
$result1 = "SELECT sno,type FROM users WHERE sno = '$sessionid'";
$getusers = mysqli_query($con, $result1);$rowusers = mysqli_fetch_assoc($getusers);
	$loggedid = mysqli_real_escape_string($con, $rowusers['sno']);
	$adminrole = mysqli_real_escape_string($con, $rowusers['type']);
}else{	$loggedid = '';
	$adminrole = '';
}
if(!empty($_GET['snopid'])){	$getid = base64_decode($_GET['snopid']);	$results_paid = "SELECT * FROM products WHERE type!='' AND status='1' AND id='$getid'";	$resultsstr = mysqli_query($con, $results_paid);	$row_asso = mysqli_fetch_assoc($resultsstr);	$id = mysqli_real_escape_string($con, $row_asso['id']);	$type = mysqli_real_escape_string($con, $row_asso['type']);	$product_title = mysqli_real_escape_string($con, $row_asso['product_title']);	$product_sub_ttile = mysqli_real_escape_string($con, $row_asso['product_sub_ttile']);	$product_img1 = mysqli_real_escape_string($con, $row_asso['product_img1']);	$product_img2 = mysqli_real_escape_string($con, $row_asso['product_img2']);	$product_img3 = mysqli_real_escape_string($con, $row_asso['product_img3']);	$product_price1 = mysqli_real_escape_string($con, $row_asso['product_price1']);	$product_price2 = mysqli_real_escape_string($con, $row_asso['product_price2']);	$product_price3 = mysqli_real_escape_string($con, $row_asso['product_price3']);	$description = mysqli_real_escape_string($con, $row_asso['description']);	$product_graph_img = mysqli_real_escape_string($con, $row_asso['product_graph_img']);
	
	if(isset($_GET['pval']) == 'product_img2'){
		$update2 = "update `products` set `product_img2`='' where `id`='$getid'";
		mysqli_query($con, $update2);
		unlink("../uploads/products/$product_img2");
		$snoid = base64_encode($getid);
		header("Location: add_edit.php?snopid=$snoid");
	}
	
	if(isset($_GET['pval']) == 'product_img3'){
		$update2 = "update `products` set `product_img3`='' where `id`='$getid'";
		mysqli_query($con, $update2);
		unlink("../uploads/products/$product_img3");
		$snoid = base64_encode($getid);
		header("Location: add_edit.php?snopid=$snoid");
	}
	
	if(isset($_GET['pval']) == 'product_graph_img'){
		$update2 = "update `products` set `product_graph_img`='' where `id`='$getid'";
		mysqli_query($con, $update2);
		$snoid = base64_encode($getid);
		header("Location: add_edit.php?snopid=$snoid");
	}	
	}else{	$getid = '';	$id = '';	$type = '';	$product_title = '';	$product_sub_ttile = '';	$product_img1 = '';	$product_img2 = '';	$product_img3 = '';	$product_price1 = '';	$product_price2 = '';	$product_price3 = '';	$description = '';	$product_graph_img = '';}$random_2 = base64_encode(rand());

if($adminrole == 'Super_admin'){
?>
<style>
ul#ui-id-1{
	height: 300px;
    overflow: auto;
}
</style>

<div id="wrapper">
    <?php include("../sidebar2.php"); ?>
	
    <div id="content-wrapper">
      <div class="container-fluid">
        <!-- Breadcrumbs-->
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="../dashboard">Dashboard</a></li>
          <li class="breadcrumb-item"><a href="../products">Products List</a></li>
          <li class="breadcrumb-item active">
		  <?php if(!empty($_GET['snopid'])){ ?>
		  Edit Product
		  <?php }else{ ?>
		  Add New Product
		  <?php } ?>
		  </li>
        </ol>
        <!-- Icon Cards-->
        <div class="row">
			<div class="col-lg-12">
			<div class="panel panel-default">	<form method="post" autocomplete="off" name="prodRegisterFrm" id="prodRegisterFrm">
		<div class="panel-body">					<div class="form-group">				<div class="row">					<div class="col-sm-2">						<label>Product Type<span class="required">*</span></label>					</div>					<div class="col-sm-9">						<select name="type" class="form-control" required>							<option value="">Select Option</option>
						<?php 
						$resultCatstr = mysqli_query($con, "SELECT * FROM categories");
							while ($row_Cat = mysqli_fetch_assoc($resultCatstr)) {
							$namecat = mysqli_real_escape_string($con, $row_Cat['name']);
							$name_link = mysqli_real_escape_string($con, $row_Cat['name_link']);
						?>								<option value="<?php echo $name_link; ?>" <?php if($type == $name_link) { echo 'selected="selected"'; } ?>><?php echo $namecat; ?></option>
						<?php } ?>						</select>					</div>				</div>			</div>		
			<div class="form-group">
				<div class="row">
					<div class="col-sm-2">
						<label>Product Title <span class="required">*</span></label>
					</div>
					<div class="col-sm-9">
						<input name="product_title" type="text" class="form-control" value="<?php echo $product_title; ?>" required />
					</div>
				</div>
			</div>						<div class="form-group">				<div class="row">					<div class="col-sm-2">						<label>Product Sub-Title <span class="required">*</span></label>					</div>					<div class="col-sm-9">						<input name="product_sub_ttile" type="text" class="form-control" value="<?php echo $product_sub_ttile; ?>" required />					</div>				</div>			</div>						<div class="form-group">				<div class="row">					<div class="col-sm-2">						<label>Product Image1 <span class="required">*</span></label>					</div>					<div class="col-sm-9">						<input name="product_img1" type="file" id="product_img1" value="<?php echo $product_img1; ?>" required />					<?php if(!empty($product_img1)){ ?><br>					<a href="../uploads/products/<?php echo $product_img1; ?>" download>Download</a>					<?php } ?>					</div>				</div>			</div>						<div class="form-group">				<div class="row">					<div class="col-sm-2">						<label>Product Image2</label>					</div>					<div class="col-sm-9">						<input name="product_img2" type="file" id="product_img2" value="<?php echo $product_img2; ?>" />					<?php if(!empty($product_img2)){ ?><br>					<a href="../uploads/products/<?php echo $product_img2; ?>" download>Download</a> | 
					<a href="add_edit.php?snopid=<?php echo base64_encode($getid); ?>&pval=product_img2">Delete Photo</a>										<?php } ?>					</div>				</div>			</div>						<div class="form-group">				<div class="row">					<div class="col-sm-2">						<label>Product Image3</label>					</div>					<div class="col-sm-9">						<input name="product_img3" type="file" id="product_img3" value="<?php echo $product_img3; ?>" />					<?php if(!empty($product_img3)){ ?><br>					<a href="../uploads/products/<?php echo $product_img3; ?>" download>Download</a> | 
					<a href="add_edit.php?snopid=<?php echo base64_encode($getid); ?>&pval=product_img3">Delete Photo</a>					<?php } ?>					</div>				</div>			</div>						<div class="form-group">				<div class="row">					<div class="col-sm-2">						<label>Product MRP Price</label>					</div>					<div class="col-sm-9">						<input name="product_price1" type="text" class="form-control" value="<?php echo $product_price1; ?>" />					</div>				</div>			</div>						<div class="form-group">				<div class="row">					<div class="col-sm-2">						<label>Product DP Price <span class="required">*</span></label>					</div>					<div class="col-sm-9">						<input name="product_price2" type="text" class="form-control" value="<?php echo $product_price2; ?>" required />					</div>				</div>			</div>						<div class="form-group">				<div class="row">					<div class="col-sm-2">						<label>Product BV Price</label>					</div>					<div class="col-sm-9">						<input name="product_price3" type="text" class="form-control" value="<?php echo $product_price3; ?>" />					</div>				</div>			</div>						<div class="form-group">				<div class="row">					<div class="col-sm-2">						<label>Description <span class="required">*</span></label>					</div>					<div class="col-sm-9">						<textarea name="description" class="form-control" rows="5"><?php echo $description; ?></textarea>					</div>				</div>			</div>						<div class="form-group">				<div class="row">					<div class="col-sm-2">						<label>Product Graph Image</label>					</div>					<div class="col-sm-9">						<input name="product_graph_img" type="file" id="product_graph_img" value="<?php echo $product_graph_img; ?>" />					<?php if(!empty($product_graph_img)){ ?><br>					<a href="../uploads/products/<?php echo $product_graph_img; ?>" download>Download</a> | 					
					<a href="add_edit.php?snopid=<?php echo base64_encode($getid); ?>&pval=product_graph_img">Delete Photo</a>					<?php } ?>					</div>				</div>			</div>			
			<div class="row mb-5">				<div class="col-sm-10"></div>
				<div class="col-md-2">
					<input type="hidden" name="pid" value="<?php echo $getid; ?>">
					 <?php if(!empty($_GET['snopid'])){ ?>
					<button type="button" class="btn btn-warning" id="prdbtn">Update</button>
					  <?php }else{ ?>
					<button type="button" class="btn btn-success" id="prdbtn">Save</button>
					  <?php } ?>
				</div>
			</div>
        </div>
		</form>
        </div>
        </div>
        </div>   </div>  </div></div>    <script>$('#prdbtn').on('click', function(e){$('.loading_icon').show();$("#prdbtn").attr("disabled", true);	e.preventDefault();		var form=document.getElementById('prodRegisterFrm');	var fdata=new FormData(form); 	$.ajax({		type: "POST",		url: '../response.php?tag=newProductAE',		data: fdata,		contentType: false,		cache: false,		processData:false,		success: function(result){			if(result == 1){			  window.location.href='../products';			  $("#prodRegisterFrm")[0].reset();			  $("#prdbtn").attr("disabled", false);			  $('.loading_icon').hide();			  return false;			}			if(result == 2){				alert('File is not Supported (Please upload the JPG, PNG and JPEG Files)');				$('.loading_icon').hide();				$("#prdbtn").attr("disabled", false);				return false;			}		}	});		});	</script>        <?php include("../footer2.php"); 
}else{
	header("Location: ../logout.php");
}
?>
