<?php
ob_start();
include("../db.php");
include("../header2.php");

if(!isset($_SESSION['sno'])){
    header("Location: ../admin_login");
    exit(); 
}

if(isset($_SESSION['sno']) && !empty($_SESSION['sno'])){
$sessionid = $_SESSION['sno'];
$result1 = "SELECT sno,type FROM users WHERE sno = '$sessionid'";
$getusers = mysqli_query($con, $result1);
$rowusers = mysqli_fetch_assoc($getusers);
	$loggedid = mysqli_real_escape_string($con, $rowusers['sno']);
	$adminrole = mysqli_real_escape_string($con, $rowusers['type']);
}else{
	$loggedid = '';
	$adminrole = '';
}


if(!empty($_GET['snopid'])){
	$getid = base64_decode($_GET['snopid']);

	$results_paid = "SELECT * FROM categories WHERE id='$getid'";
	$resultsstr = mysqli_query($con, $results_paid);
	$row_asso = mysqli_fetch_assoc($resultsstr);
	$id = mysqli_real_escape_string($con, $row_asso['id']);
	$name = mysqli_real_escape_string($con, $row_asso['name']);
	$cat_img1 = mysqli_real_escape_string($con, $row_asso['image']);
}else{

	$getid = '';
	$id = '';
	$name = '';
	$cat_img1 = '';
}

$random_2 = base64_encode(rand());



if($adminrole == 'Super_admin'){

?>

<style>
ul#ui-id-1{
	height: 300px;
    overflow: auto;
}
</style>



<div id="wrapper">

    <?php include("../sidebar2.php"); ?>

	

    <div id="content-wrapper">

      <div class="container-fluid">
        <!-- Breadcrumbs-->

        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="../dashboard">Dashboard</a></li>
          <li class="breadcrumb-item"><a href="../products/cat_index.php">Product Categories List</a></li>
          <li class="breadcrumb-item active">
		  <?php if(!empty($_GET['snopid'])){ ?>
		  Edit Category
		  <?php }else{ ?>
		  Add New Product Category
		  <?php } ?>
		  </li>
        </ol>

        <!-- Icon Cards-->

        <div class="row">
			<div class="col-lg-12">
			<div class="panel panel-default">
	<form method="post" autocomplete="off" name="prodRegisterFrm" id="prodRegisterFrm">
		<div class="panel-body">
		
			<div class="form-group">
				<div class="row">
					<div class="col-sm-2">
						<label>Category Name <span class="required">*</span></label>
					</div>
					<div class="col-sm-9">
						<input name="name" type="text" class="form-control" value="<?php echo $name; ?>" required />
					</div>
				</div>
			</div>
			
			<div class="form-group">
				<div class="row">
					<div class="col-sm-2">
						<label>Category Image <span class="required">*</span></label>
					</div>
					<div class="col-sm-9">
						<input name="cat_img" type="file" id="cat_img" value="<?php echo $cat_img1; ?>" required />
					<?php if(!empty($cat_img1)){ ?><br>
					<a href="../uploads/products/<?php echo $cat_img1; ?>" download>Download</a>
					<?php } ?>
					</div>
				</div>
			</div>
			<div class="row mb-5">
				<div class="col-sm-9"></div>
				<div class="col-md-2">
					<input type="hidden" name="pid" value="<?php echo $getid; ?>">
					 <?php if(!empty($_GET['snopid'])){ ?>
					<button type="button" class="btn btn-warning w-100" id="prdbtn">Update</button>
					  <?php }else{ ?>
					<button type="button" class="btn btn-success w-100" id="prdbtn">Save</button>
					  <?php } ?>
				</div>
				<div class="col-sm-1"></div>
			</div>
			
        </div>
		</form>
        </div>
        </div>
        </div>
   </div>
  </div>
</div> 
   
<script>
$('#prdbtn').on('click', function(e){

$('.loading_icon').show();
$("#prdbtn").attr("disabled", true);
	e.preventDefault();
	
	var form=document.getElementById('prodRegisterFrm');
	var fdata=new FormData(form); 
	$.ajax({
		type: "POST",
		url: '../response.php?tag=newCatAE',
		data: fdata,
		contentType: false,
		cache: false,
		processData:false,
		success: function(result){
			if(result == 1){
			  window.location.href='../products/cat_index.php';
			  $("#prodRegisterFrm")[0].reset();
			  $("#prdbtn").attr("disabled", false);
			  $('.loading_icon').hide();
			  return false;
			}
			if(result == 2){
				alert('File is not Supported (Please upload the JPG, PNG and JPEG Files)');
				$('.loading_icon').hide();
				$("#prdbtn").attr("disabled", false);
				return false;
			}
		}
	});	
	
});	
</script>  
   
   
<?php include("../footer2.php"); 

}else{
	header("Location: ../logout.php");
}

?>

