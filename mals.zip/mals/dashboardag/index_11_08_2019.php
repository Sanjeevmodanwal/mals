<?php
ob_start();
include("../db.php");
include("../header2.php");

if(!isset($_SESSION['sno'])){
    header("Location: ../login");
    exit(); 
}

if(isset($_SESSION['sno']) && !empty($_SESSION['sno'])){
$sessionid = $_SESSION['sno'];
$result1 = "SELECT sno,type FROM users WHERE sno = '$sessionid'";
$getusers = mysqli_query($con, $result1);
$rowusers = mysqli_fetch_assoc($getusers);
	$loggedid = mysqli_real_escape_string($con, $rowusers['sno']);
	$adminrole = mysqli_real_escape_string($con, $rowusers['type']);
}else{
	$loggedid = '';
	$adminrole = '';
}

if($adminrole == 'Admin'){
?>
<div id="wrapper">
    <?php include("../sidebar2.php"); ?>
	
    <div id="content-wrapper">
      <div class="container-fluid">
        <!-- Breadcrumbs-->
        <ol class="breadcrumb">
          <li class="breadcrumb-item">
            <a href="#">Dashboard</a>
          </li>
          <li class="breadcrumb-item active">Overview</li>
        </ol>

        <!-- Icon Cards-->
        <div class="row">
          <div class="col-xl-3 col-sm-6 mb-3">
            <div class="card text-white bg-primary o-hidden h-100">
              <div class="card-body">
                <div class="card-body-icon">
                  <i class="fas fa-fw fa-comments"></i>
                </div>
				<?php 
				$resultAssociateTotal = mysqli_query($con,"SELECT sno FROM users WHERE type='Admin' AND sno!='$loggedid' AND parent_id='$loggedid'");
				$total_add = mysqli_num_rows($resultAssociateTotal);
				?>
                <div class="mr-5">Total Add (<?php echo $total_add;?>)</div>
              </div>
              <a class="card-footer text-white clearfix small z-1" href="../associateag">
                <span class="float-left">View Details</span>
                <span class="float-right">
                  <i class="fas fa-angle-right"></i>
                </span>
              </a>
            </div>
          </div>
          <div class="col-xl-3 col-sm-6 mb-3">
            <div class="card text-white bg-warning o-hidden h-100">
              <div class="card-body">
                <div class="card-body-icon">
                  <i class="fas fa-fw fa-list"></i>
                </div>
				<?php 
				$resultTotal = mysqli_query($con,"SELECT sno FROM users WHERE type='Admin'");
				$total_add_1 = mysqli_num_rows($resultTotal);
				?>
                <div class="mr-5">Total Team (<?php echo $total_add_1;?>)</div>
              </div>
              <a class="card-footer text-white clearfix small z-1" href="../associateag/totalteam.php">
                <span class="float-left">View Details</span>
                <span class="float-right">
                  <i class="fas fa-angle-right"></i>
                </span>
              </a>
            </div>
          </div>
          <!--div class="col-xl-3 col-sm-6 mb-3">
            <div class="card text-white bg-success o-hidden h-100">
              <div class="card-body">
                <div class="card-body-icon">
                  <i class="fas fa-fw fa-shopping-cart"></i>
                </div>
                <div class="mr-5">123 New Orders!</div>
              </div>
              <a class="card-footer text-white clearfix small z-1" href="#">
                <span class="float-left">View Details</span>
                <span class="float-right">
                  <i class="fas fa-angle-right"></i>
                </span>
              </a>
            </div>
          </div>
          <div class="col-xl-3 col-sm-6 mb-3">
            <div class="card text-white bg-danger o-hidden h-100">
              <div class="card-body">
                <div class="card-body-icon">
                  <i class="fas fa-fw fa-life-ring"></i>
                </div>
                <div class="mr-5">13 New Tickets!</div>
              </div>
              <a class="card-footer text-white clearfix small z-1" href="#">
                <span class="float-left">View Details</span>
                <span class="float-right">
                  <i class="fas fa-angle-right"></i>
                </span>
              </a>
            </div>
          </div>
        </div-->


        <!-- DataTables Example -->
        <div class="card mb-3">
          
        </div>
   </div>

<?php include("../footer2.php"); 
}else{
	header("Location: ../logout.php");
}
?>
