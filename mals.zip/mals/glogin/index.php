<?php

require_once('settings.php');

// $login_url = 'https://accounts.google.com/o/oauth2/v2/auth?scope=' . urlencode('https://www.googleapis.com/auth/userinfo.profile https://www.googleapis.com/auth/userinfo.email https://www.googleapis.com/auth/plus.me') . '&redirect_uri=' . urlencode(CLIENT_REDIRECT_URL) . '&response_type=code&client_id=' . CLIENT_ID . '&access_type=offline&prompt=consent';


$login_url = 'https://accounts.google.com/o/oauth2/auth?scope='.urlencode('https://www.googleapis.com/auth/userinfo.profile https://www.googleapis.com/auth/userinfo.email https://www.googleapis.com/auth/plus.me').'&redirect_uri='.urlencode('http://mals.co.in/glogin/gauth.php').'&response_type=code&client_id=826473254160-04narii8jogitopkmdb5h9t5mp300skl.apps.googleusercontent.com&access_type=offline&prompt=consent';
?>
<html>
<head>
<style type="text/css">

#login-button {
	display: block;
	text-align: center;
	margin: 50px 0;
}

</style>
</head>

<body>

<a href="<?= $login_url ?>">Login with Google</a>

</body>
</html>