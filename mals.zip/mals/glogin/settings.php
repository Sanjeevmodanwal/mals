<?php
/* Google App Client Id */
define('CLIENT_ID', '826473254160-04narii8jogitopkmdb5h9t5mp300skl.apps.googleusercontent.com');

/* Google App Client Secret */
define('CLIENT_SECRET', 'xlIn-EeuYkFqqUL-C1QYh5WK');

/* Google App Redirect Url */
define('CLIENT_REDIRECT_URL', 'http://mals.co.in/glogin/gauth.php');

?>