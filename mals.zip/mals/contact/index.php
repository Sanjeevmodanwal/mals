<?php
include("../header.php");
?>
<section class="content bg-white pt-5 pb-5 mb-5">
        <div class="container">
  		
<div class="at-sectiontitleborder text-center">
	<h1 class="mb-5">Contact Us</h1>	
</div> 	
<div class="row">
<div class="col-lg-4 col-md-6">
<div class="contact-box">
<div class="contact-icon"> <i class="fas fa-map-marker-alt"></i></div>
<div class="contact-txt">  
	<h3 class="mb-0">Our Address</h3>
	<p>#399,Vill.-Jawahar Puri, Teh.-Dera Bassi,<br>Dist.-Mohali</p>
</div>
</div>
</div>
<div class="col-lg-4 col-md-6">
<div class="contact-box">
<div class="contact-icon"><i class="fas fa-phone"></i> </div>
<div class="contact-txt"> <h3 class="mb-0">Phone Number</h3>
<p><a href="tel:7508225311">+91 750 822 5311</a></p>
</div>
</div>
</div>
<div class="col-lg-4 col-md-6">
<div class="contact-box">
<div class="contact-icon"> <i class="far fa-envelope"></i> </div>
<div class="contact-txt">  <h3 class="mb-0">Our Email Id</h3>
<p><a href="mailto:support@mals.co.in">support@mals.co.in</a></p>
</div>
</div>
 </div>
 </div>
</div>
</section>
	

<section id="map">
	<div class="row footer-contact">
	<!-- IFRAME: GET YOUR LOCATION FROM GOOGLE MAP -->
	<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d27475.803705022037!2d76.82498919128845!3d30.592349627905538!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x390fbfe3d47980c5%3A0x81c713e2fce9c86a!2sDera+Bassi%2C+Punjab!5e0!3m2!1sen!2sin!4v1550597505787" width="100%" height="400" frameborder="0" style="border:0" allowfullscreen></iframe>
	<div class="container">
	<div class="contact-overlay footer-part footer-form">
	<div class="footer-form-head">
	<p>Send Us Now</p>
	<h2>Get In Touch</h2> <span class="footer-ser-re">Service Request Form</span> </div>
	<!-- ENQUIRY FORM -->
                    
					
<form method="post" id="contactusform" class="mt-4" name="contactusform" autocomplete="off">
	<div class="row">
	<div class="col-sm-6">
		<input type="text" name="your_name" id="name_contact" size="40" class="form-control name_contact" placeholder="Name">
	</div>
	<div class="col-sm-6">
		<input type="email" name="your_email" id="email_contact" size="40" class="form-control email_contact" placeholder="Email">
	</div>
	<div class="col-sm-12"> 
		<input type="text" name="your_phone" id="phone_contact" size="40" class="form-control phone_contact" placeholder="Phone"> 
	</div> 
	<div class="col-sm-12">
		<textarea name="your_message" id="message_contact" cols="1" rows="1" class="form-control message_contact" placeholder="Comment"></textarea> 
	</div>	
	<div class="col-sm-12">
		<button type="button" class="btn btn-green mt-3" id="contactfomsubmit">SUBMIT</button>
	</div>
	</div>
</form>
					

</div>
</div>
</section>
<style>
.map.agileits {display:none;}
</style>
	<?php
include("../footer.php");

?>

<script>
$('#contactfomsubmit').on('click', function(e){
	e.preventDefault();
	
	var name_contact = $('#name_contact').val();
	var email_contact = $('#email_contact').val();
	var phone_contact = $('#phone_contact').val();
	var message_contact = $('#message_contact').val();
	
	if(name_contact == "") {
		$('.name_contact').css({"border":"1px solid red"});		
	}
	if(email_contact == "") {
		$('.email_contact').css({"border":"1px solid red"});		
	}
	if(phone_contact == "") {
		$('.phone_contact').css({"border":"1px solid red"});		
	}
	if(message_contact == "") {
		$('.message_contact').css({"border":"1px solid red"});		
	}
	
	if(name_contact == "" || email_contact == "" || phone_contact == "" || message_contact == ""){
		return false;
	}		
	
	var $form = $(this).closest("#contactusform");
	var formData =  $form.serializeArray();
	var URL = "../response.php?tag=contactInset";
	$.post(URL, formData).done(function(data) {
		if(data == 1){
		  alert('Thanks for your submission. We will contact you soon');
		  window.reload();
		  return false;
		 }
	 });
	
});	
</script>