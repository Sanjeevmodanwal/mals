<?php
$con = mysqli_connect("localhost", "root", "", "malsc3a1_makealife_db");
if (mysqli_connect_errno()) {
  printf("Connect failed: %s\n", mysqli_connect_error());
  exit();
}
//mysqli_close($con);/
?>