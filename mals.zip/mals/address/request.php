<!DOCTYPE html>
<html>
<head>
  <title>Cashfree - Signature Generator</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">

</head>
<body onload="document.frm1.submit()">


<?php 
include("../db.php");
date_default_timezone_set("Asia/Kolkata");


$mode = "PROD"; //<------------ Change to TEST for test server, PROD for production

// extract($_POST);

$time = date('Y-m-d h:i:s'); 	
$user_id = $_POST['user_id'];
$cart_details = $_POST['cart_id'];
$pro_quantity = $_POST['pro_quantity'];	
$orderAmount = $_POST['amount']; //'1';
$customerName = $_POST['full_name'];
$customerEmail = $_POST['email'];
$customerPhone = $_POST['mobile'];
$pincode = $_POST['pin_code'];
$address = $_POST['address'];
$city = $_POST['city'];
$orderNote = $_POST['order_place'];
$total_quantity = $_POST['total_quantity'];

$cart_id = implode("','", $cart_details);
$product_quantity = implode("','", $pro_quantity);

$insert_quesry = "INSERT INTO `delivery_details`(`payment_status`, `created_at`) VALUES ('Pending', '$time')";
mysqli_query($con, $insert_quesry); 
$dd_id = mysqli_insert_id($con);
$orderId = 'MALS_orderId_'.$dd_id;


$appId = '3163120d8513489684a3fc74313613';
$orderCurrency = 'INR';
$returnUrl = 'http://localhost/mals/address/response.php';
$notifyUrl = 'http://localhost/mals/address/response.php';

  $secretKey = "4d6ad11ca9952dd8365337c1b477f453a825358b";
  $postData = array( 
  "appId" => $appId, 
  "orderId" => $orderId, 
  "orderAmount" => $orderAmount, 
  "orderCurrency" => $orderCurrency, 
  "orderNote" => $orderNote, 
  "customerName" => $customerName, 
  "customerPhone" => $customerPhone, 
  "customerEmail" => $customerEmail,
  "returnUrl" => $returnUrl, 
  "notifyUrl" => $notifyUrl,
);
ksort($postData);
$signatureData = "";
foreach ($postData as $key => $value){
    $signatureData .= $key.$value;
}
$signature = hash_hmac('sha256', $signatureData, $secretKey,true);
$signature = base64_encode($signature);

if ($mode == "PROD") {
  $url = "https://www.cashfree.com/checkout/post/submit";
} else {
  $url = "https://test.cashfree.com/billpay/checkout/post/submit";
}

$update_query = "UPDATE `delivery_details` SET `user_id`='$user_id', `cart_id`='$cart_id', `quantity`='$product_quantity', `total_amount`='$orderAmount', `full_name`='$customerName', `email`='$customerEmail', `mobile`='$customerPhone', `pin_code`='$pincode', `address`='$address', `city`='$city', `order_place`='$orderNote', `payment_request_id`='$orderId' WHERE sno='$dd_id'";
mysqli_query($con, $update_query);

$inserted = "INSERT INTO `payment_status` (user_id, dd_id, `pay_email`, amount, `pay_mobile`, `pay_status`, `payment_request_id`, `paymentdate`) VALUES ('$user_id', '$dd_id', '$customerEmail', '$orderAmount', '$customerPhone', 'Pending', '$orderId', '$time')";
mysqli_query($con, $inserted);

?>
  <form action="<?php echo $url; ?>" name="frm1" method="post">
      <p>Please wait.......</p>
      <input type="hidden" name="signature" value='<?php echo $signature; ?>'/>
      <input type="hidden" name="orderNote" value='<?php echo $orderNote; ?>'/>
      <input type="hidden" name="orderCurrency" value='<?php echo $orderCurrency; ?>'/>
      <input type="hidden" name="customerName" value='<?php echo $customerName; ?>'/>
      <input type="hidden" name="customerEmail" value='<?php echo $customerEmail; ?>'/>
      <input type="hidden" name="customerPhone" value='<?php echo $customerPhone; ?>'/>
      <input type="hidden" name="orderAmount" value='<?php echo $orderAmount; ?>'/>
      <input type ="hidden" name="notifyUrl" value='<?php echo $notifyUrl; ?>'/>
      <input type ="hidden" name="returnUrl" value='<?php echo $returnUrl; ?>'/>
      <input type="hidden" name="appId" value='<?php echo $appId; ?>'/>
      <input type="hidden" name="orderId" value='<?php echo $orderId; ?>'/>
  </form>
</body>
</html>
