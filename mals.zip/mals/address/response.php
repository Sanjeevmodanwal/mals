<?php
ob_start();
include("../db.php");
include("../header.php");

if(!isset($_SESSION['sno'])){
    header("Location: ../login");
    exit(); 
}
?>

<?php  
	 $secretkey = "4d6ad11ca9952dd8365337c1b477f453a825358b";
	 $orderId = $_POST["orderId"];
	 $orderAmount = $_POST["orderAmount"];
	 $referenceId = $_POST["referenceId"];
	 $txStatus = $_POST["txStatus"];
	 $paymentMode = $_POST["paymentMode"];
	 $txMsg = $_POST["txMsg"];
	 $txTime = $_POST["txTime"];
	 $signature = $_POST["signature"];
	 $data = $orderId.$orderAmount.$referenceId.$txStatus.$paymentMode.$txMsg.$txTime;
	 $hash_hmac = hash_hmac('sha256', $data, $secretkey, true) ;
	 $computedSignature = base64_encode($hash_hmac);
if ($signature == $computedSignature) {
			 
	$update_query = "UPDATE `payment_status` SET `pay_status`= 'Complete', `payment_mode`= '$paymentMode', `payment_id`='$referenceId' WHERE payment_request_id='$orderId'";
	$payment_rqst_id = mysqli_query($con, $update_query);
	
	$get_data = 'SELECT * From payment_status where payment_id="'.$referenceId.'"';	
	$rsltqry_data = mysqli_query($con, $get_data);
    $rowpay_data = mysqli_fetch_array($rsltqry_data);
	$email = $rowpay_data['pay_email'];
	$mobile = $rowpay_data['pay_mobile'];
	$user_done = $rowpay_data['complete'];
	$dd_id = $rowpay_data['dd_id'];

	$get_data1 = 'SELECT * From delivery_details where sno="'.$dd_id.'"';	
	$rsltqry_data1 = mysqli_query($con, $get_data1);
    $rowpay_data1 = mysqli_fetch_array($rsltqry_data1);
	$full_name = $rowpay_data1['full_name'];
	$address = $rowpay_data1['address'];
	$city = $rowpay_data1['city'];
	$order_place = $rowpay_data1['order_place'];
	$pin_code = $rowpay_data1['pin_code'];
	$quantity = $rowpay_data1['quantity']; 
	$quantity_data2 = explode(',', $quantity);
	// $quantity_data = implode(",", $quantity_data2);
	$quantity_data = array_sum($quantity_data2);
	
	$cart_id = $rowpay_data1['cart_id'];
	$cart_id2 = explode(",", $cart_id);
	$cart_id3 = implode("','", $cart_id2);
	
	$get_p_id = "SELECT product_id From cart_items where sno IN ('$cart_id3')";	
	$rsltqry_p_id = mysqli_query($con, $get_p_id);
    while($row_p_id = mysqli_fetch_array($rsltqry_p_id)){
		$product_id[] = $row_p_id['product_id'];
	}	
	$product_id2 = implode("','", $product_id);
	
	$get_p_id2 = "SELECT product_title From products where id IN ('$product_id2') group by product_title";	
	$rsltqry_p_id2 = mysqli_query($con, $get_p_id2);
	$product_title = [];
    while($row_p_id2 = mysqli_fetch_array($rsltqry_p_id2)){
		$product_title[] = $row_p_id2['product_title'];
	}
	
	$product_title2 = implode(", ", $product_title);
	
	if($user_done == ''){
	$subject2 = "MALS - Fees Paid Successfully";
	$to2 = $email;
	$msg1 = "<b>Dear $full_name,</b><br>";
	$msg2 = "<p>Thank you for shopping at MALS. Please find your payment details below: </p>";
	$msg3 = "<p>Amount is Rs.$orderAmount </p>";
	$msg4 = "<p>Payment Status is : $txStatus </p>";
	$msg5 = "<p>Your Reference ID is : $referenceId </p>";
	$msg6 = "<p>Your Order ID is : $orderId </p>";
	$msg7 = "<p>Product Name: $product_title2 </p>";
	$msg8 = "<p>Quantity : $quantity_data</p>";
	$msg9 = "<p>Address : $address,$city,$pin_code </p>";
	$msg10 = "<p>Order Place : $order_place </p>";
	$msg11 = "<p>For any further information / queries, please contact us at +91 750 822 5311.</p>";
	$msg12 = "<p>We wish you all the best.</p>";
	$msg13 = "<p>Thanks,</p>";
	$msg14 = "<p>Team MALS</p>";
	$message2 = $msg1.''.$msg2.''.$msg3.''.$msg4.''.$msg5.''.$msg6.''.$msg7.''.$msg8.''.$msg9.''.$msg10.''.$msg11.''.$msg12.''.$msg13.''.$msg14;
	
	$headers2 = "MIME-Version: 1.0" . "\r\n";
	$headers2 .= "Content-type:text/html;charset=UTF-8" . "\r\n";
	$headers2 .= 'From: MALS <support@mals.co.in>'. "\r\n";
	
	mail ($to2,$subject2,$message2,$headers2);


	$subject3 = "MALS - Fees Paid Successfully($full_name, $mobile)";
	$to3 = 'makealifesweet@gmail.com';
	$msg42 = "<p>A new shopping has been created on MALS find the details below: </p>";
	$msg43 = "<p>Username: $full_name </p>";
	$msg44 = "<p>Email Address: $email </p>";
	$msg45 = "<p>Product Name: $product_title2 </p>";
	$msg46 = "<p>Quantity : $quantity_data</p>";
	$msg47 = "<p>Amount: Rs. $orderAmount </p>";
	$msg48 = "<p>Payment Status : $txStatus </p>";
	$msg49 = "<p>Reference ID : $referenceId </p>";
	$msg50 = "<p>Order ID is : $orderId </p>";
	$msg51 = "<p>Address : $address,$city,$pin_code </p>";
	$msg52 = "<p>Order Place : $order_place </p>";
	$message3 = $msg42.''.$msg43.''.$msg44.''.$msg45.''.$msg46.''.$msg47.''.$msg48.''.$msg49.''.$msg50.''.$msg51.''.$msg52;

	$headers3 = "MIME-Version: 1.0" . "\r\n";
	$headers3 .= "Content-type:text/html;charset=UTF-8" . "\r\n";
	$headers3 .= 'From: no-reply <support@mals.co.in>'. "\r\n";
	$headers3 .= 'Cc: sanjiv28890@gmail.com' . "\r\n";
	
	mail ($to3,$subject3,$message3,$headers3);

	}
	
	$update_query = "UPDATE `payment_status` SET `complete`='1' WHERE payment_request_id='$orderId'";
	mysqli_query($con, $update_query);
	
	$update_query1 = "UPDATE `delivery_details` SET `payment_status`='Complete' WHERE payment_request_id='$orderId'";
	mysqli_query($con, $update_query1);
	
	$update_cart_item = "update cart_items set cart_status='1' where sno IN ('$cart_id3')";
	mysqli_query($con, $update_cart_item);
	
	 ?>
	<section class="container-fluid users_form">
	<div class="container pt-5">
    <div class="row">
	<p class="col-12" style="padding-bottom:20px; text-align:center; font-size:16px; font-weight:500;"><span style="text-align:center;"><i style="font-size: 26px;
    background: green;
    color: #fff;
    height: 60px;
    width: 60px;
    border-radius: 50%;
    line-height: 60px;" class="fa fa-check" aria-hidden="true"></i></span></p>
	  <div class=" p-0 col-lg-6 offset-lg-3 mb-4">
		<div class="table-responsive">
		<table class="table table-bordered table-hover table-striped">
			<tbody>
			      <tr>
			        <td>Order ID</td>
			        <td><?php echo $orderId; ?></td>
			      </tr>
			      <tr>
			        <td>Order Amount</td>
			        <td><?php echo $orderAmount; ?></td>
			      </tr>
			      <tr>
			        <td>Reference ID</td>
			        <td><?php echo $referenceId; ?></td>
			      </tr>
			      <tr>
			        <td>Transaction Status</td>
			        <td><?php echo $txStatus; ?></td>
			      </tr>
			      <tr>
			        <td>Payment Mode </td>
			        <td><?php echo $paymentMode; ?></td>
			      </tr>
			      <tr>
			        <td>Message</td>
			        <td><?php echo $txMsg; ?></td>
			      </tr>
			      <tr>
			        <td>Transaction Time</td>
			        <td><?php echo $txTime; ?></td>
			      </tr>
			    </tbody>
			</table>
		
	</div>
	</div>
	</div>
	</div>
	</section>
	<?php   
	} else {
			
	$update_query = "UPDATE `payment_status` SET `pay_status`= 'Failed', `payment_mode`= '$paymentMode', `payment_id`='$referenceId' WHERE payment_request_id='$orderId'";
	mysqli_query($con, $update_query);
	
	$update_query2 = "UPDATE `delivery_details` SET `payment_status`='Failed' WHERE payment_request_id='$orderId'";
	mysqli_query($con, $update_query2);
	 
	 ?>
			
	<section class="container-fluid users_form">
	<div class="container pt-5">
    <div class="row">
	<p class="col-12" style="padding-bottom:20px; text-align:center; font-size:16px; font-weight:500;">Signature Verification failed</p>
	  <div class=" p-0 col-lg-6 offset-lg-3 mb-4">
		<div class="table-responsive">
		<table class="table table-bordered table-hover table-striped">
			    <tbody>
			      <tr>
			        <td>Order ID</td>
			        <td><?php echo $orderId; ?></td>
			      </tr>
			      <tr>
			        <td>Order Amount</td>
			        <td><?php echo $orderAmount; ?></td>
			      </tr>
			      <tr>
			        <td>Reference ID</td>
			        <td><?php echo $referenceId; ?></td>
			      </tr>
			      <tr>
			        <td>Transaction Status</td>
			        <td><?php echo $txStatus; ?></td>
			      </tr>
			      <tr>
			        <td>Payment Mode </td>
			        <td><?php echo $paymentMode; ?></td>
			      </tr>
			      <tr>
			        <td>Message</td>
			        <td><?php echo $txMsg; ?></td>
			      </tr>
			      <tr>
			        <td>Transaction Time</td>
			        <td><?php echo $txTime; ?></td>
			      </tr>
			    </tbody>
			</table>
		</div>
	</div>
	</div>
	</div>
	</section>
	
	<?php	
	 	}
	 ?>

<?php include("../footer.php"); ?>



