<?php
include("db.php");
date_default_timezone_set("Asia/Kolkata");
header('Content-type: application/json');
$datetime = date('Y-m-d');
$datetime_at = date('Y-m-d H:i:s');

if($_GET['tag'] == "countrytostate") {
	$pt = $_POST['country'];
	$get_query = mysqli_query($con, "SELECT DISTINCT state_name FROM country_state_city where country_name='$pt' AND state_name!='' AND status='1'");
	while($rowstr = mysqli_fetch_array($get_query)){
		$pn = $rowstr['state_name'];		
		$res1[] = array(
		    'state_name' => $pn
		);
	}
	$list = isset($res1) ? $res1 : '';
	echo json_encode($list);	
}

if($_GET['tag'] == "statetocity") {
	$pt = $_POST['country'];
	$pt2 = $_POST['state'];
	$get_query = mysqli_query($con, "SELECT DISTINCT city_name FROM country_state_city where country_name='$pt' AND state_name='$pt2' AND city_name!='' AND status='1'");
	while($rowstr = mysqli_fetch_array($get_query)){
		$pn = $rowstr['city_name'];		
		$res1[] = array(
		    'city_name' => $pn
		);
	}
	$list = isset($res1) ? $res1 : '';
	echo json_encode($list);	
}

if($_GET['tag'] == "acntList") {
	$sponserid = $_POST['sponserid'];
	$bnkname = $_POST['bnkname'];
	$nameIdClass = $_POST['nameIdClass'];
	$flag = 0;
	
	if(!empty($sponserid)){
		$flag = 1;
		if($sponserid > 0 ){
			$sponserid1 = "username = '$sponserid'";
		}else{
			$sponserid1 = "username = '$sponserid'";
		}
	}else{
		$sponserid1 = '';
	}	
	
	if(!empty($nameIdClass)){
		if($nameIdClass > 0 ){
			if ($flag == 1){
				$nameId1 = "AND (username LIKE '%$nameIdClass%') OR (associate_name LIKE '%$nameIdClass%')";
			}else{
				$nameId1 = "(username LIKE '%$nameIdClass%') OR (associate_name LIKE '%$nameIdClass%')";
				 $flag = 1;
			}
		}else{
			if ($flag == 1){
				$nameId1 = "AND (username LIKE '%$nameIdClass%') OR (associate_name LIKE '%$nameIdClass%')";
			}else{
				$nameId1 = "(username LIKE '%$nameIdClass%') OR (associate_name LIKE '%$nameIdClass%')";
				 $flag = 1;
			}			
		}
	}else{
		$nameId1 = '';
	}	
	
	if(!empty($bnkname)){
		if($bnkname > 0 ){
			if ($flag == 1){
				$bnkname1 = "AND bank_name = '$bnkname'";
			}else{
				$bnkname1 = "bank_name = '$bnkname'";
				 $flag = 1;
			}
		}else{
			if ($flag == 1){
				$bnkname1 = "AND bank_name = '$bnkname'";
			}else{
				$bnkname1 = "bank_name = '$bnkname'";
				 $flag = 1;
			}
			
		}
	}else{
		$bnkname1 = '';
	}
		
	$queyFind = "SELECT sno,username,account_no,account_holder_name,bank_name,branch_name,ifsc FROM users where $sponserid1 $bnkname1 $nameId1";
	$get_query = mysqli_query($con, $queyFind);
	while($rowstr = mysqli_fetch_array($get_query)){
		$sno = $rowstr['sno'];		
		$username = $rowstr['username'];		
		$account_no = $rowstr['account_no'];
		$account_holder_name = $rowstr['account_holder_name'];
		$bank_name = $rowstr['bank_name'];
		$branch_name = $rowstr['branch_name'];
		$ifsc = $rowstr['ifsc'];
		
		$btnedit = '<a href="../associate/edituser.php?snoid='.base64_encode($sno).'">Edit</a>';
		
		$res1[] = array(
		    'spnid' => $username,
		    'account_no' => $account_no,
		    'ahn' => $account_holder_name,
		    'bank_name' => $bank_name,
		    'branch_name' => $branch_name,
		    'ifsc' => $ifsc,
		    'btnedit' => $btnedit
		);
	
	}
	
	$list = isset($res1) ? $res1 : '';
	echo json_encode($list);	
}

if($_GET['tag'] == "sponserId") {
$searchTerm = $_GET['term'];    
$query = $con->query("SELECT DISTINCT username FROM users WHERE type!='Super_admin' AND username = '$searchTerm'");
// $query = $con->query("SELECT DISTINCT username FROM users WHERE type!='Super_admin' AND username LIKE '%".$searchTerm."%' limit 60");
    while ($row = $query->fetch_assoc()) {
        $data[] = $row['username'];
    }

$list = isset($data) ? $data : '';
echo json_encode($list);

}

if($_GET['tag'] == "parantIdS") {
$searchTerm = $_GET['term'];    
$query = $con->query("SELECT DISTINCT username FROM users WHERE type!='Super_admin' AND username = '$searchTerm'");
    while ($row = $query->fetch_assoc()) {
		// $an = $row['associate_name'];
		// $un = $row['username'];
        // $data[] = $an.'('.$un.')';
		 $data[] = $row['username'];
    }

$list = isset($data) ? $data : '';
echo json_encode($list);

}

if($_GET['tag'] == "getnameParant"){
	$searchTerm = $_POST['uname'];    
	$query = $con->query("SELECT DISTINCT associate_name FROM users WHERE type!='Super_admin' AND username = '$searchTerm'");
	$row = $query->fetch_assoc();
	$associate_name = $row['associate_name'];
	
	$res1[] = array(
		'prnt_username' => $associate_name
	);
	
	$list = isset($res1) ? $res1 : '';
	echo json_encode($list);
}

if($_GET['tag'] == "AdminsponserId") {
$searchTerm = $_GET['term'];
$query = $con->query("SELECT DISTINCT username FROM users WHERE type!='Super_admin' AND username LIKE '%".$searchTerm."%' limit 60");
    while ($row = $query->fetch_assoc()) {
        $data[] = $row['username'];
    }

$list = isset($data) ? $data : '';
echo json_encode($list);

}

if($_GET['tag'] == "AdminparantIdS") {
$searchTerm = $_GET['term'];    
$query = $con->query("SELECT DISTINCT username FROM users WHERE type!='Super_admin' AND username LIKE '%".$searchTerm."%' limit 60");
    while ($row = $query->fetch_assoc()) {
		 $data[] = $row['username'];
    }

$list = isset($data) ? $data : '';
echo json_encode($list);

}

if($_GET['tag'] == "contactInset") {
	$your_name = $_POST['your_name'];
	$your_email = $_POST['your_email'];
	$your_phone = $_POST['your_phone'];
	$your_message = $_POST['your_message'];
	
	$queyFind = "INSERT INTO `contactus` (`your_name`, `your_email`, `your_phone`, `your_message`, `created`) VALUES ('$your_name', '$your_email', '$your_phone', '$your_message', '$datetime_at');";
	$get_query = mysqli_query($con, $queyFind);
	
	$body = '<table>
	<tr><th>Name: </th><td>'.$your_name.'</td></tr>
	<tr><th>Email: </th><td>'.$your_email.'</td></tr>
	<tr><th>Phone No.: </th><td>'.$your_phone.'</td></tr>
	<tr><th>Message: </th><td>'.$your_message.'</td></tr>
	<tr><th>Date: </th><td>'.$datetime_at.'</td></tr>
	</table>';

	
	// $headers = "MIME-Version: 1.0" . "\r\n";
	// $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
	// $headers .= 'From: <support@makealifesweet.com>' . "\r\n";
	// $headers .= 'Cc: myboss@example.com' . "\r\n";
	
	$headers = "MIME-Version: 1.0" . "\r\n";
	$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
	
	$subject = "Contact Us Form - ($your_name, $your_phone)";
	$to = 'support@mals.co.in';
	
	$headers .= 'From: MALS <support@mals.co.in>' . "\r\n";
	$headers .= 'Cc: sanjiv28890@gmail.com' . "\r\n";
	

	mail($to,$subject,$body,$headers);
	
	echo '1';
}


if($_GET['tag'] == "getdelivered") {	
	$getid = $_POST['getid'];    
	$shirt_delivered_date = $_POST['shirt_delivered_date'];    
	$courier_type = $_POST['courier_type'];    
	$courier_company = $_POST['courier_company'];    
	$courier_mobile = $_POST['courier_mobile'];    
	$update2 = "update `users` set `shirt_delivered_date`='$shirt_delivered_date', `courier_type`='$courier_type', `courier_company`='$courier_company', `courier_mobile`='$courier_mobile', `courier_datetime`='$datetime_at' where `sno`='$getid'";
	mysqli_query($con, $update2);
	echo '1';
}

if($_GET['tag'] == "getcolorChange") {	
	$getid = $_POST['getid'];    
	$getval = $_POST['getval'];    
	$update2 = "update `users` set `id_red_or_green`='$getval' where `sno`='$getid'";
	mysqli_query($con, $update2);
}

if($_GET['tag'] == "payoutList") {
	$income_name = $_POST['getval'];
	
	$result1 = "SELECT sno,username,account_no,account_holder_name FROM users WHERE (username = '$income_name' OR account_no = '$income_name')";
	$getusers = mysqli_query($con, $result1);
	$rowusers = mysqli_fetch_assoc($getusers);
	$snoid = mysqli_real_escape_string($con, $rowusers['sno']);
	$username = mysqli_real_escape_string($con, $rowusers['username']);
	$account_no = mysqli_real_escape_string($con, $rowusers['account_no']);
	$account_holder_name = mysqli_real_escape_string($con, $rowusers['account_holder_name']);

	$result_payout_Direct = "SELECT amount FROM payout_passbook_list WHERE income_name='Direct Income' AND user_id='$snoid'";
		$get_payout_Direct = mysqli_query($con, $result_payout_Direct);
		$Direct_amount = 0;
		while ($row_payout_Direct = mysqli_fetch_assoc($get_payout_Direct)) {
			$Direct_amount += mysqli_real_escape_string($con, $row_payout_Direct['amount']);
		}

		$result_payout_Level = "SELECT amount FROM payout_passbook_list WHERE income_name='Level Income' AND user_id='$snoid'";
		$get_payout_Level = mysqli_query($con, $result_payout_Level);
		$Level_amount = 0;
		while ($row_payout_Level = mysqli_fetch_assoc($get_payout_Level)) {
			$Level_amount += mysqli_real_escape_string($con, $row_payout_Level['amount']);
		}

		$result_payout_Other = "SELECT amount FROM payout_passbook_list WHERE income_name='Other Income' AND user_id='$snoid'";
		$get_payout_Other = mysqli_query($con, $result_payout_Other);
		$Other_amount = 0;
		while ($row_payout_Other = mysqli_fetch_assoc($get_payout_Other)) {
			$Other_amount += mysqli_real_escape_string($con, $row_payout_Other['amount']);
		}


	
	$getallList = "<div class='col-sm-12'><div class='col-sm-6'><p><b>User Id : </b>$username</p><p><b>A/C No. : </b>$account_no</p><p><b>Name : </b>$account_holder_name</p></div><div class='col-sm-6'><p><b>Total Direct Income : </b><i class='fas fa-rupee-sign'></i>$Direct_amount</p><p><b>Total Level Income : </b><i class='fas fa-rupee-sign'></i>$Level_amount</p><p><b>Total Other Income : </b><i class='fas fa-rupee-sign'></i>$Other_amount</p></div></div>";	
	
	$res1[] = array(
		'snoid' => $snoid,	    
		'getallList' => $getallList	    
	);
		
	$list = isset($res1) ? $res1 : '';
	echo json_encode($list);
}

if($_GET['tag'] == "payoutListUser") {
	$income_name = $_POST['getval'];
	
	$result1 = "SELECT sno FROM users WHERE (username = '$income_name' OR account_no = '$income_name')";
	$getusers = mysqli_query($con, $result1);
	$rowusers = mysqli_fetch_assoc($getusers);
	$user_sno = mysqli_real_escape_string($con, $rowusers['sno']);	
	
	$result_payout = "SELECT * FROM payout_passbook_list WHERE user_id='$user_sno'";
	$get_payout = mysqli_query($con, $result_payout);
	$amount_qty = 0;
	while ($row_payout = mysqli_fetch_assoc($get_payout)) {
		$level = mysqli_real_escape_string($con, $row_payout['level']);
		$income_name = mysqli_real_escape_string($con, $row_payout['income_name']);
		$amount = mysqli_real_escape_string($con, $row_payout['amount']);
		$amount_qty += mysqli_real_escape_string($con, $row_payout['amount']);
		$datetime_1 = mysqli_real_escape_string($con, $row_payout['datetime']);
		$datetime = date('d F Y, h:i A', strtotime($datetime_1));
	
	$allpaylist = "<tr><td>$level</td><td>$income_name</td><td>$amount</td><td>$datetime</td></tr>";
	
		$res1[] = array(
			'allpaylist' => $allpaylist	    
		);
	}

	$allpaylist = "<tr>
		<td colspan='2' class='text-right pr-5'><b>Total</b></td>
		<td><i class='fas fa-rupee-sign'></i>$amount_qty</td>
		<td></td>
	</tr>";

	$res1[] = array(
			'allpaylist' => $allpaylist	    
	);
		
	$list = isset($res1) ? $res1 : '';
	echo json_encode($list);
}


if($_GET['tag'] == "deleteIdList") {
	$income_name = $_POST['getval'];
	
	$result1 = "SELECT sno,associate_name,username,created FROM users WHERE (username = '$income_name' OR account_no = '$income_name')";
	$getusers = mysqli_query($con, $result1);
	while ($rowusers = mysqli_fetch_assoc($getusers)) {
	$snoid = mysqli_real_escape_string($con, $rowusers['sno']);
	$username = mysqli_real_escape_string($con, $rowusers['username']);
	$associate_name = mysqli_real_escape_string($con, $rowusers['associate_name']);
	$created = mysqli_real_escape_string($con, $rowusers['created']);
	$created_datetime_1 = date("d/m/Y H:i:s A",strtotime($created));
	
	$delbtn = '<a href="javascript::void(0)" class="btn btn-success deldiv" data-id='.$snoid.'>Delete</a>';
	
	$res1[] = array(	    
		'snoid' => $snoid,
		'username' => $username,
		'associate_name' => $associate_name,
		'created' => $created_datetime_1,    
		'delbtn' => $delbtn    
	);
	}
		
	$list = isset($res1) ? $res1 : '';
	echo json_encode($list);
}

if($_GET['tag'] == "deleteId") {
	$sono = $_POST['getid'];
	
	$result1 = "DELETE FROM `users` WHERE `sno` = '$sono'";
	mysqli_query($con, $result1);
	echo '1';
}

if($_GET['tag'] == "logsList") {
	$income_name = $_POST['getval'];
	
	$resultAssociate = "SELECT * FROM login_time WHERE  (username = '$income_name' OR mobile = '$income_name') order by sno desc";
	
	$getusers = mysqli_query($con, $resultAssociate);
	while ($rowusers = mysqli_fetch_assoc($getusers)) {
	$username = mysqli_real_escape_string($con, $rowusers['username']);
	$associate_name = mysqli_real_escape_string($con, $rowusers['associate_name']);
	$mobile = mysqli_real_escape_string($con, $rowusers['mobile']);
	$created = mysqli_real_escape_string($con, $rowusers['created_datetime']);
	$created_datetime_1 = date("d/m/Y H:i:s A",strtotime($created));
	
	$res1[] = array(
		'username' => $username,
		'associate_name' => $associate_name,
		'mobile' => $mobile,    
		'created' => $created_datetime_1  
	);
	}
		
	$list = isset($res1) ? $res1 : '';
	echo json_encode($list);
}

if($_GET['tag'] == "prod_id") {
	$sono = $_POST['getid'];
	
	$delete_foldr=mysqli_query($con, "SELECT * FROM products where id='$sono'");
	$dltlist = mysqli_fetch_assoc($delete_foldr);
	$product_img1 = $dltlist['product_img1'];
	$product_img2 = $dltlist['product_img2'];
	$product_img3 = $dltlist['product_img3'];
	$product_graph_img = $dltlist['product_graph_img'];
	
	if(!empty($product_img1)){
		unlink("uploads/products/$product_img1");
	}
	if(!empty($product_img2)){
		unlink("uploads/products/$product_img2");
	}
	if(!empty($product_img3)){
		unlink("uploads/products/$product_img3");
	}
	if(!empty($product_graph_img)){
		unlink("uploads/products/$product_graph_img");
	}	
	
	$result1 = "DELETE FROM `products` WHERE `id` = '$sono'";
	mysqli_query($con, $result1);
	echo '1';
	die;
}

if($_GET['tag'] == "newProductAE"){
	$pid = $_POST['pid'];
	$type = $_POST['type'];
	$product_title = $_POST['product_title'];
	$product_sub_ttile = $_POST['product_sub_ttile'];	
	$product_price1 = $_POST['product_price1'];	
	$product_price2 = $_POST['product_price2'];	
	$product_price3 = $_POST['product_price3'];	
	$description = $_POST['description'];	

	$name1 = $_FILES['product_img1']['name'];
	$tmp1 = $_FILES['product_img1']['tmp_name'];
	
	$name2 = $_FILES['product_img2']['name'];
	$tmp2 = $_FILES['product_img2']['tmp_name'];
	
	$name3 = $_FILES['product_img3']['name'];
	$tmp3 = $_FILES['product_img3']['tmp_name'];
	
	$name4 = $_FILES['product_graph_img']['name'];
	$tmp4 = $_FILES['product_graph_img']['tmp_name'];

	$firstname = str_replace(' ', '', $product_title);	

	if(empty($pid)){
								
		$extension = pathinfo($name1, PATHINFO_EXTENSION);				
		if($extension=='JPG' || $extension=='jpg' || $extension=='jpeg' || $extension=='JPEG' || $extension=='png' || $extension=='PNG'){
			$img_name1 = $type.'_'.$firstname.'_1'.date('is').'.'.$extension;
			move_uploaded_file($tmp1, 'uploads/products/'.$img_name1);
		}else{
			echo '2';
			exit;			
		}
		
		if(!empty($name2)){
		$extension2 = pathinfo($name2, PATHINFO_EXTENSION);				
		if($extension2=='JPG' || $extension2=='jpg' || $extension2=='jpeg' || $extension2=='JPEG' || $extension2=='png' || $extension2=='PNG'){
			$img_name2 = $type.'_'.$firstname.'_2'.date('is').'.'.$extension2;
			move_uploaded_file($tmp2, 'uploads/products/'.$img_name2);
		}else{
			echo '2';
			exit;			
		}
		}else{
			$img_name2 = '';
		}
		
		if(!empty($name3)){
		$extension3 = pathinfo($name3, PATHINFO_EXTENSION);				
		if($extension3=='JPG' || $extension3=='jpg' || $extension3=='jpeg' || $extension3=='JPEG' || $extension3=='png' || $extension3=='PNG'){
			$img_name3 = $type.'_'.$firstname.'_3'.date('is').'.'.$extension3;
			move_uploaded_file($tmp3, 'uploads/products/'.$img_name3);
		}else{
			echo '2';
			exit;			
		}
		}else{
			$img_name3 = '';
		}
		
		if(!empty($name4)){
		$extension4 = pathinfo($name4, PATHINFO_EXTENSION);				
		if($extension4=='JPG' || $extension4=='jpg' || $extension4=='jpeg' || $extension4=='JPEG' || $extension4=='png' || $extension4=='PNG'){
			$img_name4 = $type.'_'.$firstname.'_4'.date('is').'.'.$extension4;
			move_uploaded_file($tmp4, 'uploads/products/'.$img_name4);
		}else{
			echo '2';
			exit;			
		}
		}else{
			$img_name4 = '';
		}
		
		$created_at = date('Y-m-d H:i:s');
	
		$inserted = "INSERT INTO `products` (`type`, `product_title`, `product_sub_ttile`, `product_img1`, `product_img2`, `product_img3`, product_price1, `product_price2`, `product_price3`, `description`, `product_graph_img`, `status`, `created_at`) VALUES ('$type', '$product_title', '$product_sub_ttile', '$img_name1', '$img_name2', '$img_name3', '$product_price1', '$product_price2', '$product_price3', '$description', '$img_name4', '1', '$created_at')";
		mysqli_query($con, $inserted);	  
	
		echo '1';
		exit;
	
	}else{

		$delete_foldr=mysqli_query($con, "SELECT * FROM products where id='$pid'");
		$dltlist = mysqli_fetch_assoc($delete_foldr);
		$product_img1 = $dltlist['product_img1'];
		$product_img2 = $dltlist['product_img2'];
		$product_img3 = $dltlist['product_img3'];
		$product_graph_img = $dltlist['product_graph_img'];

		if(!empty($name1)){
		$extension1 = pathinfo($name1, PATHINFO_EXTENSION);				
		if($extension1=='JPG' || $extension1=='jpg' || $extension1=='jpeg' || $extension1=='JPEG' || $extension1=='png' || $extension1=='PNG'){
			if(!empty($product_img1)){
				unlink("uploads/products/$product_img1");
			}
			$img_name1 = $type.'_'.$firstname.'_1'.date('is').'.'.$extension1;
			move_uploaded_file($tmp1, 'uploads/products/'.$img_name1);
		}else{
			echo '2';
			exit;			
		}
		}else{
			$img_name1 = $product_img1;
		}
		
		if(!empty($name2)){
		$extension2 = pathinfo($name2, PATHINFO_EXTENSION);				
		if($extension2=='JPG' || $extension2=='jpg' || $extension2=='jpeg' || $extension2=='JPEG' || $extension2=='png' || $extension2=='PNG'){
			if(!empty($product_img2)){
				unlink("uploads/products/$product_img2");
			}
			$img_name2 = $type.'_'.$firstname.'_2'.date('is').'.'.$extension2;
			move_uploaded_file($tmp2, 'uploads/products/'.$img_name2);
		}else{
			echo '2';
			exit;			
		}
		}else{
			$img_name2 = $product_img2;
		}
		
		if(!empty($name3)){
		$extension3 = pathinfo($name3, PATHINFO_EXTENSION);				
		if($extension3=='JPG' || $extension3=='jpg' || $extension3=='jpeg' || $extension3=='JPEG' || $extension3=='png' || $extension3=='PNG'){
			if(!empty($product_img3)){
				unlink("uploads/products/$product_img3");
			}
			$img_name3 = $type.'_'.$firstname.'_3'.date('is').'.'.$extension3;
			move_uploaded_file($tmp3, 'uploads/products/'.$img_name3);
		}else{
			echo '2';
			exit;			
		}
		}else{
			$img_name3 = $product_img3;
		}
		
		if(!empty($name4)){
		$extension4 = pathinfo($name4, PATHINFO_EXTENSION);				
		if($extension4=='JPG' || $extension4=='jpg' || $extension4=='jpeg' || $extension4=='JPEG' || $extension4=='png' || $extension4=='PNG'){
			if(!empty($product_graph_img)){
				unlink("uploads/products/$product_graph_img");
			}
			$img_name4 = $type.'_'.$firstname.'_4'.date('is').'.'.$extension4;
			move_uploaded_file($tmp4, 'uploads/products/'.$img_name4);
		}else{
			echo '2';
			exit;			
		}
		}else{
			$img_name4 = $product_graph_img;
		}

		$uqry = "update `products` set `type`='$type', `product_title`='$product_title', `product_sub_ttile`='$product_sub_ttile', product_img1='$img_name1', `product_img2`='$img_name2', `product_img3`='$product_img3', `product_price1`='$product_price1', `product_price2`='$product_price2', `product_price3`='$product_price3', `description`='$description', `product_graph_img`='$img_name4' where `id`='$pid'";
		$update_query = mysqli_query($con, $uqry);

		echo '1';
		exit;
	}

}

if($_GET['tag'] == "newCatAE"){
	$pid = $_POST['pid'];
	$name = $_POST['name'];
	
	$name4 = $_FILES['cat_img']['name'];
	$tmp4 = $_FILES['cat_img']['tmp_name'];
	
	$firstname = str_replace(' ', '_', $name);
	$created_at = date('Y-m-d H:i:s');
	
	if(empty($pid)){
		
	if(!empty($name4)){
		$extension4 = pathinfo($name4, PATHINFO_EXTENSION);				
		if($extension4=='JPG' || $extension4=='jpg' || $extension4=='jpeg' || $extension4=='JPEG' || $extension4=='png' || $extension4=='PNG'){
			$img_name4 = 'Cat_'.$firstname.'_'.date('is').'.'.$extension4;
			move_uploaded_file($tmp4, 'uploads/products/'.$img_name4);
		}else{
			echo '2';
			exit;			
		}
	}else{
		$img_name4 = '';
	}
	
	$inserted = "INSERT INTO `categories` (`name`, `image`, `name_link`, `created`) VALUES ('$name', '$img_name4', '$firstname', '$created_at')";
		mysqli_query($con, $inserted);	  
	
	echo '1';
	exit;
	
	}else{

		$delete_foldr=mysqli_query($con, "SELECT image FROM categories where id='$pid'");
		$dltlist = mysqli_fetch_assoc($delete_foldr);
		$product_img1 = $dltlist['image'];

		if(!empty($name4)){
		$extension1 = pathinfo($name4, PATHINFO_EXTENSION);				
		if($extension1=='JPG' || $extension1=='jpg' || $extension1=='jpeg' || $extension1=='JPEG' || $extension1=='png' || $extension1=='PNG'){
			if(!empty($product_img1)){
				unlink("uploads/products/$product_img1");
			}
			$img_name1 = 'Cat_'.$firstname.'_'.date('is').'.'.$extension1;
			move_uploaded_file($tmp4, 'uploads/products/'.$img_name1);
		}else{
			echo '2';
			exit;			
		}
		}else{
			$img_name1 = $product_img1;
		}
		
		
		 $uqry = "update `categories` set `name`='$name', `image`='$img_name1', `name_link`='$firstname', created='$created_at' where `id`='$pid'";
		$update_query = mysqli_query($con, $uqry);

		echo '1';
		exit;
	}

}


// if($_GET['tag'] == "payoutListUser") {
	// $income_name = $_POST['getval'];
	
	// $result1 = "SELECT sno FROM users WHERE (username = '$income_name' OR account_no = '$income_name')";
	// $getusers = mysqli_query($con, $result1);
	// $rowusers = mysqli_fetch_assoc($getusers);
	// $user_sno = mysqli_real_escape_string($con, $rowusers['sno']);
	
	// $result_payout = "SELECT * FROM plan_payout_passbook WHERE status = '1'";
	// $get_payout = mysqli_query($con, $result_payout);
	// while ($row_payout = mysqli_fetch_assoc($get_payout)) {
		// $level = mysqli_real_escape_string($con, $row_payout['level']);
		// $direct_income = mysqli_real_escape_string($con, $row_payout['direct_income']);
		// $level_income = mysqli_real_escape_string($con, $row_payout['level_income']);
		// $other_income = mysqli_real_escape_string($con, $row_payout['other_income']);
		
		// $rslt_payout = "SELECT * FROM payout_passbook_list WHERE user_id = '$user_sno' AND level = '$level' AND income_name='direct_income'";
		// $qry_rslt = mysqli_query($con, $rslt_payout);				
		
		// if(mysqli_num_rows($qry_rslt)){
			// $direct_income_1 = "<input type='checkbox' class='classMain' getLevel='$level' data-val='direct_income' value='$direct_income' checked>";
		// }else{
			// if(!empty($direct_income)){
				// $direct_income_1 = "<input type='checkbox' class='classMain' getLevel='$level' data-val='direct_income' value='$direct_income'>";
			// }else{
				// $direct_income_1 = "";
			// }
		// }
		
		// $rslt_payout_1 = "SELECT * FROM payout_passbook_list WHERE user_id = '$user_sno' AND level = '$level' AND income_name='level_income'";
		// $qry_rslt_1 = mysqli_query($con, $rslt_payout_1);
		
		// if(mysqli_num_rows($qry_rslt_1)){
			// $level_income_1 = "<input type='checkbox' class='classMain' getLevel='$level' data-val='level_income' value='$level_income' checked>";
		// }else{
			// if(!empty($level_income)){
				// $level_income_1 = "<input type='checkbox' class='classMain' getLevel='$level' data-val='level_income' value='$level_income'>";
			// }else{
				// $level_income_1 = "";
			// }
		// }
		
		// $allpaylist = "<tr><td>$level</td><td>$direct_income $direct_income_1</td><td>$level_income $level_income_1</td><td><input type='text'></td></tr>";
	
		// $res1[] = array(
			// 'allpaylist' => $allpaylist	    
		// );
	// }
		
	// $list = isset($res1) ? $res1 : '';
	// echo json_encode($list);
// }
?>