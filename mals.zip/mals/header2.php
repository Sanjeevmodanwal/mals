<!doctype html>
<?php 
ob_start();
if(!isset($_SESSION)){
	 session_start();
}
date_default_timezone_set("Asia/Kolkata");
include("db.php");
if(isset($_SESSION['sno']) && !empty($_SESSION['sno'])){
$storeId = $_SESSION['sno'];
$resultQry = mysqli_query($con,"SELECT sno,type,associate_name,username FROM users WHERE sno = '$storeId'");
$rowftech = mysqli_fetch_assoc($resultQry);
	$idgt = $rowftech['sno'];
	$rolegt = $rowftech['type'];
	$associate_name12 = $rowftech['associate_name'];
	$username12 = $rowftech['username'];
}else{
	$idgt = '';
	$rolegt = '';
	$associate_name12 = '';
	$username12 = '';
}
?>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">
  <title>Mals - Dashboard</title>
  <!-- Custom fonts for this template-->
  <script src="../backend/vendor/jquery/jquery.min.js"></script>
  <link href="../backend/vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
  <!-- Page level plugin CSS-->
  <link href="../backend/vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">
  <!-- Custom styles for this template-->
  <link href="../backend/css/sb-admin.css" rel="stylesheet">
  
  <script src="../js/code-jquery-ui.js"></script>
  <link rel="stylesheet" href="../css/code-jquery-ui.css">
</head>
<style>
.showLoading {
	background: url("../images/loading_mals.gif") no-repeat scroll center center transparent;
	background-color: rgba(150,150,150,.5);
	width: 100%;
	height: 100%;
	vertical-align: middle;
	z-index: 100 !important;
	position: fixed;
	top: 0;
	left: 0;
	display:none;
}
</style>

<script src="../js/code-jquery-ui.js"></script>
<script>	
  $(function() {
    $(".datepicker123").datepicker({	  
		dateFormat: 'yy-mm-dd', 
		changeMonth: true, 
		changeYear: true,
		yearRange: "-80:+0"
    });
  });
</script>

<body id="page-top">

  <nav class="navbar navbar-expand navbar-dark bg-dark static-top">

    <a class="navbar-brand mr-1" href="#">Mals</a>

    <button class="btn btn-link btn-sm text-white order-1 order-sm-0" id="sidebarToggle" href="#">
      <i class="fas fa-bars"></i>
    </button>

    <!-- Navbar Search -->
    <form class="d-none d-md-inline-block form-inline ml-auto mr-0 mr-md-3 my-2 my-md-0">
      <!--div class="input-group">
        <input type="text" class="form-control" placeholder="Search for..." aria-label="Search" aria-describedby="basic-addon2">
        <div class="input-group-append">
          <button class="btn btn-primary" type="button">
            <i class="fas fa-search"></i>
          </button>
        </div>
      </div-->
    </form>

    <!-- Navbar -->
    <ul class="navbar-nav ml-auto ml-md-0">
            
      <li class="nav-item dropdown no-arrow">
        <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          <?php echo $associate_name12;?><i class="fas fa-user-circle fa-fw"></i>
        </a>
        <div class="dropdown-menu dropdown-menu-right" aria-labelledby="userDropdown">          
          
		  <?php if($rolegt == 'Super_admin'){ ?>				
				<a class="dropdown-item" href="../associate/profile.php?snoid=<?php echo base64_encode($idgt); ?>">Profile</a>
				<div class="dropdown-divider"></div>
				<a class="dropdown-item" href="../associate/setting.php?snoid=<?php echo base64_encode($idgt); ?>">Settings</a>
				<div class="dropdown-divider"></div>
				<a class="dropdown-item" href="#" data-toggle="modal" data-target="#logoutModal">Logout</a>
		  <?php } ?>
		  
		  <?php if($rolegt == 'Admin'){ ?>
				<a class="dropdown-item" href="../associateag/profile.php?snoid=<?php echo base64_encode($idgt); ?>">Profile</a>
				<div class="dropdown-divider"></div>
				<a class="dropdown-item" href="../associateag/setting.php?snoid=<?php echo base64_encode($idgt); ?>">Settings</a>
				<div class="dropdown-divider"></div>
				<a class="dropdown-item" href="../logout.php">Logout</a>
		  <?php } ?>
		  
        </div>
      </li>
    </ul>

  </nav>
